-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 04-01-2012 a las 15:57:35
-- Versión del servidor: 5.0.51
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `lagc`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `av_avisos`
-- 

CREATE TABLE `av_avisos` (
  `id` int(11) NOT NULL auto_increment,
  `titulo` varchar(200) collate utf8_spanish_ci NOT NULL,
  `fechacre` varchar(11) collate utf8_spanish_ci NOT NULL,
  `fechapro` varchar(11) collate utf8_spanish_ci NOT NULL,
  `activo` int(1) NOT NULL default '2',
  `resumen` varchar(300) collate utf8_spanish_ci NOT NULL,
  `resu_act` mediumint(1) NOT NULL default '1',
  `descripcion` text collate utf8_spanish_ci NOT NULL,
  `categoria` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `av_avisos`
-- 

INSERT INTO `av_avisos` VALUES (1, 'aviso numero 1', '1234567890', '1234567890', 1, 'resumen de avido numero 1', 1, 'descripcion completa de aviso numero 1', 2);
INSERT INTO `av_avisos` VALUES (2, 'titulo 2', '1234567890', '123456789', 1, 'resumen titulo 2', 1, 'descripcion de titulo 2', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `av_categorias`
-- 

CREATE TABLE `av_categorias` (
  `id_cat` int(11) NOT NULL auto_increment,
  `titulo_cat` varchar(100) character set latin1 NOT NULL,
  `descripcion` varchar(300) character set latin1 NOT NULL,
  PRIMARY KEY  (`id_cat`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `av_categorias`
-- 

INSERT INTO `av_categorias` VALUES (1, 'cat 1', 'descri cat 1');
INSERT INTO `av_categorias` VALUES (2, 'cat 2', 'descr cat 2');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `blog_articulos`
-- 

CREATE TABLE `blog_articulos` (
  `b_id` int(11) NOT NULL auto_increment,
  `b_autor` int(11) NOT NULL,
  `b_titulo` varchar(255) collate utf8_spanish_ci NOT NULL,
  `b_resumen` varchar(255) collate utf8_spanish_ci NOT NULL,
  `b_resumen_activar` int(1) NOT NULL,
  `b_contenido` longtext collate utf8_spanish_ci NOT NULL,
  `b_categoria` int(11) NOT NULL,
  `b_palabras` varchar(255) collate utf8_spanish_ci NOT NULL,
  `b_fecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `b_fechamodi` varchar(11) collate utf8_spanish_ci NOT NULL,
  `b_form_coment_act` int(1) default '2',
  `b_coment_act` int(1) default '2',
  `b_activo` int(1) NOT NULL,
  PRIMARY KEY  (`b_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `blog_articulos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `blog_categorias`
-- 

CREATE TABLE `blog_categorias` (
  `cat_id` int(11) NOT NULL auto_increment,
  `cat_nombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `cat_descripcion` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cat_activado` int(1) NOT NULL,
  PRIMARY KEY  (`cat_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=6 ;

-- 
-- Volcar la base de datos para la tabla `blog_categorias`
-- 

INSERT INTO `blog_categorias` VALUES (1, 'Lagc Peru', 'descripcion del blog jejedescripcion del blog jejedescripcion del blog jejedescripcion del blog jejedescripcion del blog jejedescripcion del blog jejedescripcion del blog jejedescripcion del blog jejedescripcion del blog jejedescripcion del blog jejedescr', 1);
INSERT INTO `blog_categorias` VALUES (2, 'PHP', '', 1);
INSERT INTO `blog_categorias` VALUES (3, 'HTML5', '', 1);
INSERT INTO `blog_categorias` VALUES (4, 'CSS3', 'descripcion del blog jejedescripcion del blog jejedescripcion del blog jejedescripcion del blog jejedescripcion del blog jejedescripcion del blog jejedescripcion del blog jejedescripcion del blog jejedescripcion del blog jejedescripcion del blog jejedescr', 1);
INSERT INTO `blog_categorias` VALUES (5, 'Manuales', '', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `blog_comentarios`
-- 

CREATE TABLE `blog_comentarios` (
  `comen_id` int(11) NOT NULL auto_increment,
  `comen_articulo` int(11) NOT NULL,
  `comen_comentario` varchar(250) collate utf8_spanish_ci NOT NULL,
  `comen_fcreado` varchar(11) collate utf8_spanish_ci NOT NULL,
  `comen_faprobado` varchar(11) collate utf8_spanish_ci NOT NULL,
  `comen_usuario` int(11) NOT NULL,
  `comen_aprobado` int(1) NOT NULL,
  PRIMARY KEY  (`comen_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `blog_comentarios`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `blog_visitas`
-- 

CREATE TABLE `blog_visitas` (
  `id` int(11) NOT NULL auto_increment,
  `IP` varchar(15) collate utf8_spanish_ci default NULL,
  `hora` varchar(8) collate utf8_spanish_ci default NULL,
  `articulo` varchar(11) collate utf8_spanish_ci default NULL,
  `segundos` varchar(30) collate utf8_spanish_ci default NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `blog_visitas`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cl_clientes`
-- 

CREATE TABLE `cl_clientes` (
  `cl_id` int(11) NOT NULL auto_increment,
  `cl_nombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `cl_imagen` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cl_descipcion` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cl_web` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cl_empresa` varchar(100) collate utf8_spanish_ci NOT NULL,
  `cl_activado` int(1) NOT NULL,
  PRIMARY KEY  (`cl_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=9 ;

-- 
-- Volcar la base de datos para la tabla `cl_clientes`
-- 

INSERT INTO `cl_clientes` VALUES (1, 'Nuez de la India Perú', '1316356670.jpg', '', 'http://www.nuezdelaindiaperu.com/', 'Lagc Perú', 1);
INSERT INTO `cl_clientes` VALUES (2, 'Extrem Callalli', '1316356704.jpg', '', 'http://www.extremcallalli.com/', 'Lagc Perú', 1);
INSERT INTO `cl_clientes` VALUES (3, 'Laboratorio Llerena', '1316356800.jpg', '', 'http://www.labllerenaames.com/', 'Lagc Perú', 1);
INSERT INTO `cl_clientes` VALUES (4, 'Perú Rock and Pop', '1316356832.jpg', '', 'http://www.perurockandpop.com/', 'Lagc Perú', 1);
INSERT INTO `cl_clientes` VALUES (5, 'Smart Soft Perú', '1316356868.jpg', '', 'http://smartsoftperu.com/', 'Smart Soft Perú', 1);
INSERT INTO `cl_clientes` VALUES (6, 'Por Tu Hermana', '1316356895.jpg', '', 'http://www.portuhermana.com/', 'Lagc Perú', 1);
INSERT INTO `cl_clientes` VALUES (7, 'Greys Importaciones', '1316357039.jpg', '', '', 'Lagc Perú', 1);
INSERT INTO `cl_clientes` VALUES (8, 'Corasil', '1318351196.jpg', '', 'http://corasil.com/', 'Grupo Innova Perú', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `componentes`
-- 

CREATE TABLE `componentes` (
  `id_com` int(11) NOT NULL auto_increment,
  `url` varchar(100) collate utf8_spanish_ci NOT NULL,
  `archivo` varchar(100) collate utf8_spanish_ci NOT NULL,
  `campobd` varchar(100) collate utf8_spanish_ci NOT NULL,
  `campoid` varchar(100) collate utf8_spanish_ci NOT NULL,
  `campotitulo` varchar(100) collate utf8_spanish_ci NOT NULL,
  `campopalabras` varchar(100) collate utf8_spanish_ci NOT NULL,
  `nombre` varchar(200) collate utf8_spanish_ci NOT NULL,
  `descripcion` text collate utf8_spanish_ci NOT NULL,
  `email` varchar(255) collate utf8_spanish_ci NOT NULL default 'luisgago@lagc-peru.com',
  `fecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `licencia` varchar(19) collate utf8_spanish_ci NOT NULL,
  `visible` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id_com`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=21 ;

-- 
-- Volcar la base de datos para la tabla `componentes`
-- 

INSERT INTO `componentes` VALUES (1, 'com_configuracion', 'class.lg', '', '', '', '', 'Configuracion', 'configuracion de todo el sitio', 'luisgago@lagc-peru.com', '1297124178', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (2, 'com_usuarios', 'inicio', 'usuarios', 'id', 'usuario', 'apellidos', 'Usuarios', 'Configura las cuentas de usuarios que podran acceder a lagc.', 'luisgago@lagc-peru.com', '1297122217', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (3, 'com_componentes', 'inicio', 'componentes', 'id_com', '', '', 'Componentes', 'Crear y Editar Componentes', 'luisgago@lagc-peru.com', '1297124189', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (4, 'com_sistema', 'class.login', '', '', '', '', 'Sistemas', 'Configuracion Global de Lagc', 'luisgago@lagc-peru.com', '1297124210', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (5, 'com_inicio', 'index', '', '', '', '', 'Inicio', 'Inicio del Administrador', 'luisgago@lagc-peru.com', '1297124224', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (6, 'com_modulos', 'inicio', '', '', '', '', 'Modulos', 'colocarse en un lugar donde mostrara el contenido', 'luisgago@lagc-peru.com', '1297124217', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (7, 'com_menu', 'inicio', '', '', '', '', 'Menu', '', 'luisgago@lagc-peru.com', '1301876879', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (8, 'com_imagenes', 'inicio', '', '', '', '', 'Imagenes', '', 'luisgago@lagc-peru.com', '1316996906', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (9, 'com_idiomas', 'inicio', '', '', '', '', 'Idiomas', '', 'luisgago@lagc-peru.com', '1316996997', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (10, 'com_plantillas', 'inicio', '', '', '', '', 'Plantillas', '', 'luisgago@lagc-peru.com', '1316997038', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (11, 'com_contenidos', 'inicio', 'contenidos', 'cont_id', 'cont_titulo', 'palabras', 'Contenidos', 'Crea contenidos y insertalos en el sitio. Consta de un editor similar a word.', 'luisgago@lagc-peru.com', '1297124231', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (12, 'com_programacion', 'inicio', 'prog_archivos', 'id_cont', 'nombre_cont', '', 'Programación', 'Archivos con codigo', 'luisgago@lagc-peru.com', '1297124241', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (13, 'com_galeria', 'inicio', 'fotos_album', 'id_gal', 'titulo', '', 'Galeria', 'Galerias de Fotos', 'luisgago@lagc-peru.com', '1297179535', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (14, 'com_avisos', 'inicio', 'av_avisos', 'id', 'titulo', '', 'Avisos', '', 'luisgago@lagc-peru.com', '1299784933', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (15, 'com_videos', 'inicio', '', '', '', '', 'Videos', '', 'luisgago@lagc-peru.com', '1299794636', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (16, 'com_whois', 'inicio', '', '', '', '', 'whois', '', 'luisgago@lagc-peru.com', '1301768174', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (17, 'com_blog', 'inicio', 'blog_articulos', 'b_id', 'b_titulo', 'b_palabras', 'Blog', '', 'luisgago@lagc-peru.com', '1310739467', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (18, 'com_clientes', 'inicio', 'cl_clientes', 'cl_id', 'cl_nombre', 'cl_empresa', 'Clientes', '', 'luisgago@lagc-peru.com', '1312835840', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (19, 'com_catalogodeltron', 'inicio', 'cp_productos', 'cp_pid', 'cp_pcodigo', 'cp_pdescripcion', 'Catalogo de Productos', '', 'luisgago@lagc-peru.com', '1313160728', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (20, 'com_productos', 'inicio', 'pro_productos', 'p_id', 'p_titulo', 'p_contenido1', 'Productos', '', 'luisgago@lagc-peru.com', '1318632785', '9470-5281-5767-1470', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `contenidos`
-- 

CREATE TABLE `contenidos` (
  `cont_id` int(11) NOT NULL auto_increment,
  `cont_titulo` varchar(300) collate utf8_spanish_ci NOT NULL,
  `cont_titulo_activo` int(1) NOT NULL,
  `cont_resumen` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cont_resumen_activar` int(1) NOT NULL,
  `cont_contenido` longtext collate utf8_spanish_ci NOT NULL,
  `palabras` varchar(200) collate utf8_spanish_ci NOT NULL,
  `cont_fecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `cont_fechamodi` varchar(11) collate utf8_spanish_ci NOT NULL,
  `activo` int(1) NOT NULL,
  PRIMARY KEY  (`cont_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=6 ;

-- 
-- Volcar la base de datos para la tabla `contenidos`
-- 

INSERT INTO `contenidos` VALUES (1, 'Que es Lagc Perú', 1, '', 1, '', 'que es lagc, descripcion lagc, definicion de lagc, datos de lagc', '1311786755', '1316912337', 1);
INSERT INTO `contenidos` VALUES (2, 'Servicios', 1, '', 1, '', '', '1311786773', '', 1);
INSERT INTO `contenidos` VALUES (3, 'Cms', 1, '', 1, '', 'cms lagc peru, lagc peru', '1316534834', '1316535157', 1);
INSERT INTO `contenidos` VALUES (4, 'Sistemas', 1, '', 1, '', 'sistemas lagc peru', '1316534871', '1316535640', 1);
INSERT INTO `contenidos` VALUES (5, 'Desarrollo Web', 1, '', 1, '', 'desarrollo web lagc peru', '1316534899', '1316535650', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cp_grupo`
-- 

CREATE TABLE `cp_grupo` (
  `cp_gid` int(11) NOT NULL auto_increment,
  `cp_gtipo` int(11) NOT NULL,
  `cp_gnombre` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_garchivo` varchar(100) collate utf8_spanish_ci NOT NULL COMMENT 'archivo .tpl para formularios',
  `cp_gactivo` int(1) NOT NULL default '1',
  PRIMARY KEY  (`cp_gid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=14 ;

-- 
-- Volcar la base de datos para la tabla `cp_grupo`
-- 

INSERT INTO `cp_grupo` VALUES (1, 1, 'Accesorios / miscelaneos', 'accesorios-miscelaneos.tpl', 1);
INSERT INTO `cp_grupo` VALUES (2, 1, 'Cases (cajas)', '', 1);
INSERT INTO `cp_grupo` VALUES (3, 1, 'Cdrom / dvd drives', '', 1);
INSERT INTO `cp_grupo` VALUES (4, 1, 'Computadoras pc', 'computadoras-pc.tpl', 1);
INSERT INTO `cp_grupo` VALUES (5, 1, 'Discos duros internos', '', 1);
INSERT INTO `cp_grupo` VALUES (6, 1, 'Fuentes estabilizadores ups', '', 1);
INSERT INTO `cp_grupo` VALUES (7, 2, 'Cpus (microprocesadores)', '', 1);
INSERT INTO `cp_grupo` VALUES (8, 2, 'Discos duros internos', '', 1);
INSERT INTO `cp_grupo` VALUES (9, 2, 'Motherboards (placas base)', '', 1);
INSERT INTO `cp_grupo` VALUES (10, 2, 'Multimedia, productos', '', 1);
INSERT INTO `cp_grupo` VALUES (11, 2, 'Tarjetas de video / dispositivos de video', '', 1);
INSERT INTO `cp_grupo` VALUES (12, 3, 'Suministros', '', 1);
INSERT INTO `cp_grupo` VALUES (13, 4, 'Garantia extendida', '', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cp_imagenes`
-- 

CREATE TABLE `cp_imagenes` (
  `cp_imgid` int(11) NOT NULL auto_increment,
  `cp_imgproduc` int(11) NOT NULL,
  `cp_imgtitulo` varchar(100) collate utf8_spanish_ci NOT NULL,
  `cp_imgimg` varchar(20) collate utf8_spanish_ci NOT NULL,
  `cp_imgdescripcion` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_imgfecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `cp_imgactivo` int(1) NOT NULL,
  PRIMARY KEY  (`cp_imgid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `cp_imagenes`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cp_linea`
-- 

CREATE TABLE `cp_linea` (
  `cp_tid` int(11) NOT NULL auto_increment,
  `cp_tnombre` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_tmarca` int(11) NOT NULL,
  `cp_tactivo` int(1) NOT NULL,
  PRIMARY KEY  (`cp_tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=9 ;

-- 
-- Volcar la base de datos para la tabla `cp_linea`
-- 

INSERT INTO `cp_linea` VALUES (1, 'Muebles para computadoras', 1, 1);
INSERT INTO `cp_linea` VALUES (2, 'tipo 2', 1, 1);
INSERT INTO `cp_linea` VALUES (3, 'Ups', 1, 1);
INSERT INTO `cp_linea` VALUES (4, 'Accesorios', 1, 1);
INSERT INTO `cp_linea` VALUES (5, 'Garantia extendida', 6, 1);
INSERT INTO `cp_linea` VALUES (6, 'Disco duro ide serial ata', 6, 1);
INSERT INTO `cp_linea` VALUES (7, 'Disco duro p/nb sata', 6, 1);
INSERT INTO `cp_linea` VALUES (8, 'Mb c2d s775 1333fsb', 5, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cp_locales`
-- 

CREATE TABLE `cp_locales` (
  `cp_lid` int(11) NOT NULL auto_increment,
  `cp_lnombre` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_ldireccion` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_ltelefonos` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_lactivado` int(1) NOT NULL,
  PRIMARY KEY  (`cp_lid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=13 ;

-- 
-- Volcar la base de datos para la tabla `cp_locales`
-- 

INSERT INTO `cp_locales` VALUES (1, 'Lima', 'los olivos 103 a-2', '054-12345652|01-19893242343', 1);
INSERT INTO `cp_locales` VALUES (6, 'Moquegua', 'mercaderes 105', '054-9523434|054-98345454|93543545', 1);
INSERT INTO `cp_locales` VALUES (12, 'Tacna', '', '|666|77777', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cp_marcas`
-- 

CREATE TABLE `cp_marcas` (
  `cp_mid` int(11) NOT NULL auto_increment,
  `cp_mgrupo` int(11) NOT NULL,
  `cp_mnombre` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_mimagen` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_mactivo` int(1) NOT NULL,
  PRIMARY KEY  (`cp_mid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=7 ;

-- 
-- Volcar la base de datos para la tabla `cp_marcas`
-- 

INSERT INTO `cp_marcas` VALUES (1, 1, 'Compaq', '1314718490.jpg', 1);
INSERT INTO `cp_marcas` VALUES (2, 1, 'Verbatim', '1314718824.jpg', 1);
INSERT INTO `cp_marcas` VALUES (3, 1, 'xexor', '1314718893.jpg', 1);
INSERT INTO `cp_marcas` VALUES (4, 1, 'nueva marca', '1314910215.jpg', 1);
INSERT INTO `cp_marcas` VALUES (5, 2, 'GIGABYTE', '1314976345.jpg', 1);
INSERT INTO `cp_marcas` VALUES (6, 4, 'TOSHIBA', '1314976412.jpg', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cp_productos`
-- 

CREATE TABLE `cp_productos` (
  `cp_pid` int(11) NOT NULL auto_increment,
  `cp_pusuario` int(11) NOT NULL,
  `cp_ptipo` int(5) NOT NULL,
  `cp_pmarca` int(11) NOT NULL,
  `cp_plinea` int(11) NOT NULL,
  `cp_pcodigo` varchar(100) collate utf8_spanish_ci NOT NULL,
  `cp_pdescripcion` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_ptipopro` int(11) NOT NULL,
  `cp_ptipoope` int(11) NOT NULL,
  `cp_plocales` text collate utf8_spanish_ci NOT NULL,
  `cp_pcomentario` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_pcaracteristicas` text collate utf8_spanish_ci NOT NULL,
  `cp_pfecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `cp_pmodificado` varchar(11) collate utf8_spanish_ci NOT NULL,
  `cp_pactivado` int(1) NOT NULL,
  PRIMARY KEY  (`cp_pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `cp_productos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `fotos_album`
-- 

CREATE TABLE `fotos_album` (
  `id_gal` int(11) NOT NULL auto_increment,
  `titulo` varchar(100) collate utf8_spanish_ci NOT NULL,
  `activar` int(1) NOT NULL,
  `descripcion` varchar(200) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id_gal`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `fotos_album`
-- 

INSERT INTO `fotos_album` VALUES (1, 'Primer Galería', 1, 'Descripción de galeria');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `fotos_imagenes`
-- 

CREATE TABLE `fotos_imagenes` (
  `id_ga` int(11) NOT NULL auto_increment,
  `titulo` varchar(100) collate utf8_spanish_ci NOT NULL,
  `imagen` varchar(50) collate utf8_spanish_ci NOT NULL,
  `descripcion` varchar(200) collate utf8_spanish_ci NOT NULL,
  `fechacre` varchar(11) collate utf8_spanish_ci NOT NULL,
  `fechamod` varchar(11) collate utf8_spanish_ci NOT NULL,
  `categoria` int(11) NOT NULL,
  `mostitle` int(1) NOT NULL,
  `mosdesc` int(1) NOT NULL,
  `activo` int(1) NOT NULL,
  PRIMARY KEY  (`id_ga`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `fotos_imagenes`
-- 

INSERT INTO `fotos_imagenes` VALUES (1, 'Primera Foto', '1318802615.jpg', 'descripcion de fotografia', '1318802615', '1318802674', 1, 1, 1, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `mod_modulos`
-- 

CREATE TABLE `mod_modulos` (
  `mod_id` int(11) NOT NULL auto_increment,
  `mod_nombre` varchar(255) collate utf8_spanish_ci NOT NULL,
  `mod_orden` varchar(100) collate utf8_spanish_ci NOT NULL default '0' COMMENT 'en que orden se mostrara cada modulo',
  `mod_posicion_id` int(11) NOT NULL,
  `mod_tipo_id` int(11) NOT NULL,
  `mod_fecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `mod_modificado` varchar(11) collate utf8_spanish_ci NOT NULL,
  `mod_permisos` varchar(1000) collate utf8_spanish_ci NOT NULL,
  `mod_permisosplus` varchar(255) collate utf8_spanish_ci NOT NULL,
  `mod_vertitu` int(1) NOT NULL,
  `mod_activo` int(1) NOT NULL,
  `mod_archivo` varchar(255) collate utf8_spanish_ci NOT NULL,
  `mod_tipvalor1` longtext collate utf8_spanish_ci NOT NULL,
  `mod_tipvalor2` longtext collate utf8_spanish_ci NOT NULL,
  `mod_tipvalor3` longtext collate utf8_spanish_ci NOT NULL,
  `mod_tipvalor4` longtext collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`mod_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=4 ;

-- 
-- Volcar la base de datos para la tabla `mod_modulos`
-- 

INSERT INTO `mod_modulos` VALUES (1, 'Menu Principal', '1', 6, 1, '1309450050', '1318804647', '-1|1', '14|17|19|18|12|11|13|20|2|15|16|', 0, 1, '', '1', '', '', '');
INSERT INTO `mod_modulos` VALUES (3, 'Bloque de Usuario', '', 1, 4, '1310959824', '1314888499', '13/13|1/13|2/16/16|1/16|2/18/17/9/9|1/8/8|3/8|1/8|2/8|4/10/10|1/12/12|2/2/2|2/2|3/2|1/14/15', '', 0, 2, '1310959824.tpl', '', '', '', '');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `mod_posiciones`
-- 

CREATE TABLE `mod_posiciones` (
  `mod_id` int(11) NOT NULL auto_increment,
  `mod_nombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `mod_codeinicio` varchar(255) collate utf8_spanish_ci NOT NULL,
  `mod_codefin` varchar(255) collate utf8_spanish_ci NOT NULL,
  `fecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `modificado` varchar(11) collate utf8_spanish_ci NOT NULL,
  `activado` int(1) NOT NULL,
  PRIMARY KEY  (`mod_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=13 ;

-- 
-- Volcar la base de datos para la tabla `mod_posiciones`
-- 

INSERT INTO `mod_posiciones` VALUES (1, 'izquierda', '', '', '1309618511', '1312835336', 1);
INSERT INTO `mod_posiciones` VALUES (2, 'derecha', '', '', '1309618511', '', 1);
INSERT INTO `mod_posiciones` VALUES (3, 'cabecera', '', '', '1309618511', '', 1);
INSERT INTO `mod_posiciones` VALUES (5, 'banner', '', '', '1309618511', '', 1);
INSERT INTO `mod_posiciones` VALUES (6, 'menuprincipal', '', '', '1309618511', '', 1);
INSERT INTO `mod_posiciones` VALUES (7, 'cabecera2', '', '', '1314645232', '1314645262', 1);
INSERT INTO `mod_posiciones` VALUES (8, 'internobody', '', '', '1314646046', '', 1);
INSERT INTO `mod_posiciones` VALUES (9, 'contenido1', '', '', '1314894275', '1314894296', 1);
INSERT INTO `mod_posiciones` VALUES (10, 'contenido2', '', '', '1314894306', '', 1);
INSERT INTO `mod_posiciones` VALUES (11, 'contenido3', '', '', '1318607530', '', 1);
INSERT INTO `mod_posiciones` VALUES (12, 'contenido4', '', '', '1318607549', '', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `mod_tipo`
-- 

CREATE TABLE `mod_tipo` (
  `tip_id` int(11) NOT NULL auto_increment,
  `tip_nombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `tip_lenguaje` varchar(10) collate utf8_spanish_ci NOT NULL,
  `tip_cabecera` longtext collate utf8_spanish_ci NOT NULL,
  `tip_archivo` varchar(15) collate utf8_spanish_ci NOT NULL,
  `tip_savetipo` int(1) NOT NULL default '1',
  `tip_fecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `tip_modificado` varchar(11) collate utf8_spanish_ci NOT NULL,
  `tip_activo` int(1) NOT NULL,
  `tip_tipvalor1` varchar(255) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`tip_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=5 ;

-- 
-- Volcar la base de datos para la tabla `mod_tipo`
-- 

INSERT INTO `mod_tipo` VALUES (1, 'Menus', 'html', '', '1309056506.php', 1, '1309056506', '1317165276', 1, 'posicion|css||');
INSERT INTO `mod_tipo` VALUES (2, 'Editor Html', 'html', '<script type="text/javascript" src="utilidades/tiny_mce/tiny_mce_gzip.js"></script>\r\n<script type="text/javascript">\r\n// This is where the compressor will load all components, include all components used on the page here\r\ntinyMCE_GZ.init({\r\n	plugins : ''spellchecker,pagebreak,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template'',\r\n	themes : ''advanced'',\r\n	languages : ''en'',\r\n	disk_cache : true,\r\n	debug : false\r\n});\r\n</script>\r\n<script type="text/javascript">\r\ntinyMCE.init({\r\n		// General options\r\n		mode : "textareas",\r\n		theme : "advanced",\r\n		editor_deselector : "mceNoEditor", //para que el textarea no tenga editor\r\n		plugins : "spellchecker,pagebreak,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template",\r\n		// Theme options\r\n		theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,undo,redo,formatselect,fontselect,fontsizeselect,insertdate,inserttime",\r\n		theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,link,unlink,anchor,cleanup,|,image,forecolor,|,removeformat,visualaid,|,code,preview,fullscreen",\r\n		theme_advanced_buttons3 : "tablecontrols,|,charmap,iespell,media,advhr,|,sub,sup",\r\n		theme_advanced_toolbar_location : "top",\r\n		theme_advanced_toolbar_align : "left",\r\n		theme_advanced_statusbar_location : "bottom",\r\n		theme_advanced_resizing : true,\r\n		// Skin options\r\n		skin : "o2k7",\r\n		skin_variant : "silver",\r\n		// Drop lists for link/image/media/template dialogs\r\n		template_external_list_url : "js/template_list.js",\r\n		external_link_list_url : "js/link_list.js",\r\n		external_image_list_url : "js/image_list.js",\r\n		media_external_list_url : "js/media_list.js",\r\n		// Replace values for the template plugin\r\n		template_replace_values : {\r\n				username : "Some User",\r\n				staffid : "991234"\r\n		}\r\n});\r\n</script>', '1309056543.php', 2, '1309056543', '1317165288', 1, 'contenido|||');
INSERT INTO `mod_tipo` VALUES (3, 'Codigo', 'html', '<script language="Javascript" type="text/javascript" src="utilidades/edit_area/edit_area_full.js"></script>\r\n<script language="Javascript" type="text/javascript">\r\n// initialisation\r\neditAreaLoader.init({\r\n  id: "cont2_lagc"	// id of the textarea to transform		\r\n  ,start_highlight: true	// if start with highlight\r\n  ,allow_resize: "both"\r\n  ,allow_toggle: true\r\n  ,word_wrap: true\r\n  ,language: "es"\r\n  ,syntax: "php"\r\n  ,toolbar: "search, go_to_line, |, undo, redo"\r\n});\r\n</script>', '1309056555.php', 2, '1309056555', '1317165332', 1, 'codigocont_lagc|||');
INSERT INTO `mod_tipo` VALUES (4, 'Identificarte', 'html', '', '1310959709.php', 2, '1310959709', '1317165344', 1, '|||');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `m_menus`
-- 

CREATE TABLE `m_menus` (
  `m_id` int(11) NOT NULL auto_increment,
  `m_nombre` varchar(255) collate utf8_spanish_ci NOT NULL,
  `m_componente` varchar(255) collate utf8_spanish_ci NOT NULL,
  `m_orden` int(11) NOT NULL,
  `m_target` varchar(10) collate utf8_spanish_ci NOT NULL,
  `m_cssa` varchar(11) collate utf8_spanish_ci NOT NULL,
  `m_cssli` varchar(11) collate utf8_spanish_ci NOT NULL,
  `m_tcssa` int(1) NOT NULL,
  `m_tcssli` int(1) NOT NULL,
  `m_fecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `m_modificado` varchar(11) collate utf8_spanish_ci NOT NULL,
  `m_posi` int(11) NOT NULL,
  `m_activo` int(1) NOT NULL,
  PRIMARY KEY  (`m_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=8 ;

-- 
-- Volcar la base de datos para la tabla `m_menus`
-- 

INSERT INTO `m_menus` VALUES (1, 'inicio', '-1|1', 1, '', 'nav1', '', 2, 1, '1310337280', '1325281231', 1, 1);
INSERT INTO `m_menus` VALUES (2, 'Contactanos', '12|1', 5, '', 'nav5', 'end', 2, 2, '1311698286', '1325458515', 1, 1);
INSERT INTO `m_menus` VALUES (4, 'La Empresa', '11|5', 2, '', 'nav2', '', 2, 1, '1311786871', '1325458100', 1, 1);
INSERT INTO `m_menus` VALUES (5, 'Servicios', '18', 3, '', 'nav3', '', 2, 1, '1311786880', '1325457946', 1, 1);
INSERT INTO `m_menus` VALUES (7, 'Clientes', '17', 4, '', 'nav4', '', 2, 1, '1311786936', '1325457984', 1, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `m_posicion`
-- 

CREATE TABLE `m_posicion` (
  `m_pid` int(11) NOT NULL auto_increment,
  `m_pnombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `m_pactivo` int(1) NOT NULL,
  PRIMARY KEY  (`m_pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `m_posicion`
-- 

INSERT INTO `m_posicion` VALUES (1, 'Menu Principal', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `m_submenus`
-- 

CREATE TABLE `m_submenus` (
  `m_subid` int(11) NOT NULL auto_increment,
  `m_subnombre` varchar(255) collate utf8_spanish_ci NOT NULL,
  `m_subidm` int(11) NOT NULL,
  `m_subcomponente` varchar(255) collate utf8_spanish_ci NOT NULL,
  `m_subtarget` varchar(10) collate utf8_spanish_ci NOT NULL,
  `m_subcss` varchar(11) collate utf8_spanish_ci NOT NULL,
  `m_suborden` int(11) NOT NULL,
  `m_subfecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `m_submodificado` varchar(11) collate utf8_spanish_ci NOT NULL,
  `m_subposi` int(11) NOT NULL,
  `activado` int(1) NOT NULL,
  PRIMARY KEY  (`m_subid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `m_submenus`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `prog_archivos`
-- 

CREATE TABLE `prog_archivos` (
  `id_cont` int(11) NOT NULL auto_increment,
  `nombre_cont` varchar(100) collate utf8_spanish_ci NOT NULL,
  `archivo_cont` varchar(20) collate utf8_spanish_ci NOT NULL,
  `fecha_cre` varchar(11) collate utf8_spanish_ci NOT NULL,
  `fecha_mod` varchar(11) collate utf8_spanish_ci NOT NULL,
  `activo` int(1) NOT NULL,
  PRIMARY KEY  (`id_cont`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `prog_archivos`
-- 

INSERT INTO `prog_archivos` VALUES (1, 'Contactenos', '1_contacto', '1312252295', '1317253876', 1);
INSERT INTO `prog_archivos` VALUES (2, 'Radio Online', '2_radio', '1314558036', '1317253889', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `pro_productos`
-- 

CREATE TABLE `pro_productos` (
  `p_id` int(11) NOT NULL auto_increment,
  `p_titulo` varchar(300) collate utf8_spanish_ci NOT NULL,
  `p_contenido1` longtext collate utf8_spanish_ci NOT NULL,
  `p_contenido2` longtext collate utf8_spanish_ci NOT NULL,
  `p_contenido3` longtext collate utf8_spanish_ci NOT NULL,
  `p_imagen` varchar(14) collate utf8_spanish_ci NOT NULL,
  `p_fecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `p_fechamodi` varchar(11) collate utf8_spanish_ci NOT NULL,
  `activo` int(1) NOT NULL,
  PRIMARY KEY  (`p_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `pro_productos`
-- 

INSERT INTO `pro_productos` VALUES (1, 'Producto primero', '<p>Primer Producto</p>', '<p>caracteristicas</p>', '<p>mas info&nbsp;</p>', '1318798781.jpg', '1318777392', '1318798781', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuarios`
-- 

CREATE TABLE `usuarios` (
  `id` tinyint(5) NOT NULL auto_increment,
  `usuario` varchar(20) collate utf8_spanish_ci NOT NULL,
  `password` varchar(32) collate utf8_spanish_ci NOT NULL,
  `componentes` varchar(500) collate utf8_spanish_ci NOT NULL,
  `email` varchar(100) collate utf8_spanish_ci NOT NULL,
  `tipo` int(5) default '2',
  `activo` int(11) NOT NULL,
  `sexo` int(1) NOT NULL,
  `nombres` varchar(200) collate utf8_spanish_ci NOT NULL,
  `apellidos` varchar(200) collate utf8_spanish_ci NOT NULL,
  `cump_dia` varchar(2) collate utf8_spanish_ci NOT NULL,
  `cump_mes` varchar(2) collate utf8_spanish_ci NOT NULL,
  `cump_anio` varchar(4) collate utf8_spanish_ci NOT NULL,
  `doc_tipo` int(11) NOT NULL,
  `doc_num` int(50) NOT NULL,
  `imagen` text collate utf8_spanish_ci NOT NULL,
  `fecha` varchar(10) collate utf8_spanish_ci NOT NULL,
  `fechamodi` varchar(10) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `usuarios`
-- 

INSERT INTO `usuarios` VALUES (1, 'vikingo', '42d83ea5c0be456bdf42fa61f55d5288', '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20', 'luisgago@lagc-peru.com', 1, 1, 1, 'Luis', 'Gago Casas', '30', '5', '1989', 1, 70332193, 'vikingo_1319903979.jpg', '1278379495', '1319903979');
INSERT INTO `usuarios` VALUES (2, 'admin', '14313a59312d605973aa6a7adf87a7a3', '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20', 'info@lagc-peru.com', 1, 1, 1, 'Administrador', 'Lagc Peru', '-1', '-1', '-1', 1, 0, '', '1296763709', '1320445884');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `videos`
-- 

CREATE TABLE `videos` (
  `id_vi` int(11) NOT NULL auto_increment,
  `titulo` varchar(100) collate utf8_spanish_ci NOT NULL,
  `descripcion` varchar(200) collate utf8_spanish_ci NOT NULL,
  `url` varchar(300) collate utf8_spanish_ci NOT NULL,
  `fechacre` varchar(11) collate utf8_spanish_ci NOT NULL,
  `fechamod` varchar(11) collate utf8_spanish_ci NOT NULL,
  `mostitle` int(1) NOT NULL,
  `mosdesc` int(1) NOT NULL,
  `activo` int(1) NOT NULL,
  PRIMARY KEY  (`id_vi`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `videos`
-- 

