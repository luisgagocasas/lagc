-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 02-02-2013 a las 08:03:12
-- Versión del servidor: 5.0.51
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `lagc`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `av_avisos`
-- 

CREATE TABLE `av_avisos` (
  `id` int(11) NOT NULL auto_increment,
  `titulo` varchar(200) collate utf8_spanish_ci NOT NULL,
  `fechacre` varchar(11) collate utf8_spanish_ci NOT NULL,
  `fechapro` varchar(11) collate utf8_spanish_ci NOT NULL,
  `activo` int(1) NOT NULL default '2',
  `resumen` varchar(300) collate utf8_spanish_ci NOT NULL,
  `resu_act` mediumint(1) NOT NULL default '1',
  `descripcion` text collate utf8_spanish_ci NOT NULL,
  `categoria` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `av_avisos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `av_categorias`
-- 

CREATE TABLE `av_categorias` (
  `id_cat` int(11) NOT NULL auto_increment,
  `titulo_cat` varchar(100) character set latin1 NOT NULL,
  `descripcion` varchar(300) character set latin1 NOT NULL,
  PRIMARY KEY  (`id_cat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `av_categorias`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `blog_articulos`
-- 

CREATE TABLE `blog_articulos` (
  `b_id` int(11) NOT NULL auto_increment,
  `b_autor` int(11) NOT NULL,
  `b_titulo` varchar(255) collate utf8_spanish_ci NOT NULL,
  `b_resumen` varchar(255) collate utf8_spanish_ci NOT NULL,
  `b_img` varchar(30) collate utf8_spanish_ci NOT NULL,
  `b_resumen_activar` int(1) NOT NULL,
  `b_contenido` longtext collate utf8_spanish_ci NOT NULL,
  `b_categoria` int(11) NOT NULL,
  `b_palabras` varchar(255) collate utf8_spanish_ci NOT NULL,
  `b_fecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `b_fechamodi` varchar(11) collate utf8_spanish_ci NOT NULL,
  `b_form_coment_act` int(1) default '2',
  `b_coment_act` int(1) default '2',
  `b_activo` int(1) NOT NULL,
  PRIMARY KEY  (`b_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=20 ;

-- 
-- Volcar la base de datos para la tabla `blog_articulos`
-- 

INSERT INTO `blog_articulos` VALUES (1, 1, 'Ubicación, Limites y Poblacion del Distrito Socabaya', '', '1341918149.jpg', 0, '<p style="text-align: justify;"><strong>UBICACI&Oacute;N: Socabaya</strong> es un peque&ntilde;o valle circundado de cerros rocosos de una altura Media que son ramales de la cadena de cerros llamada Calera (Cerro Grande, Las Caseras, Carnavales, Pillu). Esta ubicada al Sur Oeste de la Ciudad de Arequipa a una distancia de 12 km. del centro de La ciudad, comprendida entre las coordenadas 16&ordm; 27&acute; 51&rdquo; latitud sur, 1&ordm; 31&acute;40&rdquo; de latitud Oeste a 2,300 metros sobre el nivel del mar.</p>\r\n<p style="text-align: justify;"><strong>LIMITES:</strong> Socabaya limita por el Norte con el distrito de Jos&eacute; Luis Bustamante y Rivero, Por Sur con el distrito de Yarabamba, por el Este Con los distritos de <strong>Mollebaya</strong>, <strong>Characato y Saband&iacute;a</strong>, por el Oeste con el distrito de <strong>Jacobo D. Hunter</strong> y la cadena de cerros que sigue de Sur a Norte.</p>\r\n<p style="text-align: justify;"><strong>POBLACI&Oacute;N:</strong> La poblaci&oacute;n aproximada total de Socabaya, se eleva a 39,838 habitantes, de los cuales 18,797 son hombres y 18,935 son mujeres. Con una tasa de crecimiento de 1.1%. Esta poblaci&oacute;n presenta el 5.7% de la poblaci&oacute;n de la Provincia de <strong>Arequipa</strong>, y el 4.2% de la poblaci&oacute;n departamental. Su densidad poblacional es de 2050 habitantes por Km2. La Distribuci&oacute;n de su poblaci&oacute;n es bastante desigual sabiendo que la mayor parte de ella (el 97.14% se con centra en &aacute;reas urbanas dejando el 2.86%. NOTA: En el &uacute;ltimo censo realizado todav&iacute;a no tiene resultados oficiales sobre la poblaci&oacute;n actual del distrito.</p>\r\n<p><img style="margin: 5px auto; display: block;" title="Plano de Socabaya" src="../componentes/com_imagenes/imagenes/1341918149.jpg" alt="Plano de Socabaya" height="698" width="500" /></p>', 1, 'Ubicacion Socabaya, Limites de Socabaya', '1341918187', '', 1, 1, 1);
INSERT INTO `blog_articulos` VALUES (2, 1, 'Himno de Socabaya', '', '1341946375.jpg', 0, '<p>&nbsp;</p>\r\n<center><table border="0" align="center"><tbody><tr>\r\n<td colspan="2">\r\n<h4><strong>I ESTROFA</strong></h4>\r\n<p align="center">&iexcl;Oh! Mi tierra, querida por siglos</p>\r\n<p align="center">donde razas mezclaron la voz,</p>\r\n<p align="center">&iexcl;Oh! Mi tierra, quebrilla celestre</p>\r\n<p align="center">como el m&aacute;s reluciente metal.</p>\r\n<p align="center">Valle hermosos de muchas leyendas</p>\r\n<p align="center">Donde el sol pareciera nacer.</p>\r\n<p align="center">Evocamos tus glorias pasadas</p>\r\n<p align="center">Junto al &aacute;rbol del bien y la paz.</p>\r\n</td>\r\n</tr><tr>\r\n<td>\r\n<h4><br /><br /><strong>II ESTROFA</strong></h4>\r\n<p align="center">Maucallaqta la tierra primera</p>\r\n<p align="center">donde una d&iacute;a hern&aacute;ndez, or&oacute;,</p>\r\n<p align="center">con aromas de vid y cebada</p>\r\n<p align="center">sanfernando un d&iacute;a creci&oacute;</p>\r\n<p align="center">en tus lares se hicieron tejidos</p>\r\n<p align="center">y a los tiempos t&uacute; dabas la cal,</p>\r\n<p align="center">los arrieros so&ntilde;aron contigo</p>\r\n<p align="center">en molino de piedra y ma&iacute;z</p>\r\n</td>\r\n<td>\r\n<h4><br /><br /><strong>III ESTROFA</strong></h4>\r\n<p align="center">Bello lar que prodiga ternuras</p>\r\n<p align="center">a trav&eacute;s de sus frutos en flor,</p>\r\n<p align="center">en la pe&ntilde;as dormidas se siente</p>\r\n<p align="center">el perfume que da el honor</p>\r\n<p align="center">fue Barriga, tu hijo amado</p>\r\n<p align="center">que te dio la verdad y el laurel</p>\r\n<p align="center">y con &eacute;l nuestras venas se hinchas</p>\r\n<p align="center">con pureza del viento del mar.</p>\r\n</td>\r\n</tr></tbody></table></center>\r\n<p><span style="font-size: 14px; color: #999; font-weight: bold;">&laquo; <a href="videos">Ver todos los Videos</a></span></p>\r\n<center><object style="height: 400px; width: 570px;" width="570" height="400" data="https://www.youtube.com/v/7njuS6J7CYo?version=3&amp;feature=player_embedded&amp;autohide=1&amp;autoplay=1&amp;controls=0&amp;enablejsapi=1&amp;fs=1&amp;loop=1&amp;rel=0" type="application/x-shockwave-flash"><param name="allowFullScreen" value="true" /><param name="allowScriptAccess" value="always" /><param name="src" value="https://www.youtube.com/v/7njuS6J7CYo?version=3&amp;feature=player_embedded&amp;autohide=1&amp;autoplay=1&amp;controls=0&amp;enablejsapi=1&amp;fs=1&amp;loop=1&amp;rel=0" /><param name="allowfullscreen" value="true" /><param name="allowscriptaccess" value="always" /></object></center>\r\n<p><span style="font-size: 10px; color: #999;">Doble Clic para la pantalla completa.</span></p>', 1, 'Himno socabaya, 2012 himno socabaya', '1341946069', '1341946564', 1, 1, 1);
INSERT INTO `blog_articulos` VALUES (3, 1, 'Construcción de la Plaza Principal de Socabaya', '', '1341946700.jpg', 0, '<p style="text-align: justify;">Una vez concluida la construcci&oacute;n de la Iglesia San Fernando Rey de Socabaya, en el a&ntilde;o de <strong>1795</strong>, tan solo se coloca una reja met&aacute;lica enfrente de la iglesia (la que actualmente existe), dejando de lado todo lo que hoy es la plaza, puesto que en ese entonces todo este terreno era parte del Cerro Mochadero, cubierto de piedras y espinas totalmente inclinado. Fue hasta el a&ntilde;o de 1919, teniendo como alcalde de Socabaya, a Don Pedro Barriga y de P&aacute;rroco a <strong>Don Jacinto Daniel Flores</strong>, que ven por conveniente y necesaria la nivelaci&oacute;n de dicho terreno para poder construir una plaza que de realce a la Iglesia. Para esto se re&uacute;nen con Don Pablo Lazo Gobernador del Distrito, Don Mariano Azunto N&uacute;&ntilde;ez, Juez de Paz, en dicha reuni&oacute;n se forma un Comit&eacute; para dar inicio a esta obra, donde el se&ntilde;or Alcalde asumir&iacute;a la Presidencia y Jacinto Daniel Flores la Tesorer&iacute;a.<img style="margin: 5px; float: right;" title="Plaza Antigua de Socabaya" src="http://1.bp.blogspot.com/_rg1w24wcW-g/TLyev9-zMyI/AAAAAAAAAFQ/lrqbNdVn5pU/s1600/PLAZA.jpg" alt="Antigua plaza Socabaya" height="295" width="411" /><br /> Adem&aacute;s se cont&oacute; con la presencia de Notables vecinos como son: <strong>Vicente A. Lazo, Santiago L. Mu&ntilde;oz y Don Faustino Lazo</strong>, quienes formar&iacute;an parte de una comisi&oacute;n para realizar la obra y para solicitar apoyo de los vecinos..<br /><br /> As&iacute; se dio comienzo a los trabajos de nivelaci&oacute;n a base de dinamita, barreta, lampa y pico, como tambi&eacute;n la edificaci&oacute;n de un muro de piedra cortada que existe en el lado Oeste de la Plaza. Luego de todo este trabajo, la Plaza terminar&iacute;a en forma de un cuadril&aacute;tero, con un pino y un molle en el centro de la misma.<br /><br /> Tiempo despu&eacute;s el teniente del ejercito <strong>Don Melchor C&aacute;rdenas</strong>, consigue la ampliaci&oacute;n de la Plaza. Para dar cabida a dos compa&ntilde;&iacute;as de Caballer&iacute;a, que all&iacute; necesitan acantonarse.<br /> En el a&ntilde;o de 1936, siendo Alcalde Don Francisco Carpio Sosa; Socabaya, soporta una fuerte granizada que destroz&oacute; los sembr&iacute;os de ma&iacute;z, por lo sucedido consigue ayuda econ&oacute;mica de las autoridades de Arequipa, para los damnificados, los cuales deciden donar el dinero para que se hiciera una obra en beneficio del pueblo.<br /><br /> Con este dinero se construir&iacute;a el mercado que se encuentra a un costado de la Plaza en la parte baja, conocida tambi&eacute;n como "<strong>La Recoba</strong>", a su vez se construye un canal y un peque&ntilde;o reservorio tray&eacute;ndose el agua desde la acequialta (<strong>Chuca</strong>). Actualmente el mercado existe pero esta abandonado, el canal ya ha desaparecido y el reservorio todav&iacute;a est&aacute; ubicado a un costado de la casa que fuera de la Sra. Celia Vda. de Salas. Es as&iacute; como se pudo con mayor facilidad regar las plantas y algunos &aacute;rboles existentes en la plaza.<br /><br /> En el a&ntilde;o de <strong>1942</strong>, el Director del Centro Escolar de Varones Don Nicanor Rivera C&aacute;ceres, dise&ntilde;a peque&ntilde;os jardines que florecieron con la ayuda y el trabajo de los alumnos. Entusiasmados los vecinos con este trabajo, forman un comit&eacute; pro construcci&oacute;n de la plaza, que estuvo conformado por los se&ntilde;ores Jos&eacute; Antonio P&eacute;rez Diez Canseco, como Presidente, la Srta. <strong>Mar&iacute;a Mercedes Lazarte</strong>, Directora de la Escuela de Ni&ntilde;as del Pueblo, <strong>Francisca Cuadros</strong>, <strong>Luis F. D&iacute;az P</strong>. y Don Albino Lazo.<br /><br /> Posteriormente el comit&eacute; gestionar&iacute;a ayuda del Alcalde Provincial de Arequipa, el Dr. C&eacute;sar A. Casovone, el cual designa al Ing. Manuel D&iacute;az Cano, para que dirigiera la obra, el mismo que redise&ntilde;ara la plaza en la forma y tama&ntilde;o en que ahora la vemos, con el producto de actividades pro fondos construyeron las camineras o andadores. En el a&ntilde;o de 1945 fue nombrado Alcalde de Socabaya, don Francisco - Cuadros en el mandato del Presidente <strong>Jos&eacute; Luis Bustamante y Rivero</strong>, en cuyo per&iacute;odo se dieron donaciones de cemento para todos los distritos, aprovechando tales recursos, para construir las galer&iacute;as de los lados norte y sur.<br /><br /> Posteriormente, en el a&ntilde;o de <strong>1948.</strong> Fue nombrado <strong>Alcalde Luis F. D&iacute;az P</strong>. el que logra la construcci&oacute;n del Consejo Distrital, en el local que hoy ocupa la Gobernatura del distrito. Al inaugurar dicha obra, se nombra como padrinos al Sr. Pedro P. D&iacute;az, conocido industrial que dona dinero en efectivo y el Sr. Ren&eacute; Forja, Gerente de Lanificio que don&oacute; ladrillo. Con estas donaciones y aunadas a otros fondos municipales, permiten la construcci&oacute;n de las galer&iacute;as de gradas de todo el lado este, siendo el constructor de esta obra el Sr. Manuel Ramos. Hacia el a&ntilde;o de 1950. A&ntilde;o que se logra el servicio de luz el&eacute;ctrica. El Sr. Alberto de Bela&uacute;nde, Gerente de la Sociedad El&eacute;ctrica, quien obsequia postes de madera con los cuales se pudo iluminar la plaza. Inaugur&aacute;ndose el d&iacute;a de las v&iacute;speras en la festividad de la Virgen de los Remedios en el mes de Setiembre.<br /><br /> En la gesti&oacute;n del Sr. Benigno Montoya, se edifica el malec&oacute;n del lado occidental de la plaza. En el a&ntilde;o de <strong>1967</strong> fue nombrado nuevamente alcalde don Francisco Cuadros, el que conjuntamente con sus regidores organiza unas peleas de toros y con la recaudaci&oacute;n se hace levantar la pileta en la parte central de la plaza, modificada tres veces hasta hoy.<br /><br /> En ese entonces don Senovio Polar, dona las bancas de cemento, que modernizaron m&aacute;s esta plaza. Luego en el a&ntilde;o de <strong>1970</strong> fue nombrado nuevamente Alcalde <strong>Luis F. D&iacute;az P</strong>., el cual logra la pavimentaci&oacute;n de las cuatro calles que rodean la plaza, permitiendo que all&iacute; se lleve a cabo los desfiles escolares por el Aniversario del Distrito y en Fiestas Patrias.<br /><br /> Las losetas con las que hoy est&aacute;n revestidas las camiseras fueron puestas en la gesti&oacute;n del <strong>Alcalde Fernando Pareja P&eacute;rez</strong>. Luego en el periodo de la Alcaldesa, <strong>Prof. Delia Rivera de Flores</strong>, coloca bancos de madera y de fierro forjado, y tambi&eacute;n se realizaba la elecci&oacute;n de Se&ntilde;orita Socabaya, en &eacute;sta Plaza, ya que sus grader&iacute;as se prestaban para apreciar con total comodidad &eacute;sta elecci&oacute;n.<br /><br /> La remodelaci&oacute;n total de la plaza que actualmente se observa, fue obra del Prof. <strong>Luis Tejada Pinto</strong>, durante su per&iacute;odo edil. Dicha plaza, emblema del Distrito guarda en su historia todo el trabajo, colaboraci&oacute;n y esfuerzo de todo su <strong>pueblo</strong>.</p>', 1, 'plaza socabaya, Iglesia san fernando rey', '1341946728', '', 1, 1, 1);
INSERT INTO `blog_articulos` VALUES (4, 1, 'Historia de la Fundacion del pueblo San Fernando de Socabaya', '', '1341946916.JPG', 0, '<p style="text-align: justify;"><strong>A&ntilde;o 1796 Juan Domingo de Zam&aacute;cola y J&aacute;uregui</strong><br /> Por la bondad de sus tierras en el Siglo <strong>XVII</strong> (17) exist&iacute;a en Socabaya, varias haciendas de espa&ntilde;oles, cuyos due&ntilde;os algunos resid&iacute;an aqu&iacute; en Socabaya, y otros en la ciudad de Arequipa. Se dice que el primer Alcalde Ordinario de este pueblo fue Don Francisco Herrera, y el Cacique de Indios Don Idelfonso Osnayo. Entre otros datos importante el Bachiller Zam&aacute;cola dice &ldquo;<strong>A distancia de dos leguas al Sur de Arequipa; en el camino Real que tira a los valles de Tambo, Moquegua y Arica se encuentra un paraje conocido con el nombre de Valle de Socabaya. Su temperamento es m&aacute;s c&aacute;lido y sin comparaci&oacute;n m&aacute;s h&uacute;medo que el de la ciudad de Arequipa</strong>&rdquo;.<img style="float: right; margin: 5px;" title="Historia de Socabaya" src="http://2.bp.blogspot.com/_rg1w24wcW-g/TLycTktFaFI/AAAAAAAAAFA/p1yqmxitbUY/s1600/100_7460.JPG" alt="Historio de Socabaya" height="225" width="300" /><br /><br /> Riegan este Valle cuatro r&iacute;os que son: el de Paucarpata cuyo origen es detr&aacute;s del Volc&aacute;n Pichu-Pichu, en las cabeceras del pueblo de Chiguata, tambi&eacute;n se les denomina &ldquo;Huac&aacute;n&rdquo;. El Canchismayo que se forma en las cabeceras de Characato y s&oacute;lo conduce agua en tiempo de lluvias; junt&aacute;ndose con el r&iacute;o Huac&aacute;n en el sitio denominado Umapalca. El r&iacute;o Mollebaya que se forma de varios manantiales de los cerros del Pichu-Pichu y el r&iacute;o Postrero o Postrer&iacute;o, cuyo origen es un manantial en la pampa de Izu&ntilde;a. Los dos r&iacute;os Mollebaya y Postrer&iacute;o se juntan en el sitio llamado Mauca Llacta, y van hac&iacute;a el oeste hasta Huasacache, donde tambi&eacute;n se juntan con el Huac&aacute;n y Canchismayo, siguiendo su curso hasta juntarse con el r&iacute;o Chili en el sitio denominado Tingo, que en lengua general de los indios significa &ldquo;Junto o Uni&oacute;n&rdquo;. En la caja de dicho r&iacute;o Postrero a poca distancia de nuestro pueblo hay una gran pe&ntilde;a con una gran concavidad en forma de b&oacute;veda, en donde brotan hilos de agua cristalina y hacia el Sur existen cerros que se denominan Pillo o Pillu donde predominan andener&iacute;a incaica.<br /><br /> Todos estos r&iacute;os no son abundantes de agua, pero cuando el a&ntilde;o es de lluvias, no deja de hacer da&ntilde;os en las riberas, llev&aacute;ndose extensiones de terrenos de sembr&iacute;o.<br /><br /> El Valle de Socabaya tiene tres lenguas espa&ntilde;olas de longitud y media legua de latitud. En aquella &eacute;poca produc&iacute;a trigo, ma&iacute;z, papas y algunos ganados. Dice el Padre Zam&aacute;cola que &ldquo;Su gente era robusta y bien apersonada y blanca.Las mujeres sumamente fecundas que sino quitara la vida la terciana del Valle de tambo a tantos socabayos a donde van a trabajar en aquel valle no cupieran de pie en sus pa&iacute;s. No hay terciana en Socabaya. Las &uacute;nicas enfermedades que se observaba fueron dolores de costado y Tabardillos&rdquo;.<br /><br /> El hombre de Socabaya provendr&iacute;a de las palabras quechuas Suca y Aya que quiere decir Campo de Sepulcros seg&uacute;n unos y Soco-Baya, sumidero-lugar seg&uacute;n otros. En efecto parece que en tiempo de los incas fue un cementerio de la regi&oacute;n, por los restos que se han hallado ac&aacute; especialmente en las faldas del <strong>Cerro Pillu</strong>, de donde los espa&ntilde;oles por corrupci&oacute;n del idioma vinieron en <strong>llamarle Socabaya</strong>, como lo nombramos hoy.<br /><br /> Los primeros espa&ntilde;oles plantaron en este sitio <strong>vi&ntilde;as</strong>, hab&iacute;a dos molinos de agua y un horno para cocer cal.<br /> No solamente fueron l<strong>os terremotos los que despoblaron Socabaya</strong> sino tambi&eacute;n las epidemias que sobrevinieron en el a&ntilde;o de <strong>1600</strong> por el sismo de este a&ntilde;o, las tierras quedaron infruct&iacute;feras, salitrosas y cubiertas de arenas (a ra&iacute;z de la erupci&oacute;n del Volc&aacute;n Huaynaputina).<br /> Por el aumento de la poblaci&oacute;n de Arequipa volvieron a ser trabajadas estas tierras y los topos se vend&iacute;an a diez y ocho reales; volviendo la prosperidad al Valle.<br /><br /> En el a&ntilde;o de <strong>1718</strong> este pueblo volvi&oacute; a sufrir el <strong>castigo de una plaga</strong> llamada peste que volvi&oacute; a despoblar el Valle. <strong>Fray Francisco Sotomayor,</strong> de la Orden Mercedaria compadecido de las calamidades que sufr&iacute;an los habitantes sobrevivientes se dedic&oacute; ha adoctrinarlos, para lo cual quiso construir una capilla en el sitio denominado San Jos&eacute; de Pueblo Viejo. Obra que no lleg&oacute; a lograrse. Un vecino de Socabaya llamado Francisco Tamayo hizo construir una capilla de b&oacute;veda en el sitio denominado <strong>Pasto de Lara</strong>, en terrenos del <strong>Monasterio de Santa Catalina</strong>. Capilla peque&ntilde;a que se destruy&oacute; en el<strong> terremoto de 1784</strong>. Hab&iacute;a otra Capilla en el lugar denominado Huasacache.<br /><br /> En el a&ntilde;o <strong>1794</strong> fue nombrado p&aacute;rroco de Socabaya el Bachiller Don <strong>Juan Domingo de Zam&aacute;cola y J&aacute;uregui</strong>, dejando por momento su curato de Cayma para cumplir con lo dispuesto por el <strong>REAL PATRONATO</strong>. El propio <strong>Doctor Zam&aacute;cola</strong> escribe la forma como se hizo cargo de la parroquia y dice: &ldquo;Mi primer cuidado s&oacute;lo se redujo a obtener los &aacute;nimos de aquellos vecinos en quienes advert&iacute; la suma frialdad y total desapego a las cosas de Dios.<br /><br /> Y es el caso que hab&iacute;a y hay todav&iacute;a en aquel Valle unos cuantos picarones quienes por vivirse a su Ley llevan una vida desastrosa no les gustaba tener tan a la mano un cura que velase sobre ellos; &eacute;stos fueron los que sembraron varias ciza&ntilde;as diab&oacute;licas para retraer a todos los dem&aacute;s de la asistencia a las faenas y dem&aacute;s que se ofrec&iacute;an. Pero llegado el tiempo de la Cuaresma conocieron la mayor parte de las gentes por medio de las amonestaciones y exhortaciones amorosas el bien que deb&iacute;an esperar as&iacute; en lo temporal como en lo espiritual si se verificase la conclusi&oacute;n de la Iglesia y la formaci&oacute;n del pueblo&rdquo;.<br /><br /> Se debe considerar a <strong>Juan Domingo Zam&aacute;cola y J&aacute;uregui</strong>, historiador ilustre dign&iacute;simo p&aacute;rroco de los curatos de Cayma y Socabaya, como el verdadero fundador del Pueblo de San Fernando de Socabaya; puesto que dispuso la reagrupaci&oacute;n de las casas en torno de la Iglesia formando la plaza, mand&oacute; construir arcos de piedra labrada a un costado de la Iglesia, mand&oacute; construir un local para la escuela y para atraer a los ni&ntilde;os, por primera vez en el Per&uacute;, el cura de Zam&aacute;cola les distribuy&oacute; las cartillas, cuadernos y rosarios. Se declar&oacute; Patrona de la Iglesia a Mar&iacute;a Sant&iacute;sima con el T&iacute;tulo de <strong>NUESTRA SE&Ntilde;ORA DE LOS REMEDIOS</strong>; asimismo se declar&oacute; Patr&oacute;n del Pueblo a SAN FERNANDO REY DE ESPA&Ntilde;A; la efigie del Patr&oacute;n de cuerpo entero y de madera construido por el maestro Don Diego de C&aacute;ceres, lo mismo que la efigie de San Jos&eacute;.<br /><br /> Adem&aacute;s la labor del Bachiller de <strong>Zam&aacute;cola y J&aacute;uregui,</strong> no solamente se concret&oacute; en la conclusi&oacute;n y adorno de la Iglesia y la construcci&oacute;n de las casas del pueblo, sino que tambi&eacute;n mand&oacute; hacer el camino real que se dirig&iacute;a al Valle de Tambo y otros pueblos anexos. Como el terreno del pueblo era accidentado por esta raz&oacute;n se le llamaba <strong>MUCHADERO</strong>, se efectuaron desmontes y planificaciones d&aacute;ndole la topograf&iacute;a que actualmente tiene.<br /><br /> Haciendo la aclaraci&oacute;n que este camino como la parte correspondiente a la plaza, Iglesia, calle Real por el costado de abajo y por la cabecera otra calle Real, formando un perfecto tri&aacute;ngulo es y pertenecen a la parroquia por sucesi&oacute;n de los due&ntilde;os de este sitio que son Don Buenaventura de Talavera, do&ntilde;a Felipa y do&ntilde;a Rita de Talavera y los Dem&aacute;s herederos de don Ignacio de Talavera y D&aacute;vila y don <strong>Manuel Asencio de Talavera</strong>.<br /> El templo y la sobras civiles se inauguraron el <strong>25 de mayo de 1795</strong>, o sea que en un a&ntilde;o se hab&iacute;a realizado una gran labor; se celebr&oacute; con este motivo una gran fiesta con <strong>m&uacute;sica</strong>, <strong>bailes y regocijo del pueblo</strong>.</p>', 1, 'historia socabaya, zamacola y jauregui', '1341946942', '', 1, 1, 1);
INSERT INTO `blog_articulos` VALUES (5, 1, 'Los Pueblos Tradicionales de Socabaya', '', '1341947231.jpg', 0, '<p><img style="border: 0px;" src="../componentes/com_imagenes/imagenes/1341947231.jpg" alt="" height="293" width="650" /></p>\r\n<p style="text-align: justify;"><strong>EL PUEBLO TRADICIONAL</strong><br /><br /><span>Es el pueblo principal del distrito donde se encuentra la plaza central del Socabaya y la iglesia San Fernando Rey de Socabaya, es su principal atractivo, la cual guarda a la Sant&iacute;sima Virgen Mar&iacute;a de los Remedios, patrona del distrito.</span><br /><span>En el pueblo tambi&eacute;n se encuentra la municipalidad, su plaza ofrece al turista una vista agradable, y la iglesia es muestra de la arquitectura en sillar de los antiguos arequipe&ntilde;os, que convirtieran a Arequipa en Patrimonio Cultural de la Humanidad.</span><br /><br /><strong>LA PAMPA TRADICIONAL</strong><br /><br /><span>Tambi&eacute;n conocida como &ldquo;pueblo viejo&rdquo;, esta ser&iacute;a la cuna de los netos y leg&iacute;timos socabayas. En este pueblo todav&iacute;a se puede sentir ese ambient&eacute; tradicional de los antiguos socabayas, sus pobladores son conocidos por lo arraigado de sus costumbres y tradiciones.&nbsp;</span><br /><span>Aqu&iacute; naciera el grandioso toro de pelea MENELIK, el mejor e incomparable hasta hoy de toda la campi&ntilde;a arequipe&ntilde;a, y en su nombre se encuentra el Complejo de Usos M&uacute;ltiples MENELIK, donde se realizan las tradicionales peleas se toros el 01 de enero; aperturando el calendario oficial de la ASCPATPA como festivales durante todo el a&ntilde;o.</span><br /><br /><strong>LARA TRADICIONAL</strong><br /><br /><span>Pueblo que da la bienvenida a los pueblos tradicionales, en este pueblo se encuentra el gran parque de la urbanizaci&oacute;n Lara, el Club CAFAE de EsSalud, el Club H&iacute;pico &ldquo;Los Criollos&rdquo; , el Golf Club, asimismo hace unos a&ntilde;os se vienen instalando nuevos restaurantes atrayendo turistas a esta zona del distrito.</span><br /><span>El pueblo de Lara se caracteriza por su fervor religioso y patronal, y es conocida su participaci&oacute;n en estas fiestas. Su principal actividad es la festividad de la Cruz de Lara, ubicada en la parte m&aacute;s alta de Santa cruz. En esta zona se tiene una vista panor&aacute;mica de 180&ordm; del distrito y su gran campi&ntilde;a.</span><br /><br /><strong>EL PASTO TRADICIONAL</strong><br /><br /><span>Pueblo privilegiado por la tranquilidad se sus parajes y el vivir en un ambiente realmente alejado del bullicio y la contaminaci&oacute;n de la ciudad.&nbsp;</span><br /><span>Es puerta de entrada a lo que seria considerado en la antigua Arequipa como su balneario, hablamos de la zona denominado hasta hoy como &ldquo;Las Pe&ntilde;as&rdquo;, especie de caverna de donde brotan hilos de agua que se encuentra en la rivera de postrer&iacute;o .</span><br /><span>El Santo patr&oacute;n de este pueblo es San Isidro Labrador, cuya imagen se encuentra en la zona m&aacute;s poblada de este caser&iacute;o..&nbsp;</span><br /><br /><strong>ALTO BUENA VISTA</strong><br /><br /><span>Pueblo tradicional que se encuentra camino a la Pampa, en el cual se ubica la Comisaria de Socabaya, as&iacute; como el Puesto de Salud San Fernando .&nbsp;</span><br /><span>Es caracter&iacute;stico en este pueblo su &ldquo;Cortamonte&rdquo; en el d&iacute;a de carnavales, como tambi&eacute;n la realizaci&oacute;n del Campeonato de verano, que se realiza en la zona denominada &ldquo;El pasto del Alto&rdquo; en el cual participan equipos principalmente de los pueblos tradicionales.</span><br /><span>El alto como todos los pueblos de Socabaya cuenta con impresionantes vistas de su abundante campi&ntilde;a.</span></p>', 1, 'Pueblos tradicionales de socabaya, la pampa, lara, el pasto, alto buena vista', '1341947293', '1341947355', 1, 1, 1);
INSERT INTO `blog_articulos` VALUES (6, 1, 'Biografia de Felipe Santiago Salaverry', '', '1341947443.jpg', 0, '<p style="text-align: justify;"><span><strong>Felipe Santiago Salaverry</strong> (Lima, 1805-Arequipa, 1836) <strong>Militar y pol&iacute;tico peruano</strong>. En 1835 se rebel&oacute; contra el presidente Orbegoso y le sucedi&oacute; en el poder. Durante su breve dictadura procur&oacute; una alianza comercial con Chile y elimin&oacute; la contribuci&oacute;n de castas. Derrotado y apresado por A. de Santa Cruz, muri&oacute; fusilado.</span></p>\r\n<p style="text-align: justify;"><span>Salaverry se enrol&oacute; con s&oacute;lo quince a&ntilde;os en el ej&eacute;rcito patriota, donde demostr&oacute; arrojo y mucha audacia, lo que se convirti&oacute; en el inicio de una vertiginosa carrera militar que le llevar&iacute;a a la c&uacute;spide con una precocidad que para muchos result&oacute; asombrosa.</span></p>\r\n<p style="text-align: justify;"><span>A los 28 a&ntilde;os ya ostentaba el grado de General del <strong>Ej&eacute;rcito</strong> y se pon&iacute;a en una posici&oacute;n expectante dentro de las altas esferas del poder castrense de la d&eacute;cada de 1830. Tal poder radic&oacute; en la cercana colaboraci&oacute;n que tuvo con el Gobierno del general Luis Jos&eacute; de Orbegoso (<strong>1833-1835</strong>), quien le nombr&oacute; Inspector General del Ej&eacute;rcito, cargo de suma importancia pues ten&iacute;a como principal objetivo asegurar la estabilidad del r&eacute;gimen y precaver cualquier tipo de sublevaci&oacute;n.<img style="float: right; margin: 5px;" title="Felipe Santiago Salaverry" src="http://2.bp.blogspot.com/_rg1w24wcW-g/TIlJ0i9E9NI/AAAAAAAAABw/odq-dQegn44/s1600/felipe+santiago+salaverry.jpg" alt="Felipe Santiago Salaverry" height="320" width="241" /></span></p>\r\n<p style="text-align: justify;"><span>En 1834, aprovechando el clima de profunda guerra civil que viv&iacute;a el pa&iacute;s, basado por el enfrentamiento entre Orbegoso y Berm&uacute;dez que se daba en la parte sur del pa&iacute;s. Salaverry, que participaba en las huestes de Orbegoso, se separ&oacute; de &eacute;l y fue a la zona norte donde se sublev&oacute; en Trujillo y el <strong>23 de febrero de 1835</strong> se autonombr&oacute; Legislador Supremo.</span><br /><span>Este hecho caus&oacute; la inmediata reacci&oacute;n de Orbegoso quien, una vez vencido Berm&uacute;dez, fue hacia Lima para enfrentarse a Salaverry. Orbegoso cont&oacute; con el apoyo de Andr&eacute;s de Santa Cruz, quien a la saz&oacute;n era Presidente de Bolivia.</span></p>\r\n<p style="text-align: justify;"><span>Tras lanzar contra Santa Cruz su famoso decreto de "<strong>Guerra a Muerte</strong>" y ofrecer premios a quien matase a <strong>un boliviano</strong>, Salaverry dio inicio a una audaz <strong>campa&ntilde;a militar</strong>, que principi&oacute; con el asalto al puerto de Cobija por la Marina de Guerra, donde se arrastr&oacute; por los suelos la bandera boliviana en ceremonia p&uacute;blica. Luego se dirigi&oacute; al sur del Per&uacute; con el grueso de sus tropas y se prepar&oacute; para <strong>enfrentar al presidente de Bolivi</strong>a.</span></p>\r\n<p style="text-align: justify;"><span>El <strong>7 de febrero</strong>, ambos ej&eacute;rcitos chocaron en la sangrienta <strong>batalla de Socabaya</strong>, donde el joven <strong>caudillo de 29 a&ntilde;os</strong> fue totalmente derrotado.</span><br /><span>Apresado, Felipe Santiago Salaverry fue fusilado, en la <strong>Plaza de Armas de Arequipa</strong> al lado de sus <strong>principales oficiales</strong>, consolid&aacute;ndose a partir de ese momento la Confederaci&oacute;n <strong>Per&uacute;-Boliviana</strong> que durar&iacute;a hasta 1839.</span><br /><span>Su hijo <strong>Carlos Augusto Salaverry</strong> fue uno de los <strong>poetas</strong> m&aacute;s destacados del <strong>romanticismo en el Per&uacute;</strong>.</span></p>\r\n<p><span><img style="display: block; margin-left: auto; margin-right: auto;" src="http://2.bp.blogspot.com/_rg1w24wcW-g/TQFDa7wPqYI/AAAAAAAAAGg/Ge5z_kCIxWM/s320/P1020076.JPG" alt="" height="240" width="320" /><br /></span></p>', 1, 'felipe santiago salavery, peru bolivia, batalla de socabaya, carlos augusto salaverry poeta, romanticismo en el peru', '1341947459', '', 1, 1, 1);
INSERT INTO `blog_articulos` VALUES (7, 1, 'Festividad de la Virgen Maria de los Remedios', '', '1341947679.jpg', 0, '<p style="text-align: justify;"><span><img style="float: left; margin: 5px;" title="Virgen Maria de los Remedios" src="http://3.bp.blogspot.com/_rg1w24wcW-g/TIesiJJhmCI/AAAAAAAAAA4/S2HMqILzrCE/s1600/S3000043.jpg" alt="Virgen Maria de los Remedios" height="267" width="200" />El mes de Setiembre es la festividad en homenaje a la Virgen Mar&iacute;a, que bajo el T&iacute;tulo de NUESTRA SE&Ntilde;ORA DE LOS REMEDIOS en su misterio de la Natividad, es la patrona del distrito, junto a San Fernando como homenaje al Rey de Espa&ntilde;a, de donde toma su nombre.</span><br /><br /><br /><span>Dentro de las principales actividades se realizan el COMBITE, SERENATAS, ARRANCADA Y ENTRADA DE CCAPO, LA OCTABA, MISAS Y PROCECIONES las dan un colorido especial y ambiente de fiesta a la Plaza Principal del distrito.</span><br /><br /><br /><span>La devoci&oacute;n de los fieles que especialmente visitan Socabaya, socabainos que ya no viven en el distrito, que con finalidad de seguir conservado la tradici&oacute;n y costumbres heredadas por su padres y abuelos participan en las diferentes actividades programadas dentro de la festividad.</span><br /><br /><br /><span>(D&iacute;as centrales 18,19 y 20 de setiembre del 2012)&nbsp;</span><br /><br /><span>Cual dulce y tierna madre</span><br /><span>la que a sus hijos contempla.</span><br /><span>Cuanta ternura en su mirada</span><br /><span>la que a sus hijos hoy alienta.</span></p>', 1, 'Virgen Maria de los Remedios', '1341947706', '', 1, 1, 1);
INSERT INTO `blog_articulos` VALUES (8, 1, 'Maucallacta Pueblo Viejo', '', '1341947772.JPG', 0, '<p style="text-align: justify;"><span>Desde tiempos inmemoriales exist&iacute;a un valle cerca al postrerio. Un pueblo llamado Maucallacta, conocido hoy por todos como Pueblo Viejo (La Pampa).</span></p>\r\n<p style="text-align: justify;"><span>Se sabe por algunos documentos antiguos, que los primeros corregidores que gobernaron Arequipa, mientras se constru&iacute;a la ciudad, tuvieron residencia en &eacute;ste pueblo. Ya que reun&iacute;an las condiciones apropiadas.</span></p>\r\n<p style="text-align: justify;"><span>Se sabe tambi&eacute;n que antes que llegara a Arequipa, su fundador ya hab&iacute;a espa&ntilde;oles en &eacute;stas tierras, seguramente vinieron escoltando a los primeros padres doctrineros, que atra&iacute;dos por las cualidades de &eacute;ste valle, deciden quedarse y aqu&iacute; iniciar su familia. Con exactitud no se sabe los nombres de &eacute;stos espa&ntilde;oles, pero por documentos sabemos que all&iacute; vivi&oacute; el capit&aacute;n espa&ntilde;ol Mart&iacute;n L&oacute;pez. Los primeros espa&ntilde;oles all&iacute; sembraron vi&ntilde;as, e hicieron dos molinos de agua y un horno para cocer cal.<img style="margin: 5px; float: right;" title="Maucallacta Pueblo Viejo" src="http://3.bp.blogspot.com/_rg1w24wcW-g/TIe6rXr0DrI/AAAAAAAAABA/cmWNt26-JWY/s1600/DSC01101.JPG" alt="Maucallacta Pueblo Viejo" height="225" width="300" /></span></p>\r\n<p style="text-align: justify;"><span>Actualmente no existen vestigios de &eacute;sta poblaci&oacute;n, seguramente por los constantes despoblamientos que hubo por los terremotos que tuvieron que pasar, existiendo hoy solamente algunos pocos sembr&iacute;os. El terremoto de 1582, el d&iacute;a. 22 de enero, destruy&oacute; todo cuanto se hab&iacute;a trabajado y edificado por sus pobladores, luego en el a&ntilde;o de 1600 vendr&iacute;an las epidemias a consecuencia de la erupci&oacute;n del <strong>volc&aacute;n Huayna</strong> Putina un 17 de enero.</span></p>\r\n<p style="text-align: justify;"><span>Fueron las lluvias de arena y piedra pomes tan espesa y abundante que en poco tiempo quedaron enterrados todos los sembr&iacute;os, pastos y caminos reales de esos tiempos, hubo oscuridad durante todo un mes, no se vieron los rayos del sol, la gente tenia que caminar con faroles en pleno d&iacute;a. Estos hechos redujeron en gran cantidad el n&uacute;mero de la poblaci&oacute;n de &eacute;ste pueblo, sus tierras quedaron infruct&iacute;feras y salitrosas, del valle que era apreciado por su fertilidad solo qued&oacute; en el recuerdo. Esto hizo que los pocos pobladores que quedaron tuvieran que emigrar, qued&aacute;ndose all&iacute; solo unos cuantos. Terminado as&iacute; con el pueblo que fue cuna de los primeros espa&ntilde;oles que vivieron en Arequipa, y el m&aacute;s poblado de esos tiempos. Llamado<strong> Maucallacta o pueblo viejo</strong>.</span></p>', 1, 'Maucallacta Pueblo Viejo', '1341947787', '', 1, 1, 1);
INSERT INTO `blog_articulos` VALUES (9, 1, 'Datos Importantes del Tradicional Distrito de Socabaya', 'La historia del tradicional distrito de Socabaya, se remonta a la época pre inca por las evidencias arqueológicas de Maucallacta, Pillu, y otros.', '1341947868.jpg', 1, '<p style="text-align: justify;"><span>Mucho m&aacute;s antes que se fundara Arequipa. En este valle ya habitaban espa&ntilde;oles, los que seguramente vinieron escoltando a los primeros padres doctrineros y por lo agradable del clima y sus f&eacute;rtiles Tierras deciden quedarse e iniciar en este pueblo su familia.</span></p>\r\n<p style="text-align: justify;"><img style="margin: 5px;" title="Distrito de Socabaya" src="http://1.bp.blogspot.com/_rg1w24wcW-g/TIfsBeoeJLI/AAAAAAAAABY/IBjqiZJk6vk/s1600/Alma+Recor+2+mnn.jpg" alt="Distrito de Socabaya" height="281" width="600" /><br /><span>En la &Eacute;poca Colonial, documentos antiguos se conoce que el Marqu&eacute;s Don Francisco Pizarro entreg&oacute; en encomienda el Ayllu de Socabaya el 22 de Enero de 1540 al capit&aacute;n Diego Hern&aacute;ndez, d&aacute;ndole adem&aacute;s 170 indios propios de este Ayllu.</span><br /><br /><span>Posteriormente los evangelizadores de la Iglesia cat&oacute;lica, construyeron una imponente Iglesia San Fernando la cual fue destruida por el terremoto de 1582.</span><br /><br /><span>La nueva Iglesia fue construida en el nuevo Pueblo San Fernando del valle de Socabaya, por el Padre e Historiador Lic. Juan Domingo Zam&aacute;cola y J&aacute;uregui, inaugur&aacute;ndose el 25 de mayo de 1795, conjuntamente con otras obras. Por lo que se toma esta fecha como nacimiento del distrito.</span><br /><br /><span>Desde el punto de vista legal el distrito de Socabaya fue creado por ley N&ordm; 12301 del 3 de mayo de 1955, otorg&aacute;ndole la categor&iacute;a de pueblo .</span><br /><br /><span>El nombre de Socabaya provendr&iacute;a de las palabras quechuas SUCCA AYA que significan &ldquo;campo de los sepulcros&rdquo;. En efecto que en tiempo pre-inca fue un cementerio, esto lo evidencian los varios tapados de piedra que se hallan en las laderas del cerro Pillu. De donde los espa&ntilde;oles por correcci&oacute;n del idioma vinieron en llamarle SOCABAYA, como la nombramos hoy.</span><br /><br /><span>El mes de Setiembre es la festividad en homenaje a la Virgen Mar&iacute;a, que bajo el T&iacute;tulo de NUESTRA SE&Ntilde;ORA DE LOS REMEDIOS en su misterio de la Natividad, es la patrona del distrito, junto a San Fernando como homenaje al Rey de Espa&ntilde;a, de donde toma su nombre.</span><br /><br /><span>En Socabaya en el cerro Alto la Luna (Urb. La Campi&ntilde;a) Aconteci&oacute; la batalla de Socabaya entre las fuerzas del General Felipe Santiago Salaverry, contra el Mariscal Boliviano Andr&eacute;s de Santa Cruz, el 7 de Febrero de 1836, donde Salaverry, fue derrotado y fucilado en la plaza de Armas de Arequipa, el 18 de Febrero del mismo a&ntilde;o.</span><br /><br /><span>Socabaya a trav&eacute;s de la historia ha tenido muchos hijos ilustres como: reverendo padre Victor M. Barriga religioso e historiador; el Dr. En derecho Lino Mu&ntilde;oz Escobedo catedr&aacute;tico y Autor de varias obras; el Dr. En medicina Melit&oacute;n Salas Tejada , que gracias a su esfuerzo Tenemos el centro de salud de San Mart&iacute;n y que funciona junto con ESSALUD denominado con su nombre .</span><br /><br /><span>Los padres de la compa&ntilde;&iacute;a de Jes&uacute;s, en Huasacache, incrementaron la Agricultura con plantaciones de ma&iacute;z, papas, trigo, cebada, plantas forrajeras, vid, etc. que convirti&oacute; a Socabaya en despensa de la ciudad de Arequipa .</span><br /><br /><span>Los padres de la compa&ntilde;&iacute;a de Jes&uacute;s, en Huasacache, incrementaron la Agricultura con plantaciones de ma&iacute;z, papas, trigo, cebada, plantas forrajeras, vid, etc. que convirti&oacute; a Socabaya en despensa de la ciudad de Arequipa</span></p>', 1, 'Datos importantes Socabaya', '1341947879', '', 1, 1, 1);
INSERT INTO `blog_articulos` VALUES (10, 1, 'Emergencia turística en Arequipa', 'La crisis financiera mundial y especialmente la crisis europea han causado grandes estragos alrededor del mundo, cientos de empresas quebradas generaron millones de personas desempleadas.', '1342003317.jpg', 1, '<p style="text-align: justify;"><span>Si bien el Per&uacute; se jacta de tener una econom&iacute;a creciente, la crisis mundial ha comenzado a afectar a uno de los principales campos generadores de econom&iacute;a e inversi&oacute;n que tiene nuestro pa&iacute;s: el turismo.</span></p>\r\n<p style="text-align: justify;"><span>Por ello, los principales entes representativos del turismo en nuestra ciudad exclaman su preocupaci&oacute;n, exigen promocionar m&aacute;s los destinos tur&iacute;sticos, pero tambi&eacute;n miran hacia otros posibles mercados la posibilidad de crecer, lejanos, obviamente, a la comunidad europea.</span></p>\r\n<p style="text-align: justify;"><strong><span>MISIONES COMERCIALES</span></strong></p>\r\n<p style="text-align: justify;"><span>El presidente de&nbsp;la Asociaci&oacute;n Peruana&nbsp;de Hoteles, Restaurantes y Afines (Ahora), Rafael Cornejo, indic&oacute; que el turismo se debe enfocar hacia los pa&iacute;ses latinoamericanos, como Chile y Brasil as&iacute; como a Estados Unidos ya que estos serian, en la actualidad, los principales mercados.</span></p>\r\n<p style="text-align: justify;"><span>&ldquo;La soluci&oacute;n para enfrentar esta crisis es hacer misiones comerciales a todos los pa&iacute;ses de Latinoam&eacute;rica, es decir, que comisiones viajen y promocionen nuestra ciudad como destino tur&iacute;stico, que vayan a ferias y exposiciones&rdquo;.</span></p>\r\n<p style="text-align: justify;"><span>Asimismo agreg&oacute; que para estas Fiestas Patrias no esperan recibir m&aacute;s de 20 mil turistas extranjeros, ya que, seg&uacute;n Cornejo, el turismo ha ca&iacute;do en relaci&oacute;n al a&ntilde;o pasado en nuestra ciudad, en un 20%, pero, en contraposici&oacute;n, se espera recibir a 60 mil turistas nacionales, ya que ellos habr&iacute;an crecido en un 15%.</span></p>\r\n<p style="text-align: justify;"><span>En Arequipa, el rubro de hoteles y restaurantes da 40 mil empleos entre directos e indirectos.</span></p>\r\n<p style="text-align: justify;"><strong><span>FIESTAS DE AREQUIPA</span></strong></p>\r\n<p style="text-align: justify;"><span>Para promocionar las fiestas de Arequipa, el Subgerente de Relaciones Exteriores y&nbsp;Turismo&nbsp;de&nbsp;la Municipalidad Provincial,&nbsp;Fredy Padilla Guzm&aacute;n, se&ntilde;al&oacute; que habr&aacute; diferentes conferencias de prensa tanto en nuestra capital como en los dem&aacute;s departamentos y tambi&eacute;n han pasado invitaciones a diferentes embajadas tanto latinoamericanas como europeas.</span></p>\r\n<p style="text-align: justify;"><span>De esta manera, sabiendo que el turismo est&aacute; decayendo en el &aacute;mbito extranjero, buscan principalmente, que sea el turista nacional quien est&eacute; presente en nuestra ciudad para el mes de agosto.</span></p>\r\n<p style="text-align: justify;"><strong><span>TENEMOS M&Aacute;S TURISTAS QUE EL A&Ntilde;O PASADO</span></strong></p>\r\n<p style="text-align: justify;"><span>A pesar de que la mayor&iacute;a de autoridades est&aacute; de acuerdo con que el turismo en nuestra ciudad ha bajado considerablemente, el Gerente Regional de Comercio Exterior y Turismo,&nbsp;Alfredo Venero, indica que esta informaci&oacute;n no es del todo cierta y muy por el contrario en consideraci&oacute;n con el a&ntilde;o pasado, el incremento de turismo habr&iacute;a subido en un 5%.</span></p>\r\n<p style="text-align: justify;"><span>&ldquo;Es cierto que durante el primer trimestre tuvimos una baja de 16% de turismo por las lluvias, pero esta cifra empez&oacute; a recuperarse a partir de marzo, es cierto que no estamos creciendo como el a&ntilde;o pasado, pero tampoco este n&uacute;mero ha disminuido&rdquo;</span></p>\r\n<p style="text-align: justify;"><strong><span>Recepci&oacute;n de turistas internacionales</span></strong></p>\r\n<p style="text-align: justify;"><strong><span>en Fiestas Patrias</span></strong></p>\r\n<p style="text-align: justify;"><strong><span>&nbsp;</span></strong><strong><span>A&ntilde;o&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Turistas</span></strong></p>\r\n<p style="text-align: justify;"><strong><span>2009&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 14 387</span></strong></p>\r\n<p style="text-align: justify;"><strong><span>2010&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 10 748</span></strong></p>\r\n<p style="text-align: justify;"><strong><span>2011&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 18 855</span></strong></p>\r\n<p style="text-align: justify;"><strong><span>2012&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;19 l&nbsp;43*</span></strong></p>\r\n<p style="text-align: justify;"><strong><span>&nbsp;</span></strong><strong><span>*Cifra que se espera recibir</span></strong></p>\r\n<p style="text-align: justify;"><span style="text-decoration: underline;">(Fuente: Gerencia Regional de Comercio Exterior y Turismo)</span></p>\r\n<p style="text-align: justify;"><strong><span>Crecimiento de turistas (hasta el mes de Mayo)</span></strong></p>\r\n<p style="text-align: justify;"><strong><span>A&ntilde;o&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Nacionales&nbsp;&nbsp; Internacionales</span></strong></p>\r\n<p style="text-align: justify;"><strong><span>2011&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 419 782&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;76 150</span></strong></p>\r\n<p style="text-align: justify;"><strong><span>2012&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 389 129&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 72 505</span></strong></p>\r\n<p style="text-align: justify;"><span style="text-decoration: underline;">(Fuente: Gerencia Regional de Comercio Exterior y Turismo)</span></p>\r\n<p style="text-align: justify;"><span>&nbsp;C</span><strong><span>IFRAS:</span></strong></p>\r\n<p style="text-align: justify;"><strong><span>16 %&nbsp;</span></strong><span>Decreci&oacute; el turismo local en el primer trimestre del a&ntilde;o a ra&iacute;z de las fuertes lluvias que azotaron el departamento durante esos meses, seg&uacute;n&nbsp;la Gerencia&nbsp;Regional&nbsp;de Comercio Exterior y Turismo</span></p>\r\n<p style="text-align: justify;"><span>&nbsp;</span><strong><span>700&nbsp;</span></strong><span>Personas llegaron a Arequipa por el Dakar este a&ntilde;o, para el pr&oacute;ximo, mediante promociones, se espera recibir a 10 mil turistas, seg&uacute;n Rafael Cornejo (Ahora).</span></p>\r\n<p style="text-align: justify;"><span>&nbsp;</span><strong><span>2%&nbsp;</span></strong><span>Baj&oacute; el turismo en el Valle del Colca con respecto al a&ntilde;o pasado, afirm&oacute; Freddy Jim&eacute;nez Barrios, gerente de Autocolca.</span></p>\r\n<p style="text-align: justify;"><span>&nbsp;</span><strong><span>DATO</span></strong></p>\r\n<p style="text-align: justify;"><span>El presidente de la Asociaci&oacute;n de Arequipa de Agencias de Viaje y Turismo (AVIT) Eddy Carpio indic&oacute; que no tienen muchas expectativas por la afluencia de turistas en la regi&oacute;n Arequipa por Fiestas Patrias, por la crisis econ&oacute;mica de Europa, las olimpiadas y otros factores externos.</span></p>', 3, 'turismo, emergencia', '1342003464', '1342004105', 1, 1, 1);
INSERT INTO `blog_articulos` VALUES (11, 1, 'División en Consejo Regional por cancelación de deudas a docentes', 'El consejero por Castilla y presidente de la Comisión de Educación del Consejo Regional de Arequipa, Leopoldo Bellido Téllez, no vio con agrado la propuesta política de la consejera por Camaná, Yamila Osorio Delgado.', '1342013386.jpg', 1, '<p style="text-align: justify;"><span>Para exigir al Gobierno Nacional un cr&eacute;dito suplementario de S/. 109 millones 449 mil 601 con el objetivo de cancelar las deudas a 10 mil 800 docentes en nuestra regi&oacute;n.</span></p>\r\n<p style="text-align: justify;"><span>En la sesi&oacute;n de Consejo Regional, realizada ayer desde las 09:00 horas, Bellido se opuso a la aprobaci&oacute;n de la moci&oacute;n obteniendo el apoyo de varios consejeros, ante la sorpresa de Osorio Delgado, quien aleg&oacute; hasta el &uacute;ltimo momento la necesidad urgente de aprobar la propuesta con el fin de ejercer presi&oacute;n ante el Gobierno para dar celeridad a la soluci&oacute;n del problema magisterial.</span></p>\r\n<p style="text-align: justify;"><span>&nbsp;</span></p>\r\n<p style="text-align: justify;"><strong><span>QUISO MEDIAR.</span></strong></p>\r\n<p style="text-align: justify;"><span>Sin embargo, Leopoldo Bellido fue tajante argumentando que la consejera, por querer figurar, trabaj&oacute; sola sin respetar&nbsp;la Comisi&oacute;n&nbsp;de Educaci&oacute;n, por lo que solicit&oacute; que la propuesta vuelva a comisi&oacute;n para que sea evaluada &ldquo;con mejores criterios de colegiatura&rdquo;.</span></p>\r\n<p style="text-align: justify;"><span>Por su parte el gerente del Gobierno Regional de Arequipa (GRA), Jorge Luis Aguilar, trat&oacute; de mediar en el incidente argumentando que el Gobierno Nacional rechazar&iacute;a el pronunciamiento si no se presentaba los montos detallados y actualizados de las deudas de los profesores, detalle que fue rebatido por Yamila Osorio, quien se&ntilde;al&oacute; que las cifras solicitadas eran informaci&oacute;n oficial de&nbsp;la Gerencia Regional&nbsp;de Educaci&oacute;n.</span></p>\r\n<p style="text-align: justify;"><strong><span>NO FUE APROBADO.</span></strong></p>\r\n<p style="text-align: justify;"><span>&ldquo;Me parece poco razonable que mi propuesta vuelva a comisi&oacute;n para que nuevamente sea puesta a la aprobaci&oacute;n del Consejo Regional con el mismo contenido, la oposici&oacute;n que hacen es de forma mas no de fondo y considero que como consejera estoy en facultad de legislar&rdquo;, argument&oacute; Yamila Osorio, luego de se&ntilde;alar que en el Consejo Regional existe mucha mediocridad.</span></p>\r\n<p style="text-align: justify;"><span>Sus declaraciones molestaron a sus colegas quienes la exhortaron a retractarse. La consejera por Caman&aacute; retir&oacute; lo dicho, pero dej&oacute; en claro su disconformidad en el actuar de sus pares.</span></p>\r\n<p style="text-align: justify;"><span>Sin embargo, la oposici&oacute;n de Bellido termin&oacute; por frustrar la aprobaci&oacute;n del manifiesto ante el asombro de miembros del Sutep (Sindicato &Uacute;nico de Trabajadores por&nbsp;la Educaci&oacute;n&nbsp;del Per&uacute;) y p&uacute;blico en general que presenci&oacute; el impasse que estuvo a punto de salirse de control.</span></p>\r\n<p style="text-align: justify;"><span>&nbsp;</span></p>\r\n<p style="text-align: justify;"><strong><span>Dato:</span></strong></p>\r\n<p style="text-align: justify;"><span>Para Adolfo Quispe, secretario general del Sutep, la actitud de Leopoldo Bellido y de los consejeros que lo apoyaron fue poco consecuente con los intereses de trabajar a favor de los profesores.</span></p>\r\n<p style="text-align: justify;">&nbsp;</p>', 3, 'Consejo regional, docentes', '1342013453', '', 1, 1, 1);
INSERT INTO `blog_articulos` VALUES (12, 1, 'Campeonato Nacional De Enduro Regresa A Arequipa', 'El “ENDURO DE AREQUIPA” Se Correrá Este Próximo Fin De Semana, Los Días 30 De Junio Y 01 De Julio, En Arequipa,Sobre Un Trazado De 40 Km Por Vuelta (3 Vueltas Diarias Para La Categoría “Super Expertos”), En La Zona De Sabandía, Socabaya Y Characato.', '1342084421.jpg', 1, '<p style="text-align: justify;">El campeonato de resistencia del Off Road, sobre un terreno pedregoso, tendr&aacute; tres zonas cronometradas el &ldquo;Cross Test&rdquo;, &ldquo;Enduro Test&rdquo; y el &ldquo;Extreme Test&rdquo;; adem&aacute;s ser&aacute; con dos controles horarios por vuelta.</p>\r\n<p style="text-align: justify;">Como se inform&oacute; anteriormente est&aacute; asegurada la participaci&oacute;n de reconocidos pilotos internacionales del Continente (M&eacute;xico, Chile) y de Per&uacute;.</p>\r\n<p style="text-align: justify;">En motos est&aacute; asegurada la participaci&oacute;n de:</p>\r\n<ul style="text-align: justify;">\r\n<li><strong>Homero D&iacute;az (M&eacute;xico)</strong>, integrante del equipo&nbsp;<strong>Redbull KTM</strong>&nbsp;ser&aacute; sin lugar a dudas el hombre a vencer, considerando el impresionante curr&iacute;culum: 2 veces campe&oacute;n Latinoamericano, 5 veces medalla de Oro en los ISDE, una decena de veces campe&oacute;n nacional de M&eacute;xico, etc.</li>\r\n<li><strong>Israel Jerem&iacute;as</strong>&nbsp;(Honda) de Chile,</li>\r\n<li><strong>Jetro Salazar&nbsp;</strong>(KTM), campe&oacute;n Latinoamericano de Motocross MX2,</li>\r\n<li><strong>Alejandro Bulos</strong>&nbsp;(YAMAHA),</li>\r\n<li><strong>Mart&Iacute;n Camps</strong>&nbsp;de Venezuela (Suzuki),</li>\r\n<li><strong>Felipe R&iacute;os y Carlo Vellutino&nbsp;</strong>(KTM), pilotos &ldquo;Dakarianos&rdquo; 2012.</li>\r\n<li><strong>Eduardo Heinrich</strong>, flamante piloto oficial Honda,</li>\r\n<li><strong>Jos&eacute; Luis Fatule</strong>&nbsp;(KTM),</li>\r\n<li><strong>Eduardo Figari</strong>&nbsp;(Husaberg), actual campe&oacute;n nacional de enduro,</li>\r\n<li>Mauricio Pinillos, C&eacute;sar Pardo, Arturo Paz, Carlos Pun, Rodrigo Majluf, Richard Doolan, Gustavo Troll, Aldo Conetta, entre otros.</li>\r\n</ul>\r\n<p style="text-align: justify;">En cuatrimotos podemos resaltar:</p>\r\n<ul style="text-align: justify;">\r\n<li><strong>Alexis Hern&aacute;ndez</strong>&nbsp;(Honda), en su preparaci&oacute;n para el Dakar 2013,</li>\r\n<li><strong>Ignacio Flores</strong>&nbsp;(Yamaha), participante en Dakar 2012 y participar&aacute; el 2013.</li>\r\n<li><strong>Ra&uacute;l Velit</strong>&nbsp;(Ganador de la primera fecha),</li>\r\n<li><strong>Fernando Loli Arnao</strong>, el actual campe&oacute;n nacional,</li>\r\n<li>Enzo Crapesi (segundo lugar en Asia),</li>\r\n<li>Tayssir Issat Hamideh (grata revelaci&oacute;n en Asia),</li>\r\n<li>Diego Iraola,</li>\r\n<li>Luis Miguel Arrisue&ntilde;o,</li>\r\n<li>Stefano Cesaro, Omar Awad, Carlos Sobenes, entre otros</li>\r\n</ul>\r\n<p style="text-align: justify;"><img title="Despu&eacute;s de 10 a&ntilde;os campeonato nacional de enduro regresa a Arequipa" src="../componentes/com_imagenes/imagenes/1342084588.jpg" alt="Despu&eacute;s de 10 a&ntilde;os campeonato nacional de enduro regresa a Arequipa" height="390" width="650" /></p>\r\n<p style="text-align: justify;">Las competencias de Enduro son espectaculares por la dificultad del trazado de los circuitos, la tenacidad, velocidad, habilidad y el n&uacute;mero de los pilotos participantes. Sin duda qui&eacute;nes sobresalen son los de la Categor&iacute;a &ldquo;Super Expertos&rdquo;, por el tipo de motocicleta, preparaci&oacute;n y por la cantidad de vueltas que dan al trazado, dejando todo de s&iacute; en los terrenos dificultosos. Estamos convencidos que el Enduro viene siendo la competencia motorizada m&aacute;s importante de nuestro pa&iacute;s por todo lo realizado hasta el momento, n&uacute;mero y calidad.</p>\r\n<p style="text-align: justify;">Arequipa, en esta oportunidad, podr&aacute; apreciar los tres tipos de especiales cronometrados, &ldquo;Cross Test&rdquo;, &ldquo;Enduro Test&rdquo;, y como en las competencias mundiales esta vez se incluir&aacute; el &ldquo;Extreme Test&rdquo;, lo que la hace importante por la calidad de terreno que se ha escogido para la ocasi&oacute;n. La Revisi&oacute;n T&eacute;cnica y Parque Cerrado ser&aacute; en el Mall Aventura Plaza en Porongoche de donde partir&aacute;n las motos y cuatrimotos, los dos d&iacute;as de competencia. Adem&aacute;s se espera que el Jurado del Enduro de Arequipa tenga representaci&oacute;n internacional con al menos un oficial acreditado por la FIM.</p>\r\n<p style="text-align: justify;">Est&aacute; competencia cuenta con el auspicio de Honda, KTM (Socopur), Yamaha, Volkswagen Amarok, Husqvarna (Paicasal), Suzuki (Barbacci Motors) y Cadena de Boticas Arc&aacute;ngel. Colaboraci&oacute;n de RedBull, Gatorade, Laboratorios Portugal, Seguros La Positiva, Mall Aventura Plaza Arequipa, Cruz del Sur, Seratra. El apoyo de la Municipalidad Provincial de Arequipa, Comisi&oacute;n de Festejos de Aniversario de Arequipa<strong>, las Municipalidades Distritales de&nbsp;Socabaya,&nbsp;Saband&iacute;a y Characato;&nbsp;</strong>Policia Nacional del Per&uacute;, Cl&iacute;nica Arequipa.</p>\r\n<p style="text-align: justify;">La premiaci&oacute;n de la categor&iacute;a Super Expertos, ser&aacute; el domingo 01 de julio, en ceremonia especial, luego de finalizada la competencia motocicl&iacute;stica.</p>\r\n<p style="text-align: justify;"><a href="http://www.nitro.pe/motos/5190-despues-de-10-anos-campeonato-nacional-de-enduro-regresa-a-arequipa.html" target="_blank">Ver Fuente</a></p>', 2, 'enduro arequipa, campeonato de moto socabaya', '1342084613', '', 1, 1, 1);
INSERT INTO `blog_articulos` VALUES (13, 1, 'Servicio de transporte en Socabaya es pésimo', 'En el distrito de Socabaya, la población se queja por el mal servicio de transporte público urbano.', '1342085998.jpg', 1, '<p>&nbsp;</p>\r\n<p><img style="margin: 5px auto; display: block;" title="Servicio p&eacute;simo en socabaya" src="../componentes/com_imagenes/imagenes/1342085998.jpg" alt="Servicio p&eacute;simo en socabaya" height="315" width="421" /></p>\r\n<p style="text-align: justify;"><span>Sobre todo en las dos lineas principales que se dirigen hacia La Mansi&oacute;n II; por lo que los vecinos piden el respaldo del Ministerio de Transportes y la Polic&iacute;a Nacional, a fin de que les solucionen su problem&aacute;tica; as&iacute; lo dio a conocer Dar&iacute;o Quispe, presidente del Pueblo Joven La Mansi&oacute;n II.</span></p>\r\n<p style="text-align: justify;"><span><a href="http://diariocorreo.pe/nota/99507/servicio-de-transporte-en-socabaya-es-pesimo/" target="_blank">Ver Fuente</a></span></p>', 2, 'transporte urbano', '1342086123', '1342086371', 1, 1, 1);
INSERT INTO `blog_articulos` VALUES (14, 1, 'Poblador de La Mansión se encadena exigiendo obras de agua y desagüe', 'El 9 de Julio en el parque 1 de la Mansión en Socabaya, una persona fue encadenada a un poste por parte de los pobladores de este sector, quienes exigen replanteamiento de las obras de agua y desague. ', '1342087022.jpg', 1, '<p style="text-align: justify;"><span style="text-decoration: underline;">Diario Correo:</span></p>\r\n<p style="text-align: justify;"><span>El presidente del pueblo joven La Mansi&oacute;n en el distrito de <strong>Socabaya</strong>, Dario Quispe, se encaden&oacute; a las rejas de una losa deportiva, en protesta del lento abance de obras de agua y desag&uuml;e en la zona. Asegura que desde el 2011 las obras est&aacute;n estancadas.&nbsp;</span><br /><br /><span>En la Manci&oacute;n II son 10 mil habitantes los que sufren por la falta de estos servicios.</span><br /><br /><span>Por su parte, el alcalde del distrito, <strong>Wilmer Mendoza</strong> asegur&oacute; que los vecinos solo quieren mayor participaci&oacute;n en las obras.</span></p>\r\n<p style="text-align: justify;"><span style="text-decoration: underline;">Radio Melodia:</span></p>\r\n<p style="text-align: justify;"><span>Adem&aacute;s se&ntilde;alaron que existen varias irregularidades en la instalaci&oacute;n de tubos en la manzana R de la Mansi&oacute;n, a quienes pidieron S/. 170 mas 30 bolsas cemento&nbsp;</span><br /><br /><span>Hasta el lugar lleg&oacute; el alcalde del distrito, Wuilber Mendoza Aparici&oacute; quien se comprometi&oacute; a dialogar ma&ntilde;ana con los pobladores y especialistas de la obra, adem&aacute;s de funcionario del gobierno regional, que financia el trabajo.&nbsp;</span></p>\r\n<p style="text-align: justify;"><span><br /></span></p>\r\n<p style="text-align: justify;"><a href="http://diariocorreo.pe/nota/99279/poblador-de-la-mansion-se-encadena-exigiendo-obras-de-agua-y-desague/" target="_blank">Ver Fuente Diario Correo</a>&nbsp;y <a href="http://www.radiomelodia.com.pe/portal/ultimasnoticias.php?subaction=showfull&amp;id=1341855623" target="_blank">Ver Fuente Radio Melodia</a></p>', 2, 'la mansion, obras de agua, encadeno', '1342087149', '1342087535', 1, 1, 1);
INSERT INTO `blog_articulos` VALUES (15, 1, 'Pasajero quedó herido al subir a la combi que se dió a la fuga', 'Marco Mendoza Cala (35) se disponía, como todos los días a las 7:00 h, a ocupar la combi de la línea 3 de Octubre.', '1342092502.jpg', 1, '<p style="text-align: justify;"><span>A la altura de la avenida La Campi&ntilde;a, del distrito de Socabaya, cuando se dispon&iacute;a a subir, la combi arranc&oacute; intempestivamente, arroj&aacute;ndolo a la pista y dej&aacute;ndolo herido.</span><br /><br /><span>La combi de plaza V1A-735 se di&oacute; a la fuga sin intenciones de auxiliarlo. El accidentado acudi&oacute; hasta la sala de emergencias del hospital Honorio Delgado, donde le detectaron fractura la clav&iacute;cula izquierda y policontuso.</span></p>\r\n<p style="text-align: justify;"><a href="http://diariocorreo.pe/nota/99679/pasajero-quedo-herido-al-subir-a-la-combi-que-se-dio-a-la-fuga/" target="_blank">Ver Fuente</a></p>', 2, 'pasajero herido, 3 de octubre, campiña', '1342092564', '', 1, 1, 1);
INSERT INTO `blog_articulos` VALUES (16, 1, 'Paolo Guerrero pasará los exámenes médicos y luego será presentado en el Corinthians', 'Si los resultados son buenos, el delantero será jugador del ‘Timao’”, señaló la página web del club.', '1342093995.jpg', 1, '<p><img style="margin: 5px auto; display: block;" title="Paolo Guerrero pasar&aacute; a Corinthians" src="../componentes/com_imagenes/imagenes/1342093995.jpg" alt="Paolo Guerrero pasar&aacute; a Corinthians" height="338" width="600" /></p>\r\n<p style="text-align: justify;">Paolo Guerrero est&aacute; a muy poco de mosrtar su f&uacute;tbol en el campe&oacute;n de la Copa Libertadores. Seg&uacute;n public&oacute; esta ma&ntilde;ana la p&aacute;gina web del club, el &lsquo;<strong>Depredador</strong>&rsquo; pasar&aacute; las pruebas m&eacute;dicas durante el transcurso del d&iacute;a y, si los resultados son los esperados, ser&aacute; presentado con bombos y platillos.</p>\r\n<p style="text-align: justify;">&ldquo;Paolo Guerrero ser&aacute; sometido a una bater&iacute;a de pruebas m&eacute;dicas. Si todo sale bien, el delantero se quedar&aacute; en el club paulista&rdquo;, aseguraron.</p>\r\n<p style="text-align: justify;">Cabe mencionar, que el ex Bayern Munich no ha querido declarar a la prensa brasile&ntilde;a. Es que sabe que su verdadera chamba consiste en hablar solo con goles.</p>\r\n<p style="text-align: justify;">&nbsp;</p>\r\n<p style="text-align: justify;"><a href="http://depor.pe/futbol-peruano/815880/noticia-unas-horas-paolo-guerrero-pasara-examenes-medicos-y-luego-presentado-corinthians" target="_blank">Ver Fuente</a></p>', 8, 'paolo guerrero, Corinthians', '1342094128', '1342094226', 1, 1, 1);
INSERT INTO `blog_articulos` VALUES (17, 1, 'El fundador de Megaupload celebra el rechazo de ACTA y asegura que la plataforma volverá', 'El fundador de Megaupload, Kim Schmidt Dotcom, ha celebrado a través de su cuenta de Twitter el rechazo del Parlamento Europeo al Acuerdo multilateral Comercial contra la Falsificación.', '1342098628.jpg', 1, '<div><img style="margin: 0px auto; display: block;" title="El fundador de Megaupload celebra el rechazo de ACTA y asegura que la plataforma volver&aacute;" src="../componentes/com_imagenes/imagenes/1342098628.jpg" alt="El fundador de Megaupload celebra el rechazo de ACTA y asegura que la plataforma volver&aacute;" height="273" width="600" /></div>\r\n<ul>\r\n<li>Dotcom aplaude en Twitter el rechazo de la Euroc&aacute;mara al acuerdo ACTA.</li>\r\n<li>Ha asegurado que Megaupload volver&aacute; "m&aacute;s grande, mejor y m&aacute;s r&aacute;pida" y que iniciativas como omo SOPA y PIPA "est&aacute;n muertas".</li>\r\n<li>Se encuentra en libertad bajo fianza y la espera de su extradici&oacute;n a Estados Unidos, donde se le acusa de violar los derechos de autor y de blanquear dinero.</li>\r\n</ul>\r\n<p>El fundador de Megaupload ha celebrado que la Euroc&aacute;mara tumbara este mi&eacute;rcoles, con 478 votos en contra, 39 a favor y 165 abstenciones, el acuerdo internacional ACTA al plantear dudas sobre su efectividad y sobre el respeto de los derechos de los usuarios de Internet.</p>\r\n<p>Adem&aacute;s, Dotcom, que se encuentra actualmente en libertad bajo fianza, ha considerado que iniciativas impulsadas en Estados Unidos como SOPA y PIPA "est&aacute;n muertas" y que lo &uacute;nico que volver&aacute; ser&aacute; Megaupload.</p>\r\n<p>"SOPA est&aacute; muerta. PIPA est&aacute; muerta. ACTA est&aacute; muerta. MEGA volver&aacute;. M&aacute;s grande. Mejor. M&aacute;s r&aacute;pido. Gratuito y protegido de los ataques. Evoluci&oacute;n!", ha asegurado Dotcom a trav&eacute;s de la red social.</p>\r\n<p>Dotcom est&aacute; a la espera de su extradici&oacute;n en agosto a Estados Unidos, donde se le acusa de violar los derechos de autor y realizar blanqueo de dinero a trav&eacute;s de Megaupload, a la que se le atribuye haber originado m&aacute;s de 500 millones de d&oacute;lares en p&eacute;rdidas a la industria del cine y de la m&uacute;sica, as&iacute; como de obtener unos beneficios de 175 millones de d&oacute;lares.</p>\r\n<p>La Polic&iacute;a neozelandesa entr&oacute; el pasado 20 de enero a la mansi&oacute;n de Dotcom, dentro de un operativo internacional contra la pirater&iacute;a inform&aacute;tica, que supuso el cierre del portal Megaupload, el embargo de sus bienes y otras detenciones en el pa&iacute;s, adem&aacute;s de en Europa.</p>\r\n<p>El Alto Tribunal de Nueva Zelanda detect&oacute; posteriormente diversas irregularidades en el registro policial de la mansi&oacute;n de Dotcom, y declar&oacute; ilegal la confiscaci&oacute;n de las copias de sus discos duros.</p>\r\n<p>&nbsp;</p>\r\n<p>Fuente: <a href="http://www.20minutos.es/noticia/1531650/0/fundador-mgaupload/celebra/acta/" target="_blank">20munutos.es</a></p>', 7, 'megaupload, Schmidt Dotcom', '1342099269', '', 1, 1, 1);
INSERT INTO `blog_articulos` VALUES (18, 1, 'virgen de los remedios', 'jejejjeje', '', 1, '<p>descripcion completa aqui</p>', 3, 'xth, jeje', '1345514610', '', 1, 1, 1);
INSERT INTO `blog_articulos` VALUES (19, 1, 'otros artículos de prueba', 'descripción del articulo de prueba 1', '', 1, '<p>jejeje</p>', 3, '', '1345518178', '1345518208', 1, 1, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `blog_categorias`
-- 

CREATE TABLE `blog_categorias` (
  `cat_id` int(11) NOT NULL auto_increment,
  `cat_nombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `cat_descripcion` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cat_activado` int(1) NOT NULL,
  PRIMARY KEY  (`cat_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=9 ;

-- 
-- Volcar la base de datos para la tabla `blog_categorias`
-- 

INSERT INTO `blog_categorias` VALUES (1, 'Socabaya', 'Historia, Limites, Himno, Biografia, Datos Importantes.', 1);
INSERT INTO `blog_categorias` VALUES (2, 'Noticias Socabaya', 'Noticias Sobre Socabaya', 1);
INSERT INTO `blog_categorias` VALUES (3, 'Noticias de Arequipa', 'Noticias de Arequipa', 1);
INSERT INTO `blog_categorias` VALUES (4, 'Noticias de Perú', '', 1);
INSERT INTO `blog_categorias` VALUES (5, 'Noticias Internacionales', '', 1);
INSERT INTO `blog_categorias` VALUES (6, 'Grupo XtH', '', 1);
INSERT INTO `blog_categorias` VALUES (7, 'Tecnología ', '', 1);
INSERT INTO `blog_categorias` VALUES (8, 'Deportes', '', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `blog_comentarios`
-- 

CREATE TABLE `blog_comentarios` (
  `comen_id` int(11) NOT NULL auto_increment,
  `comen_articulo` int(11) NOT NULL,
  `comen_comentario` varchar(250) collate utf8_spanish_ci NOT NULL,
  `comen_fcreado` varchar(11) collate utf8_spanish_ci NOT NULL,
  `comen_faprobado` varchar(11) collate utf8_spanish_ci NOT NULL,
  `comen_usuario` int(11) NOT NULL,
  `comen_aprobado` int(1) NOT NULL,
  PRIMARY KEY  (`comen_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `blog_comentarios`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `blog_visitas`
-- 

CREATE TABLE `blog_visitas` (
  `id` int(11) NOT NULL auto_increment,
  `IP` varchar(15) collate utf8_spanish_ci default NULL,
  `hora` varchar(8) collate utf8_spanish_ci default NULL,
  `articulo` varchar(11) collate utf8_spanish_ci default NULL,
  `segundos` varchar(30) collate utf8_spanish_ci default NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=31 ;

-- 
-- Volcar la base de datos para la tabla `blog_visitas`
-- 

INSERT INTO `blog_visitas` VALUES (1, '127.0.0.1', '05:30:17', '1', '1341916217');
INSERT INTO `blog_visitas` VALUES (2, '127.0.0.1', '01:40:44', '1', '1341945644');
INSERT INTO `blog_visitas` VALUES (3, '127.0.0.1', '01:53:45', '2', '1341946425');
INSERT INTO `blog_visitas` VALUES (4, '127.0.0.1', '02:05:51', '4', '1341947151');
INSERT INTO `blog_visitas` VALUES (5, '127.0.0.1', '02:08:25', '5', '1341947305');
INSERT INTO `blog_visitas` VALUES (6, '127.0.0.1', '02:12:16', '6', '1341947536');
INSERT INTO `blog_visitas` VALUES (7, '127.0.0.1', '05:51:28', '10', '1342003888');
INSERT INTO `blog_visitas` VALUES (8, '127.0.0.1', '09:10:02', '11', '1342015802');
INSERT INTO `blog_visitas` VALUES (9, '127.0.0.1', '04:32:17', '12', '1342085537');
INSERT INTO `blog_visitas` VALUES (10, '127.0.0.1', '04:45:51', '13', '1342086351');
INSERT INTO `blog_visitas` VALUES (11, '127.0.0.1', '04:59:52', '14', '1342087192');
INSERT INTO `blog_visitas` VALUES (12, '127.0.0.1', '05:08:12', '9', '1342087692');
INSERT INTO `blog_visitas` VALUES (13, '127.0.0.1', '05:08:52', '6', '1342087732');
INSERT INTO `blog_visitas` VALUES (14, '127.0.0.1', '06:21:25', '11', '1342092085');
INSERT INTO `blog_visitas` VALUES (15, '127.0.0.1', '06:55:55', '16', '1342094155');
INSERT INTO `blog_visitas` VALUES (16, '127.0.0.1', '08:22:02', '17', '1342099322');
INSERT INTO `blog_visitas` VALUES (17, '127.0.0.1', '05:00:54', '16', '1342130454');
INSERT INTO `blog_visitas` VALUES (18, '127.0.0.1', '03:41:00', '9', '1342428060');
INSERT INTO `blog_visitas` VALUES (19, '127.0.0.1', '05:46:40', '15', '1342435600');
INSERT INTO `blog_visitas` VALUES (20, '127.0.0.1', '12:52:42', '17', '1342979562');
INSERT INTO `blog_visitas` VALUES (21, '127.0.0.1', '12:00:11', '17', '1343322011');
INSERT INTO `blog_visitas` VALUES (22, '127.0.0.1', '01:03:15', '11', '1343325795');
INSERT INTO `blog_visitas` VALUES (23, '127.0.0.1', '10:26:40', '8', '1346772400');
INSERT INTO `blog_visitas` VALUES (24, '127.0.0.1', '09:22:21', '16', '1347027741');
INSERT INTO `blog_visitas` VALUES (25, '127.0.0.1', '10:06:26', '19', '1347030386');
INSERT INTO `blog_visitas` VALUES (26, '127.0.0.1', '08:21:33', '19', '1347931293');
INSERT INTO `blog_visitas` VALUES (27, '127.0.0.1', '01:22:33', '19', '1352053353');
INSERT INTO `blog_visitas` VALUES (28, '127.0.0.1', '09:04:00', '17', '1353031440');
INSERT INTO `blog_visitas` VALUES (29, '127.0.0.1', '03:53:40', '13', '1353704020');
INSERT INTO `blog_visitas` VALUES (30, '127.0.0.1', '08:10:36', '16', '1357132236');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cl_clientes`
-- 

CREATE TABLE `cl_clientes` (
  `cl_id` int(11) NOT NULL auto_increment,
  `cl_nombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `cl_imagen` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cl_descipcion` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cl_web` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cl_empresa` varchar(100) collate utf8_spanish_ci NOT NULL,
  `cl_activado` int(1) NOT NULL,
  PRIMARY KEY  (`cl_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=9 ;

-- 
-- Volcar la base de datos para la tabla `cl_clientes`
-- 

INSERT INTO `cl_clientes` VALUES (1, 'Nuez de la India Perú', '1316356670.jpg', '', 'http://www.nuezdelaindiaperu.com/', 'Lagc Perú', 1);
INSERT INTO `cl_clientes` VALUES (2, 'Extrem Callalli', '1316356704.jpg', '', 'http://www.extremcallalli.com/', 'Lagc Perú', 1);
INSERT INTO `cl_clientes` VALUES (3, 'Laboratorio Llerena', '1316356800.jpg', '', 'http://www.labllerenaames.com/', 'Lagc Perú', 1);
INSERT INTO `cl_clientes` VALUES (4, 'Perú Rock and Pop', '1316356832.jpg', '', 'http://www.perurockandpop.com/', 'Lagc Perú', 1);
INSERT INTO `cl_clientes` VALUES (5, 'Smart Soft Perú', '1316356868.jpg', '', 'http://smartsoftperu.com/', 'Smart Soft Perú', 1);
INSERT INTO `cl_clientes` VALUES (6, 'Por Tu Hermana', '1316356895.jpg', '', 'http://www.portuhermana.com/', 'Lagc Perú', 1);
INSERT INTO `cl_clientes` VALUES (7, 'Greys Importaciones', '1316357039.jpg', '', '', 'Lagc Perú', 1);
INSERT INTO `cl_clientes` VALUES (8, 'Corasil', '1318351196.jpg', '', 'http://corasil.com/', 'Grupo Innova Perú', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `componentes`
-- 

CREATE TABLE `componentes` (
  `id_com` int(11) NOT NULL auto_increment,
  `url` varchar(100) collate utf8_spanish_ci NOT NULL,
  `archivo` varchar(100) collate utf8_spanish_ci NOT NULL,
  `campobd` varchar(100) collate utf8_spanish_ci NOT NULL,
  `campoid` varchar(100) collate utf8_spanish_ci NOT NULL,
  `campotitulo` varchar(100) collate utf8_spanish_ci NOT NULL,
  `campopalabras` varchar(100) collate utf8_spanish_ci NOT NULL,
  `campodescrip` varchar(100) collate utf8_spanish_ci NOT NULL,
  `rutaimagen` varchar(200) collate utf8_spanish_ci NOT NULL,
  `campoimagen` varchar(100) collate utf8_spanish_ci NOT NULL,
  `nombre` varchar(200) collate utf8_spanish_ci NOT NULL,
  `descripcion` text collate utf8_spanish_ci NOT NULL,
  `email` varchar(255) collate utf8_spanish_ci NOT NULL default 'luisgago@lagc-peru.com',
  `fecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `licencia` varchar(19) collate utf8_spanish_ci NOT NULL,
  `visible` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id_com`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=25 ;

-- 
-- Volcar la base de datos para la tabla `componentes`
-- 

INSERT INTO `componentes` VALUES (1, 'com_configuracion', 'class.lg', '', '', '', '', '', '', '', 'Configuracion', 'configuracion de todo el sitio', 'luisgago@lagc-peru.com', '1297124178', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (2, 'com_usuarios', 'inicio', 'usuarios', 'id', 'usuario', 'apellidos', 'apellidos', '', '', 'Usuarios', 'Configura las cuentas de usuarios que podran acceder a lagc.', 'luisgago@lagc-peru.com', '1297122217', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (3, 'com_componentes', 'inicio', 'componentes', 'id_com', '', '', '', '', '', 'Componentes', 'Crear y Editar Componentes', 'luisgago@lagc-peru.com', '1297124189', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (4, 'com_sistema', 'class.login', '', '', '', '', '', '', '', 'Sistemas', 'Configuracion Global de Lagc', 'luisgago@lagc-peru.com', '1297124210', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (5, 'com_inicio', 'index', '', '', '', '', '', '', '', 'Inicio', 'Inicio del Administrador', 'luisgago@lagc-peru.com', '1297124224', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (6, 'com_modulos', 'inicio', '', '', '', '', '', '', '', 'Modulos', 'colocarse en un lugar donde mostrara el contenido', 'luisgago@lagc-peru.com', '1297124217', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (7, 'com_menu', 'inicio', '', '', '', '', '', '', '', 'Menu', '', 'luisgago@lagc-peru.com', '1301876879', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (8, 'com_imagenes', 'inicio', '', '', '', '', '', '', '', 'Imagenes', '', 'luisgago@lagc-peru.com', '1316996906', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (9, 'com_idiomas', 'inicio', '', '', '', '', '', '', '', 'Idiomas', '', 'luisgago@lagc-peru.com', '1316996997', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (10, 'com_plantillas', 'inicio', '', '', '', '', '', '', '', 'Plantillas', '', 'luisgago@lagc-peru.com', '1316997038', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (11, 'com_contenidos', 'inicio', 'contenidos', 'cont_id', 'cont_titulo', 'palabras', 'cont_resumen', '', '', 'Contenidos', 'Crea contenidos y insertalos en el sitio. Consta de un editor similar a word.', 'luisgago@lagc-peru.com', '1297124231', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (12, 'com_programacion', 'inicio', 'prog_archivos', 'id_cont', 'nombre_cont', 'nombre_cont', 'nombre_cont', '', '', 'Programación', 'Archivos con codigo', 'luisgago@lagc-peru.com', '1297124241', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (13, 'com_galeria', 'inicio', 'fotos_album', 'id_gal', 'titulo', 'descripcion', 'descripcion', '', '', 'Galeria', 'Galerias de Fotos', 'luisgago@lagc-peru.com', '1297179535', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (14, 'com_avisos', 'inicio', 'av_avisos', 'id', 'titulo', '', 'resumen', '', '', 'Avisos', '', 'luisgago@lagc-peru.com', '1299784933', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (15, 'com_videos', 'inicio', 'video_videos', 'vi_id', 'vi_titulo', 'vi_tags', 'vi_descripcion', '', '', 'Videos', '', 'luisgago@lagc-peru.com', '1299794636', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (16, 'com_whois', 'inicio', '', '', '', '', '', '', '', 'whois', '', 'luisgago@lagc-peru.com', '1301768174', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (17, 'com_blog', 'inicio', 'blog_articulos', 'b_id', 'b_titulo', 'b_palabras', 'b_resumen', 'componentes/com_imagenes/thumbnails/', 'b_img', 'Blog', '', 'luisgago@lagc-peru.com', '1310739467', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (18, 'com_clientes', 'inicio', 'cl_clientes', 'cl_id', 'cl_nombre', 'cl_empresa', 'cl_nombre', '', '', 'Clientes', '', 'luisgago@lagc-peru.com', '1312835840', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (19, 'com_catalogodeltron', 'inicio', 'cp_productos', 'cp_pid', 'cp_pcodigo', 'cp_pdescripcion', 'cp_pdescripcion', '', '', 'Catalogo de Productos', '', 'luisgago@lagc-peru.com', '1313160728', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (20, 'com_productos', 'inicio', 'pro_productos', 'p_id', 'p_titulo', 'p_contenido1', 'p_titulo', '', '', 'Productos', '', 'luisgago@lagc-peru.com', '1318632785', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (21, 'com_wilss', 'inicio', '', '', '', '', '', '', '', 'Catalogo Wilss', '', 'luisgago@lagc-peru.com', '1332316951', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (22, 'com_radio', 'inicio', '', '', '', '', '', '', '', 'Radio XtH', 'Transmisión de radio XtH Desde Socabaya > Arequipa > Perú / Ful música :)', 'luisgago@lagc-peru.com', '1333025241', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (23, 'com_enlace', 'inicio', 'url_enlaces', 'url_id', 'url_nombre', 'url_nombre', 'url_descripcion', '', '', 'Enlaces', '', 'lusigago@lagc-peru.com', '1333756579', '9470-5281-5767-1470', 1);
INSERT INTO `componentes` VALUES (24, 'com_musica', 'inicio', '', '', '', '', '', '', '', 'Musica', '', 'luisgago@lagc-peru.com', '1349292643', '9470-5281-5767-1470', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `contenidos`
-- 

CREATE TABLE `contenidos` (
  `cont_id` int(11) NOT NULL auto_increment,
  `cont_titulo` varchar(300) collate utf8_spanish_ci NOT NULL,
  `cont_titulo_activo` int(1) NOT NULL,
  `cont_resumen` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cont_resumen_activar` int(1) NOT NULL,
  `cont_contenido` longtext collate utf8_spanish_ci NOT NULL,
  `palabras` varchar(200) collate utf8_spanish_ci NOT NULL,
  `cont_fecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `cont_fechamodi` varchar(11) collate utf8_spanish_ci NOT NULL,
  `activo` int(1) NOT NULL,
  PRIMARY KEY  (`cont_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `contenidos`
-- 

INSERT INTO `contenidos` VALUES (1, 'Quienes Somos', 1, '', 1, '<p style="text-align: justify;">Bienvenidos a&nbsp;<strong>Portuhermana.com</strong>, esta p&aacute;gina est&aacute; dedicada a todos los amigos e integrantes de este grupo que se encuentran lejos.</p>\r\n<p style="text-align: justify;">Como bien se preguntaran por que el nombre entonces explicaremos ese primer punto. El Nombre de nuestra p&aacute;gina se debe a el nombre del grupo que pertenecemos "<strong>Por Tu Hermana</strong>" o para algunos solamente "<strong>XtH</strong>" naci&oacute; a principio del&nbsp;<strong>2005</strong>&nbsp;por los primeros integrantes molestando a otro integrante &ldquo;por su hermana&rdquo; que tenia buena presencia y muy simp&aacute;tica ya que segu&iacute;amos molest&aacute;ndolo todos los d&iacute;as y aun no ten&iacute;amos un nombre de grupo que sea original. Entonces decidimos llamarlo al grupo "<strong>Por Tu Hermana</strong>".</p>\r\n<p style="text-align: justify;">Y as&iacute; desde ese momento hasta el d&iacute;a de hoy todos los integrantes nos hacemos llamar de esta forma 100pre respetando al&nbsp;<strong>grupo</strong>&nbsp;y al&nbsp;<strong>barrio</strong>&nbsp;no peleando si no con actos que demuestren que no somos un grupo de pandillitas o malogrados ni tampoco drogados o borrachitos.</p>\r\n<p style="text-align: justify;">Participamos en los campeonatos que se apertura en el barrio y somos muy bienvenidos por todos tenemos mucha gente mayor que nos apoya por nuestro gran esfuerzo y empe&ntilde;o cuando al deporte se trata.</p>\r\n<p style="text-align: justify;">Cuando participamos en eventos como adobadas lo hacemos en&nbsp;<strong>grupo</strong>&nbsp;y bien unidos para sacar fondos para nuestras camisetas o pelotas.</p>\r\n<p style="text-align: justify;">Si decidimos&nbsp;<strong>salir de paseo</strong>&nbsp;salimos todos juntos y regresamos los que partimos no por nada nos &nbsp;hacemos llamar grupo y por cierto bien unido.</p>\r\n<p style="text-align: justify;">Y no solamente en&nbsp;<strong>Socabaya</strong>&nbsp;nos conocen si no en algunos distritos de&nbsp;<strong>Arequipa</strong>&nbsp;por que a veces salimos a jugar a esos distritos ganamos muchos amigos y los invitamos a Socabaya para que conozcan.</p>\r\n<p style="text-align: justify;">En &eacute;poca de lluvia y queremos jugar un partidito todos nos juntamos bajamos escoba recogedores para limpiar el agua acumulada en la cancha.</p>\r\n<p style="text-align: justify;">&nbsp;</p>\r\n<p style="text-align: justify;">&nbsp;</p>\r\n<p style="text-align: justify;">Ya les pudimos comentar algo de lo que es "<strong>Por Tu Herman</strong>a" que les pareci&oacute; te invito a registrarte en esta p&aacute;gina para que te informes mas de los eventos que vallamos a realizar y nos conozcas mucho mas ya que todos est&aacute;n invitados a pertenecer al grupo.</p>\r\n<p style="text-align: justify;">Cualquier pregunta o aporte lo podr&iacute;an hacer desde el men&uacute; en&nbsp;<em><strong>Cont&aacute;cteno</strong></em>s :)</p>\r\n<p style="text-align: justify;">&nbsp;</p>', 'socabaya, deporte, arequipa, esfuerzo, amistad, grupo, portuhermana, xth, 2005', '1311786755', '1336213582', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cp_grupo`
-- 

CREATE TABLE `cp_grupo` (
  `cp_gid` int(11) NOT NULL auto_increment,
  `cp_gtipo` int(11) NOT NULL,
  `cp_gnombre` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_gactivo` int(1) NOT NULL default '1',
  PRIMARY KEY  (`cp_gid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=14 ;

-- 
-- Volcar la base de datos para la tabla `cp_grupo`
-- 

INSERT INTO `cp_grupo` VALUES (1, 1, 'Accesorios / miscelaneos', 1);
INSERT INTO `cp_grupo` VALUES (2, 1, 'Cases (cajas)', 1);
INSERT INTO `cp_grupo` VALUES (3, 1, 'Cdrom / dvd drives', 1);
INSERT INTO `cp_grupo` VALUES (4, 1, 'Computadoras pc', 1);
INSERT INTO `cp_grupo` VALUES (5, 1, 'Discos duros internos', 1);
INSERT INTO `cp_grupo` VALUES (6, 1, 'Fuentes estabilizadores ups', 1);
INSERT INTO `cp_grupo` VALUES (7, 2, 'Cpus (microprocesadores)', 1);
INSERT INTO `cp_grupo` VALUES (8, 2, 'Discos duros internos', 1);
INSERT INTO `cp_grupo` VALUES (9, 2, 'Motherboards (placas base)', 1);
INSERT INTO `cp_grupo` VALUES (10, 2, 'Multimedia, productos', 1);
INSERT INTO `cp_grupo` VALUES (11, 2, 'Tarjetas de video / dispositivos de video', 1);
INSERT INTO `cp_grupo` VALUES (12, 3, 'Suministros', 1);
INSERT INTO `cp_grupo` VALUES (13, 4, 'Garantia extendida', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cp_imagenes`
-- 

CREATE TABLE `cp_imagenes` (
  `cp_imgid` int(11) NOT NULL auto_increment,
  `cp_imgproduc` int(11) NOT NULL,
  `cp_imgtitulo` varchar(100) collate utf8_spanish_ci NOT NULL,
  `cp_imgimg` varchar(20) collate utf8_spanish_ci NOT NULL,
  `cp_imgdescripcion` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_imgfecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `cp_imgactivo` int(1) NOT NULL,
  PRIMARY KEY  (`cp_imgid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `cp_imagenes`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cp_linea`
-- 

CREATE TABLE `cp_linea` (
  `cp_tid` int(11) NOT NULL auto_increment,
  `cp_tnombre` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_tmarca` int(11) NOT NULL,
  `cp_tactivo` int(1) NOT NULL,
  PRIMARY KEY  (`cp_tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=9 ;

-- 
-- Volcar la base de datos para la tabla `cp_linea`
-- 

INSERT INTO `cp_linea` VALUES (1, 'Muebles para computadoras', 1, 1);
INSERT INTO `cp_linea` VALUES (2, 'tipo 2', 1, 1);
INSERT INTO `cp_linea` VALUES (3, 'Ups', 1, 1);
INSERT INTO `cp_linea` VALUES (4, 'Accesorios', 1, 1);
INSERT INTO `cp_linea` VALUES (5, 'Garantia extendida', 6, 1);
INSERT INTO `cp_linea` VALUES (6, 'Disco duro ide serial ata', 6, 1);
INSERT INTO `cp_linea` VALUES (7, 'Disco duro p/nb sata', 6, 1);
INSERT INTO `cp_linea` VALUES (8, 'Mb c2d s775 1333fsb', 5, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cp_locales`
-- 

CREATE TABLE `cp_locales` (
  `cp_lid` int(11) NOT NULL auto_increment,
  `cp_lnombre` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_ldireccion` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_ltelefonos` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_lactivado` int(1) NOT NULL,
  PRIMARY KEY  (`cp_lid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=13 ;

-- 
-- Volcar la base de datos para la tabla `cp_locales`
-- 

INSERT INTO `cp_locales` VALUES (1, 'Lima', 'los olivos 103 a-2', '054-12345652|01-19893242343', 1);
INSERT INTO `cp_locales` VALUES (6, 'Moquegua', 'mercaderes 105', '054-9523434|054-98345454|93543545', 1);
INSERT INTO `cp_locales` VALUES (12, 'Tacna', '', '|666|77777', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cp_marcas`
-- 

CREATE TABLE `cp_marcas` (
  `cp_mid` int(11) NOT NULL auto_increment,
  `cp_mnombre` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_mimagen` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_mactivo` int(1) NOT NULL,
  PRIMARY KEY  (`cp_mid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=8 ;

-- 
-- Volcar la base de datos para la tabla `cp_marcas`
-- 

INSERT INTO `cp_marcas` VALUES (1, 'Compaq 2', '1314718490.jpg', 1);
INSERT INTO `cp_marcas` VALUES (2, 'Verbatim', '1314718824.jpg', 1);
INSERT INTO `cp_marcas` VALUES (3, 'xexor', '1314718893.jpg', 1);
INSERT INTO `cp_marcas` VALUES (4, 'nueva marca', '1314910215.jpg', 1);
INSERT INTO `cp_marcas` VALUES (5, 'GIGABYTE', '1314976345.jpg', 1);
INSERT INTO `cp_marcas` VALUES (6, 'TOSHIBA', '1314976412.jpg', 1);
INSERT INTO `cp_marcas` VALUES (7, 'nuevo grupo xth', '1330006174.jpg', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cp_productos`
-- 

CREATE TABLE `cp_productos` (
  `cp_pid` int(11) NOT NULL auto_increment,
  `cp_pusuario` int(11) NOT NULL,
  `cp_ptipo` int(5) NOT NULL,
  `cp_pmarca` int(11) NOT NULL,
  `cp_plinea` int(11) NOT NULL,
  `cp_pcodigo` varchar(100) collate utf8_spanish_ci NOT NULL,
  `cp_pdescripcion` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_ptipopro` int(11) NOT NULL,
  `cp_ptipoope` int(11) NOT NULL,
  `cp_plocales` text collate utf8_spanish_ci NOT NULL,
  `cp_pcomentario` varchar(255) collate utf8_spanish_ci NOT NULL,
  `cp_pcaracteristicas` text collate utf8_spanish_ci NOT NULL,
  `cp_pfecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `cp_pmodificado` varchar(11) collate utf8_spanish_ci NOT NULL,
  `cp_pactivado` int(1) NOT NULL,
  PRIMARY KEY  (`cp_pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=4 ;

-- 
-- Volcar la base de datos para la tabla `cp_productos`
-- 

INSERT INTO `cp_productos` VALUES (1, 1, 6, 5, 8, '4534534534', 'dfgfdgdfgfd', 1, 1, '1>334|6>97|12>45645|', '', '<p>fghghgf<strong>ghjghj</strong>jghjghjghj<em>hgjghj</em>ghjgh<span style="text-decoration: underline;">jhgjghjghjhg</span>j</p>', '1330007260', '', 1);
INSERT INTO `cp_productos` VALUES (2, 1, 10, 1, 2, '453453453466', 'dfgdfgdf', 1, 1, '1>|6>|12>|', '', '', '1330007669', '1330007809', 1);
INSERT INTO `cp_productos` VALUES (3, 1, 12, 6, 5, '123456', 'dfgdfgdfgdfgfd gdf dfddddd  xth', 1, 1, '1>|6>|12>|', '', '', '1330009696', '', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `fotos_album`
-- 

CREATE TABLE `fotos_album` (
  `id_gal` int(11) NOT NULL auto_increment,
  `titulo` varchar(100) collate utf8_spanish_ci NOT NULL,
  `activar` int(1) NOT NULL,
  `descripcion` varchar(200) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id_gal`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `fotos_album`
-- 

INSERT INTO `fotos_album` VALUES (1, 'Primer Galería', 1, 'Descripción de galeria');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `fotos_imagenes`
-- 

CREATE TABLE `fotos_imagenes` (
  `id_ga` int(11) NOT NULL auto_increment,
  `titulo` varchar(100) collate utf8_spanish_ci NOT NULL,
  `imagen` varchar(50) collate utf8_spanish_ci NOT NULL,
  `descripcion` varchar(200) collate utf8_spanish_ci NOT NULL,
  `fechacre` varchar(11) collate utf8_spanish_ci NOT NULL,
  `fechamod` varchar(11) collate utf8_spanish_ci NOT NULL,
  `categoria` int(11) NOT NULL,
  `mostitle` int(1) NOT NULL,
  `mosdesc` int(1) NOT NULL,
  `activo` int(1) NOT NULL,
  PRIMARY KEY  (`id_ga`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `fotos_imagenes`
-- 

INSERT INTO `fotos_imagenes` VALUES (1, 'Primera Foto', '1318802615.jpg', 'descripcion de fotografia', '1318802615', '1318802674', 1, 1, 1, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `mod_modulos`
-- 

CREATE TABLE `mod_modulos` (
  `mod_id` int(11) NOT NULL auto_increment,
  `mod_nombre` varchar(255) collate utf8_spanish_ci NOT NULL,
  `mod_orden` varchar(100) collate utf8_spanish_ci NOT NULL default '0' COMMENT 'en que orden se mostrara cada modulo',
  `mod_posicion_id` int(11) NOT NULL,
  `mod_tipo_id` int(11) NOT NULL,
  `mod_fecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `mod_modificado` varchar(11) collate utf8_spanish_ci NOT NULL,
  `mod_permisos` varchar(1000) collate utf8_spanish_ci NOT NULL,
  `mod_permisosplus` varchar(255) collate utf8_spanish_ci NOT NULL,
  `mod_vertitu` int(1) NOT NULL,
  `mod_activo` int(1) NOT NULL,
  `mod_archivo` varchar(255) collate utf8_spanish_ci NOT NULL,
  `mod_tipvalor1` longtext collate utf8_spanish_ci NOT NULL,
  `mod_tipvalor2` longtext collate utf8_spanish_ci NOT NULL,
  `mod_tipvalor3` longtext collate utf8_spanish_ci NOT NULL,
  `mod_tipvalor4` longtext collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`mod_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=16 ;

-- 
-- Volcar la base de datos para la tabla `mod_modulos`
-- 

INSERT INTO `mod_modulos` VALUES (1, 'Menu Principal', '1', 4, 1, '1309450050', '1352051953', '-1|1', '14|17|19|21|18|11|23|13|24|20|12|22|2|15|16|', 0, 1, '', '1', '', '', '');
INSERT INTO `mod_modulos` VALUES (2, 'Iniciar Sesión', '0', 2, 4, '1335090842', '1352052701', '-1|1', '17|11|24|12|22|2|15|', 0, 1, '1335090842.tpl', '', '', '', '');
INSERT INTO `mod_modulos` VALUES (3, 'Nube de Palabras', '2', 2, 5, '1335098173', '1342015833', '', '17|', 0, 1, '1335098173.tpl', '', '', '', '');
INSERT INTO `mod_modulos` VALUES (8, 'Reproductor', '0', 1, 3, '1335598224', '1335599251', '-1|1', '14|11|23|12|2|15|', 0, 1, '1335598224.tpl', 'aqui el codigo del reproductor', '', '', '');
INSERT INTO `mod_modulos` VALUES (9, 'Videos: Categorias', '0', 2, 3, '1341836382', '1341916612', '-1|1', '17|11|12|22|2|15|', 0, 1, '1341836382.tpl', '<?php\r\nfunction _ContarArt($art){\r\n	$rptcontco = mysql_query("select * from video_videos where vi_categoria=''$art''");\r\n     return mysql_num_rows($rptcontco);\r\n}\r\n?>\r\n<div class="categories widget clearfix">\r\n  <div class="title-caption">\r\n    <h3>Videos: Categorias</h3>\r\n  </div>\r\n  <ul>\r\n<?php\r\n$rptblog = mysql_query("select vi_ca_titulo,vi_ca_id from video_categorias where vi_ca_estado=''1'' order by vi_ca_titulo DESC limit 8");\r\nwhile($catblog = mysql_fetch_array($rptblog)){\r\n    echo "<li><div><a href=\\"?lagc=com_videos&id=".$catblog[''vi_ca_id'']."&categoria=".LGlobal::Url_Amigable($catblog[''vi_ca_titulo''])."\\">".$catblog[''vi_ca_titulo'']."</a><span>("._ContarArt($catblog[''vi_ca_id'']).")</span></div></li>";\r\n}\r\n?>\r\n  </ul>\r\n</div>', '', '', '');
INSERT INTO `mod_modulos` VALUES (10, 'Videos: Populares', '1', 2, 3, '1341855714', '', '-1|1', '', 0, 1, '1341855714.tpl', '', '', '', '');
INSERT INTO `mod_modulos` VALUES (11, 'Noticias Gigantes', '0', 3, 3, '1341911743', '', '-1|1', '', 0, 1, '1341911743.tpl', '', '', '', '');
INSERT INTO `mod_modulos` VALUES (12, 'Noticias Horizontales', '1', 3, 3, '1341913191', '1341916388', '-1|1', '', 0, 1, '1341913191.tpl', '', '', '', '');
INSERT INTO `mod_modulos` VALUES (13, 'Video Popular', '3', 2, 3, '1341916469', '1341944324', '-1|1', '', 0, 2, '1341916469.tpl', '<div class="latest-video widget">\r\n  <div class="title-caption-dark">\r\n    <h3>vídeo Popular</h3>\r\n    <a href="/videos" class="more-all">Ver todos</a> </div>\r\n  <div id="jp_container_1" class="jp-video jp-video-270p">\r\n    <div class="jp-type-single">\r\n      <div id="jplayer" class="jp-jplayer"></div>\r\n      <div class="jp-gui">\r\n        <div class="jp-video-play"> <a href="javascript:;" class="jp-video-play-icon" tabindex="1">reproducir</a> </div>\r\n        <div class="jp-interface">\r\n          <div class="jp-progress">\r\n            <div class="jp-seek-bar">\r\n              <div class="jp-play-bar"></div>\r\n            </div>\r\n          </div>\r\n          <div class="jp-current-time"></div>\r\n          <div class="jp-duration"></div>\r\n          <div class="jp-controls-holder">\r\n            <ul class="jp-controls">\r\n              <li><a href="javascript:;" class="jp-play" tabindex="1">reproducir</a></li>\r\n              <li><a href="javascript:;" class="jp-pause" tabindex="1">hacer una pausa</a></li>\r\n              <li><a href="javascript:;" class="jp-stop" tabindex="1">detener</a></li>\r\n              <li><a href="javascript:;" class="jp-mute" tabindex="1" title="mute">silenciar</a></li>\r\n              <li><a href="javascript:;" class="jp-unmute" tabindex="1" title="unmute">activar el sonido</a></li>\r\n              <li><a href="javascript:;" class="jp-volume-max" tabindex="1" title="max volume">el volumen máximo</a></li>\r\n            </ul>\r\n            <div class="jp-volume-bar">\r\n              <div class="jp-volume-bar-value"></div>\r\n            </div>\r\n            <ul class="jp-toggles">\r\n              <li><a href="javascript:;" class="jp-full-screen" tabindex="1" title="full screen">pantalla completa</a></li>\r\n              <li><a href="javascript:;" class="jp-restore-screen" tabindex="1" title="restore screen">restaurar la pantalla</a></li>\r\n              <li><a href="javascript:;" class="jp-repeat" tabindex="1" title="repeat">repetir</a></li>\r\n              <li><a href="javascript:;" class="jp-repeat-off" tabindex="1" title="repeat off">repetición desactivada</a></li>\r\n            </ul>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>', '', '', '');
INSERT INTO `mod_modulos` VALUES (14, 'Menú Superior', '0', 6, 1, '1342129376', '1352054564', '-1|1', '17|11|23|24|12|22|2|15|', 0, 1, '', '2', '', '', '');
INSERT INTO `mod_modulos` VALUES (15, 'Mapa Contactenos', '3', 2, 3, '1342450067', '1342451330', '12|1', '', 0, 1, '1342450067.tpl', '<div class="title-caption">\r\n<h3>Mapa de Socabaya</h3>\r\n</div>\r\n<div id="map-canvas"></div>\r\n<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false&language=es"></script>\r\n<script type="text/javascript">\r\n      function initialize() {\r\n        var latlng = new google.maps.LatLng(-16.471213,-71.525824);\r\n        var myOptions = {\r\n          zoom: 14,\r\n          center: latlng,\r\n          mapTypeId: google.maps.MapTypeId.ROADMAP\r\n        };\r\n        var map = new google.maps.Map(document.getElementById("map-canvas"),\r\n            myOptions);\r\n      } initialize()\r\n</script>', '', '', '');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `mod_posiciones`
-- 

CREATE TABLE `mod_posiciones` (
  `mod_id` int(11) NOT NULL auto_increment,
  `mod_nombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `mod_codeinicio` varchar(255) collate utf8_spanish_ci NOT NULL,
  `mod_codefin` varchar(255) collate utf8_spanish_ci NOT NULL,
  `fecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `modificado` varchar(11) collate utf8_spanish_ci NOT NULL,
  `activado` int(1) NOT NULL,
  PRIMARY KEY  (`mod_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=7 ;

-- 
-- Volcar la base de datos para la tabla `mod_posiciones`
-- 

INSERT INTO `mod_posiciones` VALUES (1, 'izquierda', '', '', '1309618511', '1335098273', 1);
INSERT INTO `mod_posiciones` VALUES (2, 'derecha', '', '', '1309618511', '', 1);
INSERT INTO `mod_posiciones` VALUES (3, 'cabecera', '', '', '1309618511', '', 1);
INSERT INTO `mod_posiciones` VALUES (4, 'menuprincipal', '', '', '1325803456', '', 1);
INSERT INTO `mod_posiciones` VALUES (5, 'footer', '', '', '1334433663', '', 1);
INSERT INTO `mod_posiciones` VALUES (6, 'superior', '', '', '1342129150', '', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `mod_tipo`
-- 

CREATE TABLE `mod_tipo` (
  `tip_id` int(11) NOT NULL auto_increment,
  `tip_nombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `tip_lenguaje` varchar(10) collate utf8_spanish_ci NOT NULL,
  `tip_cabecera` longtext collate utf8_spanish_ci NOT NULL,
  `tip_archivo` varchar(15) collate utf8_spanish_ci NOT NULL,
  `tip_savetipo` int(1) NOT NULL default '1',
  `tip_fecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `tip_modificado` varchar(11) collate utf8_spanish_ci NOT NULL,
  `tip_activo` int(1) NOT NULL,
  `tip_tipvalor1` varchar(255) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`tip_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=8 ;

-- 
-- Volcar la base de datos para la tabla `mod_tipo`
-- 

INSERT INTO `mod_tipo` VALUES (1, 'Menus', 'html', '', '1309056506.php', 1, '1309056506', '1317165276', 1, 'posicion|css||');
INSERT INTO `mod_tipo` VALUES (2, 'Editor Html', 'html', '<script type="text/javascript" src="utilidades/tiny_mce/tiny_mce_gzip.js"></script>\r\n<script type="text/javascript">\r\n// This is where the compressor will load all components, include all components used on the page here\r\ntinyMCE_GZ.init({\r\n	plugins : ''spellchecker,pagebreak,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template'',\r\n	themes : ''advanced'',\r\n	languages : ''en'',\r\n	disk_cache : true,\r\n	debug : false\r\n});\r\n</script>\r\n<script type="text/javascript">\r\ntinyMCE.init({\r\n		// General options\r\n		mode : "textareas",\r\n		theme : "advanced",\r\n		editor_deselector : "mceNoEditor", //para que el textarea no tenga editor\r\n		plugins : "spellchecker,pagebreak,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template",\r\n		// Theme options\r\n		theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,undo,redo,formatselect,fontselect,fontsizeselect,insertdate,inserttime",\r\n		theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,link,unlink,anchor,cleanup,|,image,forecolor,|,removeformat,visualaid,|,code,preview,fullscreen",\r\n		theme_advanced_buttons3 : "tablecontrols,|,charmap,iespell,media,advhr,|,sub,sup",\r\n		theme_advanced_toolbar_location : "top",\r\n		theme_advanced_toolbar_align : "left",\r\n		theme_advanced_statusbar_location : "bottom",\r\n		theme_advanced_resizing : true,\r\n		// Skin options\r\n		skin : "o2k7",\r\n		skin_variant : "silver",\r\n		// Drop lists for link/image/media/template dialogs\r\n		template_external_list_url : "js/template_list.js",\r\n		external_link_list_url : "js/link_list.js",\r\n		external_image_list_url : "js/image_list.js",\r\n		media_external_list_url : "js/media_list.js",\r\n		// Replace values for the template plugin\r\n		template_replace_values : {\r\n				username : "Some User",\r\n				staffid : "991234"\r\n		}\r\n});\r\n</script>', '1309056543.php', 2, '1309056543', '1317165288', 1, 'contenido|||');
INSERT INTO `mod_tipo` VALUES (3, 'Codigo', 'html', '<script language="Javascript" type="text/javascript" src="utilidades/edit_area/edit_area_full.js"></script>\r\n<script language="Javascript" type="text/javascript">\r\n// initialisation\r\neditAreaLoader.init({\r\n  id: "cont2_lagc"	// id of the textarea to transform		\r\n  ,start_highlight: true	// if start with highlight\r\n  ,allow_resize: "both"\r\n  ,allow_toggle: true\r\n  ,word_wrap: true\r\n  ,language: "es"\r\n  ,syntax: "php"\r\n  ,toolbar: "search, go_to_line, |, undo, redo"\r\n});\r\n</script>', '1309056555.php', 2, '1309056555', '1317165332', 1, 'codigocont_lagc|||');
INSERT INTO `mod_tipo` VALUES (4, 'Identificarte', 'html', '', '1310959709.php', 2, '1310959709', '1317165344', 1, '|||');
INSERT INTO `mod_tipo` VALUES (5, 'Nube del Blog', 'php', '', '1325803263.php', 2, '1325803263', '1325803607', 1, '|||');
INSERT INTO `mod_tipo` VALUES (6, 'Imagenes', 'php', '', '1328923303.php', 2, '1328923303', '1329147027', 1, 'img1|img2|img3|img4');
INSERT INTO `mod_tipo` VALUES (7, 'Avisos', 'php', '', '1335101366.php', 1, '1335101366', '1335281718', 1, 'contenido|img1|enlace|');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `music_album`
-- 

CREATE TABLE `music_album` (
  `album_id` int(11) NOT NULL auto_increment,
  `album_cantante` int(11) NOT NULL,
  `album_nombre` varchar(100) NOT NULL,
  `album_activo` int(1) NOT NULL,
  PRIMARY KEY  (`album_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `music_album`
-- 

INSERT INTO `music_album` VALUES (1, 2, 'Los reyes del nuevo milenio', 1);
INSERT INTO `music_album` VALUES (2, 2, 'Líderes', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `music_canciones`
-- 

CREATE TABLE `music_canciones` (
  `song_id` int(11) NOT NULL auto_increment,
  `song_titulo` varchar(100) NOT NULL,
  `song_id_cantante` int(11) NOT NULL,
  `song_album` int(11) NOT NULL,
  `song_id_genero` int(11) NOT NULL,
  `song_id_servidor` int(11) NOT NULL,
  `song_letra` text NOT NULL,
  `song_video` varchar(20) NOT NULL,
  `song_url` varchar(150) NOT NULL,
  `song_anio` varchar(4) NOT NULL,
  `song_user` int(11) NOT NULL,
  `song_creado` varchar(11) NOT NULL,
  `song_modificado` varchar(11) NOT NULL,
  `song_activo` int(1) NOT NULL,
  PRIMARY KEY  (`song_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- Volcar la base de datos para la tabla `music_canciones`
-- 

INSERT INTO `music_canciones` VALUES (1, 'Noche De Sexo', 2, 2, 48, 3, '<p style="text-align: center;"><span>it''s you boy romeo&nbsp;<br />W con Yandel&nbsp;<br />so nasty&nbsp;<br />oye bebe... pa''l mundo&nbsp;<br /><br />hola que tal soy el chico de las poesias&nbsp;<br />tu fiel admirador y aunque no me conocias&nbsp;<br />hoy es noche de sexo, voy a deborarte nena linda&nbsp;<br />hoy es noche de sexo y voy a cumplir tus fantasias&nbsp;<br />hoy es de noche de sexo, ayyy voy a deborarte nena linda&nbsp;<br />hoy es noche de sexo,&nbsp;<br /><br />lo juro por Dios q'' esta noche seras mia&nbsp;<br />q'' vo''arrancarte la tela con cautela, mi piel canela,&nbsp;<br />enseguida pela,&nbsp;<br />ella es la protagonista de mi novela&nbsp;<br />mi cinderella conmigo es q'' vuela&nbsp;<br />pongase romantica please, dame un kiss,&nbsp;<br />no cometa un desliz&nbsp;<br />ella combina la calle con la moda de paris,&nbsp;<br />la miss sigue matando en el pais&nbsp;<br /><br />hoy es noche de sexo, voy a deborarte nena linda&nbsp;<br />hoy es noche de sexo y voy a cumplir tus fantasias&nbsp;<br />hoy es de noche de sexo, ayyy voy a deborarte nena linda&nbsp;<br />hoy es noche de sexo, lo juro por Dios q'' esta noche seras mia<br /><br />acercate...&nbsp;<br />te dire que...&nbsp;<br />nadie te va a tocar como yo,&nbsp;<br />nadie te lo va a hacer como yo&nbsp;<br />y acercate...&nbsp;<br />te dire que...&nbsp;<br />nadie te va a tocar como yo,&nbsp;<br />nadie te lo va a hacer como yo&nbsp;<br /><br />decidete ya cuando sera q'' tu boca tocara mi boca&nbsp;<br />so dime ya q'' tu me das&nbsp;<br />quiero sentirte, besarte mi lengua pasarte y vas&nbsp;<br />a sentirte bien, vamos a pasarla bien,&nbsp;<br />tu no ves q'' estoy sufriendo&nbsp;<br />y viendo el tiempo pasar sin comerte&nbsp;<br />empecemo'' en la playa, terminemo''&nbsp;<br />en la cama trae la toalla porque te vas a mojar&nbsp;<br />enflex mami your tense, lay in my bed and prepare for<br /><br />hoy es noche de sexo, voy a deborarte nena linda&nbsp;<br />hoy es noche de sexo y voy a cumplir tus fantasias&nbsp;<br />hoy es de noche de sexo, ayyy voy a deborarte nena linda&nbsp;<br />hoy es noche de sexo, lo juro por Dios q'' esta noche seras mia.</span></p>', 'c9XeNj3PaX0', '', '', 1, '1351006763', '1351016216', 1);
INSERT INTO `music_canciones` VALUES (2, 'La Pared', 2, 2, 48, 3, '<p style="text-align: center;"><span>Jajajaja....&nbsp;</span><br /><span>Dooooonnnnn...&nbsp;</span><br /><span>Tranquilos muchachos... (Papi hicieron roncar al jefe...)&nbsp;</span><br /><span>Que mientras nosotros tengamos el control del genero...&nbsp;</span><br /><span>(Aqui no juega to el mundo...)&nbsp;</span><br /><span>Todos vamos a estar bien... (Jaaa!!!)&nbsp;</span><br /><br /><span>Coro (Yandel)&nbsp;</span><br /><br /><span>A mi me encanta cuando tu, (cuando tu) te pegas...&nbsp;</span><br /><span>A ti te encanta cuando yo, (cuando yo) te pego...&nbsp;</span><br /><span>A la pared, a la pared yeah yeah!!&nbsp;</span><br /><span>A la pared, a la pared...&nbsp;</span><br /><span>(Nosotros tenemos, nuestra propia agencia de viajes)...&nbsp;</span><br /><span>A la pared, a la pared yeah yeah!!!&nbsp;</span><br /><br /><span>Don Omar&nbsp;</span><br /><br /><span>Me toca el turno al bate, a mi pesito e'' chocolate...&nbsp;</span><br /><span>Q andan los salvajes, subiendose al Volkswagen...&nbsp;</span><br /><span>Con los tacones en la mano, subiendose el traje...&nbsp;</span><br /><span>(Seductora)...&nbsp;</span><br /><span>Se le olvido hasta el modelaje...&nbsp;</span><br /><span>Anda x ahi como musica loca dandose besitos con las amiguitas en el cuellito y en la boca...&nbsp;</span><br /><span>Y si otro vinito y sus amiguitos no la tocan...&nbsp;</span><br /><span>(Oye dejate llevar x nosotros)...&nbsp;</span><br /><span>Rrrraaaaa, se fue en chota...&nbsp;</span><br /><br /><span>Coro (Yandel y Don Omar)&nbsp;</span><br /><br /><span>A mi me encanta cuando tu, (cuando tu) te pegas...&nbsp;</span><br /><span>A ti te encanta cuando yo, (cuando yo) te pego...&nbsp;</span><br /><span>A la pared, a la pared yeah yeah!!&nbsp;</span><br /><span>A la pared, a la pared...&nbsp;</span><br /><span>Doooonnn... (Ey!!!)&nbsp;</span><br /><span>A mi me encanta cuando tu, (cuando tu) te pegas...&nbsp;</span><br /><span>A ti te encanta cuando yo, (cuando yo) te pego...&nbsp;</span><br /><span>A la pared, a la pared yeah yeah!!&nbsp;</span><br /><span>A la pared, a la pared...&nbsp;</span><br /><br /><span>Wisin&nbsp;</span><br /><br /><span>(Preparate)...&nbsp;</span><br /><span>Oye no se lo digas a nadie...&nbsp;</span><br /><span>Si tu pones una parte yo pongo el otro Tanto...&nbsp;</span><br /><span>Debajo del manto, sin piedad te levanto... (Ahhhh...)&nbsp;</span><br /><span>Dame un beso y un canto...&nbsp;</span><br /><span>Si tu eres mi religion yo soy tu santo...&nbsp;</span><br /><span>Y te presiona, fiera como Amazonas...&nbsp;</span><br /><span>De sus amigas la patrona...&nbsp;</span><br /><span>Una gata con rabia, cuidando la zona, rapida...&nbsp;</span><br /><span>Y no pare de pedalear, no se deje acorralar...&nbsp;</span><br /><span>A esa leona nadie la puede domar...&nbsp;</span><br /><span>Si suben el ritmo, empieza a sudar...&nbsp;</span><br /><span>Sin piedad te va a cazar, su mision es no fallar...&nbsp;</span><br /><br /><span>Coro (Yandel)&nbsp;</span><br /><br /><span>A mi me encanta cuando tu, (cuando tu) te pegas...&nbsp;</span><br /><span>A ti te encanta cuando yo, (cuando yo) te pego...&nbsp;</span><br /><span>A la pared, a la pared yeah yeah!!&nbsp;</span><br /><span>A la pared, a la pared...&nbsp;</span><br /><br /><span>Gadiel&nbsp;</span><br /><br /><span>(Oye mami te voy a decir un par de cosas)...&nbsp;</span><br /><span>Ponte las pilas...&nbsp;</span><br /><span>Invita a tus pupilas...&nbsp;</span><br /><span>Esta noche tu cuerpo desfila...&nbsp;</span><br /><span>Enciendete, date un tequila...&nbsp;</span><br /><span>Llegaron los q no hacen fila...&nbsp;</span><br /><span>Pelo rizo, de cuerpo una Top Model...&nbsp;</span><br /><span>No se va en jover, tiene full cover...&nbsp;</span><br /><span>(Ta bien guilla)...&nbsp;</span><br /><span>En su Foulroller...&nbsp;</span><br /><span>(Bien acicala)...&nbsp;</span><br /><span>Gadiel ta to'' duro cotran el muro...&nbsp;</span><br /><span>Agarrate...(Sueltate)...&nbsp;</span><br /><span>Agarrate...&nbsp;</span><br /><span>Yandel ta duro, duro contra el muro...&nbsp;</span><br /><span>(Tu y yo mamita en lo oscuro)...&nbsp;</span><br /><span>(LOS EXTRATERRESTRES)...&nbsp;</span><br /><br /><span>Coro (Don Omar y Yandel)&nbsp;</span><br /><br /><span>A mi me encanta cuando tu, (cuando tu) te pegas...&nbsp;</span><br /><span>A ti te encanta cuando yo, (cuando yo) te pego...&nbsp;</span><br /><span>A la pared, a la pared yeah yeah!!&nbsp;</span><br /><span>A la pared, a la pared...&nbsp;</span><br /><br /><span>(Wisin, Yandel, Don Omar)&nbsp;</span><br /><br /><span>Sencillo!!!&nbsp;</span><br /><span>Los de la zona place, W y Yandel, El Rey...&nbsp;</span><br /><span>Con el rey Don Omar, navegando...&nbsp;</span><br /><span>Quitense mi hermano...&nbsp;</span><br /><span>Usted con nosotros esta cojiendo agua x donde la vaca se ahoga...&nbsp;</span><br /><span>Nosotros somos extraterrestres, estamos en la nave...&nbsp;</span><br /><span>El rey...&nbsp;</span><br /><span>No es necesario, decifrar nuestro sistema...&nbsp;</span><br /><span>Dooooonnnnn...&nbsp;</span><br /><span>Nosotros en el genero somos es triangulo de las bermudas...&nbsp;</span><br /><span>Un misterio musical...&nbsp;</span><br /><span>W con Yandel...&nbsp;</span><br /><span>Nesty, la mente maestra...&nbsp;</span><br /><span>Victor el Nazi...&nbsp;</span><br /><span>Los 3 cuadrangulares de corrido oites...&nbsp;</span><br /><span>Bienvenidos al mundo de los hermanos Veguilla...&nbsp;</span><br /><span>Wisin y Yandel, El Rey, Los Vaqueros, Victor el Nazi...&nbsp;</span><br /><span>Tu sabes como nosotros lo hacemos...&nbsp;</span><br /><span>Nesty...&nbsp;</span><br /><span>Sencillo...&nbsp;</span><br /><span>LOS EXTRATERRESTRES...&nbsp;</span><br /><span>W tranquilo q todos estan corriendo x su carril...</span></p>', 'yIlLWdyRxaE', '', '', 1, '1351007411', '1351016228', 1);
INSERT INTO `music_canciones` VALUES (3, 'Tu cuerpo me llama', 2, 0, 48, 3, '<p style="text-align: center;"><span>Yo soy Reykon el lider&nbsp;</span><br /><span>en el remix&nbsp;</span><br /><span>para que brille&nbsp;</span><br /><span>con Ronald y Morron&nbsp;</span><br /><span>Los Mortal Combat&nbsp;</span><br /><br /><span>Note dejo de pensar&nbsp;</span><br /><span>en mi mente tu estas&nbsp;</span><br /><span>por las noches yo sue&ntilde;o contigo&nbsp;</span><br /><span>mi cuerpo empieza a temblar&nbsp;</span><br /><span>como puedes notar&nbsp;</span><br /><span>y pasa cada vez que hablo contigo&nbsp;</span><br /><span>pues la mente me falla&nbsp;</span><br /><span>el deseo me estalla&nbsp;</span><br /><span>solo cuando escucho tu voz&nbsp;</span><br /><span>los nervios al hablar&nbsp;</span><br /><span>me ganan la batalla&nbsp;</span><br /><span>cuando estas al telefono&nbsp;</span><br /><br /><span>Y es que Tu cuerpo me llama&nbsp;</span><br /><span>vente por favor&nbsp;</span><br /><span>quiero tenerte en mi cama&nbsp;</span><br /><span>y hacerte el amor&nbsp;</span><br /><span>y es que Tu cuerpo me llama&nbsp;</span><br /><span>vente por favor&nbsp;</span><br /><span>quiero tenerte en mi cama&nbsp;</span><br /><span>y hacerte el amor&nbsp;</span><br /><span>oh no&nbsp;</span><br /><span>oh no no no no&nbsp;</span><br /><span>y hacerte el amor&nbsp;</span><br /><span>oh no no no no&nbsp;</span><br /><span>(dicelo Ronald)&nbsp;</span><br /><br /><span>cuando estes sola&nbsp;</span><br /><span>llama llama&nbsp;</span><br /><span>yo llego a tu cama&nbsp;</span><br /><span>pa hacerte cosas ricas&nbsp;</span><br /><span>hasta por la ma&ntilde;ana&nbsp;</span><br /><span>yo voy con mi pana&nbsp;</span><br /><span>tu invita a tu hermana&nbsp;</span><br /><span>combinaci&oacute;n perfecta&nbsp;</span><br /><span>pa matar la llama&nbsp;</span><br /><br /><span>ya la tengo al punto&nbsp;</span><br /><span>por eso es que pregunto&nbsp;</span><br /><span>que estamos esperando&nbsp;</span><br /><span>pa resolver el asunto&nbsp;</span><br /><span>solos vamos pa ya&nbsp;</span><br /><span>que cuando estemos juntos&nbsp;</span><br /><span>le damo al creepyton&nbsp;</span><br /><span>al blond bien profundo&nbsp;</span><br /><br /><span>te juro que no queria&nbsp;</span><br /><span>pero por dentro sentia&nbsp;</span><br /><span>que si no besaba esa boquita&nbsp;</span><br /><span>me moriria&nbsp;</span><br /><span>que de hace mucho tiempo&nbsp;</span><br /><span>eres mi fantasia&nbsp;</span><br /><span>por ti me paso en Facebook&nbsp;</span><br /><span>de noche y de dia&nbsp;</span><br /><br /><span>Y es que Tu cuerpo me llama&nbsp;</span><br /><span>vente por favor&nbsp;</span><br /><span>quiero tenerte en mi cama&nbsp;</span><br /><span>y hacerte el amor&nbsp;</span><br /><span>y es que Tu cuerpo me llama&nbsp;</span><br /><span>vente por favor&nbsp;</span><br /><span>quiero tenerte en mi cama&nbsp;</span><br /><span>y hacerte el amor&nbsp;</span><br /><span>oh no&nbsp;</span><br /><span>oh no no no no&nbsp;</span><br /><span>(Yo soy Reykon el Lider en el Remix)&nbsp;</span><br /><span>oh no no no no&nbsp;</span><br /><span>y hacerte el amor&nbsp;</span><br /><br /><span>y es que tu cuerpo a mi me llama&nbsp;</span><br /><span>pa una aventura alla en la playa&nbsp;</span><br /><span>pa casantenas mucha la raya&nbsp;</span><br /><span>toy en Cancun y nadie me para&nbsp;</span><br /><br /><span>y yo quiero saber&nbsp;</span><br /><span>como practicas esos movimientos&nbsp;</span><br /><span>hazlo de una vez&nbsp;</span><br /><span>quiero probar tu cuerpo por dentro&nbsp;</span><br /><span>me pide un hotel&nbsp;</span><br /><span>solo cartera de channel&nbsp;</span><br /><span>luego un crucero pa Miami&nbsp;</span><br /><span>pa que vea como eh&nbsp;</span><br /><span>me pide un hotel&nbsp;</span><br /><span>pa que vea como eh&nbsp;</span><br /><span>es andar con Reykon el lider&nbsp;</span><br /><br /><span>escapemonos para que mi boca&nbsp;</span><br /><span>pueda besar cada parte de tu cuerpo&nbsp;</span><br /><span>y demonos&nbsp;</span><br /><span>pasion y sexo&nbsp;</span><br /><br /><span>en mi cama si te entregas tu yale&nbsp;</span><br /><span>suelta todo tu cuerpo&nbsp;</span><br /><span>hoy lo haremos a tu manera&nbsp;</span><br /><span>con unas copas demas&nbsp;</span><br /><span>y poco de tus besos&nbsp;</span><br /><span>los sentidos se me alteran&nbsp;</span><br /><br /><span>Y es que Tu cuerpo me llama&nbsp;</span><br /><span>vente por favor&nbsp;</span><br /><span>quiero tenerte en mi cama&nbsp;</span><br /><span>y hacerte el amor&nbsp;</span><br /><span>y es que Tu cuerpo me llama&nbsp;</span><br /><span>vente por favor&nbsp;</span><br /><span>quiero tenerte en mi cama&nbsp;</span><br /><span>y hacerte el amor&nbsp;</span><br /><span>oh no&nbsp;</span><br /><span>oh no no no no&nbsp;</span><br /><span>oh no no no no&nbsp;</span><br /><span>oh no no no no&nbsp;</span><br /><span>oh no no no no&nbsp;</span><br /><span>y hacerte el amor...&nbsp;</span><br /><br /><span>Yo soy Reykon el Lider&nbsp;</span><br /><span>eh eh que no se te olvide&nbsp;</span><br /><span>Reykon el Lider eh eh&nbsp;</span><br /><span>con Los Mortal Combat&nbsp;</span><br /><span>This is Morron alias saco ma&nbsp;</span><br /><span>con RonalD el killa&nbsp;</span><br /><span>Reykon el Lider in the Remix&nbsp;</span><br /><span>Los Mortal Combat&nbsp;</span><br /><span>La 440 Studios&nbsp;</span><br /><span>Pipe Florez&nbsp;</span><br /><span>Digital Records&nbsp;</span><br /><span>Mucha calidad musical&nbsp;</span><br /><span>DJsack&nbsp;</span><br /><span>poniendolas a mover el bote&nbsp;</span><br /><span>Mc Giver matando en el flote&nbsp;</span><br /><span>directamente de la Ciudad de Dios&nbsp;</span></p>', 'p0efTzu6FJY', 'tu_cuerpo_me_llama_los_mortal_combat.mp3', '', 1, '1351360636', '', 1);
INSERT INTO `music_canciones` VALUES (4, 'Yo te lo dije', 2, 2, 52, 3, '<p style="text-align: center;"><span>pero&nbsp;</span><br /><span>yo teje todo claro&nbsp;</span><br /><span>en que aviamos quedado&nbsp;</span><br /><span>yo te lo dije&nbsp;</span><br /><br /><span>yo te lo dije no me iba a enamorar&nbsp;</span><br /><span>te lo advert&iacute; a ti my girl&nbsp;</span><br /><span>que al otro d&iacute;a nos &iacute;bamos ah olvidar&nbsp;</span><br /><span>que no nos &iacute;bamos ah llamar.&nbsp;</span><br /><span>(x2)&nbsp;</span><br /><br /><span>sin compromiso&nbsp;</span><br /><span>lo que paso fue sin previo aviso&nbsp;</span><br /><span>esa nena en la calle me hechizo&nbsp;</span><br /><span>ahora ella me llama&nbsp;</span><br /><span>dice que quiere sentir la flama&nbsp;</span><br /><span>que quiere tenerme en su cama&nbsp;</span><br /><span>ohh ella me llama&nbsp;</span><br /><span>&eacute;chale la culpa al jiggy drama&nbsp;</span><br /><span>que lo nuestro fue un fin de semana&nbsp;</span><br /><span>(sana)no me llames&nbsp;</span><br /><span>que yo tengo planes&nbsp;</span><br /><span>yo soy j balvin&nbsp;</span><br /><span>y el resto tu lo sabes&nbsp;</span><br /><br /><span>yo te lo dije no me iba a enamorar&nbsp;</span><br /><span>te lo advert&iacute; a ti my girl&nbsp;</span><br /><span>que al otro d&iacute;a nos &iacute;bamos ah olvidar&nbsp;</span><br /><span>que no nos &iacute;bamos ah llamar.&nbsp;</span><br /><span>(x2)&nbsp;</span><br /><br /><span>y fue un placer tenerte asta almanecer&nbsp;</span><br /><span>por si acaso baby no te vuelvo a ver.&nbsp;</span><br /><span>(x2)&nbsp;</span><br /><br /><span>te lo dije&nbsp;</span><br /><span>y fue muy claro decirtele&nbsp;</span><br /><span>pero bueno&nbsp;</span><br /><span>las cosas pasan&nbsp;</span><br /><span>the bussiness&nbsp;</span><br /><span>el negocio socio&nbsp;</span><br /><span>j balvin&nbsp;</span><br /><br /><span>yo te lo dije no me iba a enamorar&nbsp;</span><br /><span>te lo advert&iacute; a ti my girl&nbsp;</span><br /><span>que al otro d&iacute;a nos &iacute;bamos ah olvidar&nbsp;</span><br /><span>que no nos &iacute;bamos ah llamar.&nbsp;</span><br /><span>(x2)&nbsp;</span><br /><br /><span>y fue un placer tenerte asta almanecer&nbsp;</span><br /><span>por si acaso baby no te vuelvo a ver.&nbsp;</span><br /><span>(x2)&nbsp;</span><br /><br /><span>yo te lo dije no me iba a enamorar&nbsp;</span><br /><span>te lo advert&iacute; a ti my girl&nbsp;</span><br /><span>que al otro d&iacute;a nos &iacute;bamos ah olvidar&nbsp;</span><br /><span>que no nos &iacute;bamos ah llamar.&nbsp;</span><br /><span>(x2)&nbsp;</span><br /><br /><span>que no nos ibamos ah llamar&nbsp;</span><br /><span>que no nos ibamos ah llamaaaaar</span></p>', '-l9FX_H7DPo', 'j_balbin_yo_te_lo_dije.mp3', '2004', 1, '1351524531', '', 1);
INSERT INTO `music_canciones` VALUES (5, 'me muero por ti', 2, 2, 48, 4, 'la la', '4vXUpVMMuqQ', 's/p5zazonqb4r4nqj/tony%20dize%20-%20me%20muero%20por%20ti.mp3?dl=1', '2011', 1, '1351006763', '1351006763', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `music_cantantes`
-- 

CREATE TABLE `music_cantantes` (
  `cantan_id` int(11) NOT NULL auto_increment,
  `cantan_nombre` varchar(255) NOT NULL,
  `cantan_generos` varchar(255) NOT NULL,
  `cantan_descripcion` text NOT NULL,
  `cantan_img` varchar(15) NOT NULL,
  `cantan_anio` varchar(4) NOT NULL,
  `cantan_pais` varchar(100) NOT NULL,
  `cantan_premios` text NOT NULL,
  `cantan_css` text NOT NULL,
  `cantan_activo` int(1) NOT NULL,
  PRIMARY KEY  (`cantan_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Volcar la base de datos para la tabla `music_cantantes`
-- 

INSERT INTO `music_cantantes` VALUES (1, 'Daddy yankee', '48', '0', '', '', '', '0', '', 1);
INSERT INTO `music_cantantes` VALUES (2, 'Wisin Y Yandel', '48/52', 'El dúo conformado por Wisin & Yandel comenzó su actividad musical en 1998 con el disco Dj Dicky: No Fear 3, en 2000 publicaron su primer álbum de estudio llamado Los reyes del nuevo milenio, donde consiguieron grabar con Tempo y Baby Rasta & Gringo.\r\nEn las sucesivas ediciones de "La Misión", continuaron publicando nuevos temas y grabaron tres nuevos álbumes: De nuevos a viejos (2001), De otra manera (2002) y Mi vida... my life (2003). Los tres fueron disco de oro. En el 2002 recibieron el premio "Tu Música" al mejor dúo de rap y reggaetón.', '1342092502.jpg', '1998', 'Puerto Rico', 'Sus giras mundiales logran llenos totales en los auditorios y estadios más importantes de cada ciudad en la que se presentan, incluyendo el Staples Center de Los Ángeles, American Airlines Arena de Miami y el Madison Square Garden de Nueva York.', '', 1);
INSERT INTO `music_cantantes` VALUES (3, 'Don omar', '48', '0', '', '', '', '0', '', 1);
INSERT INTO `music_cantantes` VALUES (4, 'Maluma', '48', '0', '', '', '', '0', '', 1);
INSERT INTO `music_cantantes` VALUES (5, 'Luis Gago', '2/23/48/50/52', '0', '1342092502.jpg', '', '', '0', '', 1);
INSERT INTO `music_cantantes` VALUES (6, 'Romeo Santos', '2/7', 'Anthony Santos (Nueva York, 21 de julio de 1981), conocido como Romeo Santos, es un cantautor estadounidense de ascendencia dominicana por parte de padre y puertorriqueña por parte de madre. Fue el líder, vocalista y principal compositor del grupo de bachata Aventura. Como miembro de Aventura, Santos ha sido una figura clave en la popularización de la bachata a nivel internacional, llevando canciones al top de las listas de Billboard Latino y a los charts de Europa,en su separacion del grupo aventura a sido reconocido como romeo santos y ya saco su primer disco como solista FORMULA 1.', '', '1994', 'Estados Unidos', 'En 2011 Gana Como Compositor del Año Los Premios Casandra De La Republica Dominicana .', '', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `music_genero`
-- 

CREATE TABLE `music_genero` (
  `genero_id` int(11) NOT NULL auto_increment,
  `genero_nombre` varchar(255) NOT NULL,
  `genero_descripcion` varchar(255) NOT NULL,
  `genero_img` varchar(15) NOT NULL,
  `genero_css` text NOT NULL,
  `genero_activo` int(1) NOT NULL,
  PRIMARY KEY  (`genero_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=57 ;

-- 
-- Volcar la base de datos para la tabla `music_genero`
-- 

INSERT INTO `music_genero` VALUES (1, 'Anime', '', '', '', 1);
INSERT INTO `music_genero` VALUES (2, 'Bachatas', '', '', '', 1);
INSERT INTO `music_genero` VALUES (3, 'Arabe', '', '', '', 1);
INSERT INTO `music_genero` VALUES (4, 'Andina', '', '', '', 1);
INSERT INTO `music_genero` VALUES (5, 'Alternativo', '', '', '', 1);
INSERT INTO `music_genero` VALUES (6, 'Baladas de Oro', '', '', '', 1);
INSERT INTO `music_genero` VALUES (7, 'Baladas en ingles', '', '', '', 1);
INSERT INTO `music_genero` VALUES (8, 'Blues', '', '', '', 1);
INSERT INTO `music_genero` VALUES (9, 'Blues Rock', '', '', '', 1);
INSERT INTO `music_genero` VALUES (10, 'Boleros', '', '', '', 1);
INSERT INTO `music_genero` VALUES (11, 'Bosca Nava', '', '', '', 1);
INSERT INTO `music_genero` VALUES (12, 'Brasileras', '', '', '', 1);
INSERT INTO `music_genero` VALUES (13, 'Chicha', '', '', '', 1);
INSERT INTO `music_genero` VALUES (14, 'Clasica', '', '', '', 1);
INSERT INTO `music_genero` VALUES (15, 'Coreografias', '', '', '', 1);
INSERT INTO `music_genero` VALUES (16, 'Country', '', '', '', 1);
INSERT INTO `music_genero` VALUES (17, 'Criollas', '', '', '', 1);
INSERT INTO `music_genero` VALUES (18, 'Cumbia Boliviana', '', '', '', 1);
INSERT INTO `music_genero` VALUES (19, 'Cumbia Chilena', '', '', '', 1);
INSERT INTO `music_genero` VALUES (20, 'Cumbia Colombiana', '', '', '', 1);
INSERT INTO `music_genero` VALUES (21, 'Cumbia del Ecuador', '', '', '', 1);
INSERT INTO `music_genero` VALUES (22, 'Cumbia Mexicana', '', '', '', 1);
INSERT INTO `music_genero` VALUES (23, 'Cumbia Peruanas', '', '', '', 1);
INSERT INTO `music_genero` VALUES (24, 'Cumbias Villeras', '', '', '', 1);
INSERT INTO `music_genero` VALUES (25, 'Dance', '', '', '', 1);
INSERT INTO `music_genero` VALUES (26, 'Disco', '', '', '', 1);
INSERT INTO `music_genero` VALUES (27, 'Electronica', '', '', '', 1);
INSERT INTO `music_genero` VALUES (28, 'Flamenco', '', '', '', 1);
INSERT INTO `music_genero` VALUES (29, 'Folklore', '', '', '', 1);
INSERT INTO `music_genero` VALUES (30, 'Heavy Metal', '', '', '', 1);
INSERT INTO `music_genero` VALUES (31, 'Hip Hop', '', '', '', 1);
INSERT INTO `music_genero` VALUES (32, 'Huaynos', '', '', '', 1);
INSERT INTO `music_genero` VALUES (33, 'Indu', '', '', '', 1);
INSERT INTO `music_genero` VALUES (34, 'Infantiles', '', '', '', 1);
INSERT INTO `music_genero` VALUES (35, 'Instrumentales', '', '', '', 1);
INSERT INTO `music_genero` VALUES (36, 'Jazz', '', '', '', 1);
INSERT INTO `music_genero` VALUES (37, 'Lationoamericana', '', '', '', 1);
INSERT INTO `music_genero` VALUES (38, 'Los 70s', '', '', '', 1);
INSERT INTO `music_genero` VALUES (39, 'Los 80s', '', '', '', 1);
INSERT INTO `music_genero` VALUES (40, 'Merengues', '', '', '', 1);
INSERT INTO `music_genero` VALUES (41, 'Metal', '', '', '', 1);
INSERT INTO `music_genero` VALUES (42, 'Cristianas', '', '', '', 1);
INSERT INTO `music_genero` VALUES (43, 'Pop Rock', '', '', '', 1);
INSERT INTO `music_genero` VALUES (44, 'Punk', '', '', '', 1);
INSERT INTO `music_genero` VALUES (45, 'Punk Rock', '', '', '', 1);
INSERT INTO `music_genero` VALUES (46, 'Rancheras', '', '', '', 1);
INSERT INTO `music_genero` VALUES (47, 'Reggae', '', '', '', 1);
INSERT INTO `music_genero` VALUES (48, 'Reggaeton', '', '', '', 1);
INSERT INTO `music_genero` VALUES (49, 'Rock', '', '', '', 1);
INSERT INTO `music_genero` VALUES (50, 'Rock en español', '', '', '', 1);
INSERT INTO `music_genero` VALUES (51, 'Romantica', '', '', '', 1);
INSERT INTO `music_genero` VALUES (52, 'Salsa', 'La salsa es el término usado a partir de los años setenta para definir al género musical resultante de una síntesis de influencias musicales cubanas con otros elementos de música caribeña, música latinoamericana y jazz, en especial el jazz afrocubano. La ', '', '', 1);
INSERT INTO `music_genero` VALUES (53, 'Tangos', '', '', '', 1);
INSERT INTO `music_genero` VALUES (54, 'Tecno', '', '', '', 1);
INSERT INTO `music_genero` VALUES (55, 'Trova', '', '', '', 1);
INSERT INTO `music_genero` VALUES (56, 'Vallenatos', '', '', '', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `music_message`
-- 

CREATE TABLE `music_message` (
  `id` int(11) NOT NULL auto_increment,
  `usuario` int(11) NOT NULL,
  `cancion` int(11) NOT NULL,
  `mensaje` varchar(254) NOT NULL,
  `fecha` varchar(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=56 ;

-- 
-- Volcar la base de datos para la tabla `music_message`
-- 

INSERT INTO `music_message` VALUES (1, 1, 1, 'oye bebe... pa''l mundo', '1355509953');
INSERT INTO `music_message` VALUES (2, 1, 2, 'Todos vamos a estar bien... (Jaaa!!!) ', '1355509963');
INSERT INTO `music_message` VALUES (3, 1, 3, 'Note dejo de pensar ', '1355509983');
INSERT INTO `music_message` VALUES (4, 1, 4, 'yo te lo dije no me iba a enamorar  te lo advertÃ­ a ti my girl  que al otro dÃ­a nos Ã­bamos ah olvidar  que no nos Ã­bamos ah llamar. ', '1355510000');
INSERT INTO `music_message` VALUES (5, 1, 5, 'la la', '1355510014');
INSERT INTO `music_message` VALUES (6, 1, 2, 'holas', '1355519244');
INSERT INTO `music_message` VALUES (7, 1, 2, 'okas', '1355519252');
INSERT INTO `music_message` VALUES (8, 1, 2, 'jejeje en serio?', '1355519259');
INSERT INTO `music_message` VALUES (9, 1, 2, 'jajaja q va hacer :)', '1355519297');
INSERT INTO `music_message` VALUES (10, 1, 2, 'en serio todo xvr?', '1355519360');
INSERT INTO `music_message` VALUES (11, 1, 2, 'jejej si ps lo mejor', '1355519363');
INSERT INTO `music_message` VALUES (12, 1, 2, 'obvio causa', '1355519366');
INSERT INTO `music_message` VALUES (13, 1, 2, 'xvr la cancion he', '1355520629');
INSERT INTO `music_message` VALUES (14, 1, 2, 'jeje', '1355520648');
INSERT INTO `music_message` VALUES (15, 1, 2, 'jujuj', '1355520651');
INSERT INTO `music_message` VALUES (16, 1, 2, 'xth', '1355520654');
INSERT INTO `music_message` VALUES (17, 1, 2, 'jajaja', '1355520754');
INSERT INTO `music_message` VALUES (18, 1, 2, 'xth', '1355520760');
INSERT INTO `music_message` VALUES (19, 1, 2, 'jajaj', '1355520762');
INSERT INTO `music_message` VALUES (20, 1, 2, 'obvio ps causa', '1355520778');
INSERT INTO `music_message` VALUES (21, 1, 2, 'jaja', '1355520780');
INSERT INTO `music_message` VALUES (22, 1, 2, 'xvr', '1355520781');
INSERT INTO `music_message` VALUES (23, 1, 2, 'okas', '1355520790');
INSERT INTO `music_message` VALUES (24, 1, 2, 'xvr', '1355520792');
INSERT INTO `music_message` VALUES (25, 1, 2, 'jaja', '1355520795');
INSERT INTO `music_message` VALUES (26, 1, 2, 'ni mod ps', '1355520813');
INSERT INTO `music_message` VALUES (27, 1, 2, 'okas', '1355520815');
INSERT INTO `music_message` VALUES (28, 1, 2, 'jeje', '1355520818');
INSERT INTO `music_message` VALUES (29, 1, 2, 'xth', '1355520843');
INSERT INTO `music_message` VALUES (30, 1, 2, 'jajaj', '1355520844');
INSERT INTO `music_message` VALUES (31, 1, 2, 'obvio ps causa', '1355520847');
INSERT INTO `music_message` VALUES (32, 1, 2, 'jajaja q wena', '1355520875');
INSERT INTO `music_message` VALUES (33, 1, 2, 'okas', '1355520876');
INSERT INTO `music_message` VALUES (34, 1, 2, '100pre sera asi', '1355520879');
INSERT INTO `music_message` VALUES (35, 1, 2, 'xD', '1355520881');
INSERT INTO `music_message` VALUES (36, 1, 2, 'holas que tal como estna he? que de nuevo muxaxos?', '1355525851');
INSERT INTO `music_message` VALUES (37, 1, 2, 'jejeje espero que todo este saliendo bien :)', '1355526384');
INSERT INTO `music_message` VALUES (38, 1, 2, 'jejeje xD', '1355526430');
INSERT INTO `music_message` VALUES (39, 1, 2, 'espero q xvr verdad?', '1355526440');
INSERT INTO `music_message` VALUES (40, 1, 2, 'bien esta web', '1355526465');
INSERT INTO `music_message` VALUES (41, 1, 2, 'como estan?', '1355526659');
INSERT INTO `music_message` VALUES (42, 1, 2, 'juju', '1355528463');
INSERT INTO `music_message` VALUES (43, 1, 2, 'jejejeje', '1355528599');
INSERT INTO `music_message` VALUES (44, 1, 2, 'xvr', '1355528601');
INSERT INTO `music_message` VALUES (45, 1, 2, 'okas', '1355528602');
INSERT INTO `music_message` VALUES (46, 1, 2, 'jujujju', '1355528605');
INSERT INTO `music_message` VALUES (47, 1, 5, 'holas que bonita cancion :)', '1355529965');
INSERT INTO `music_message` VALUES (48, 1, 4, 'esta xvr', '1357148655');
INSERT INTO `music_message` VALUES (49, 1, 4, 'jejeje', '1357148657');
INSERT INTO `music_message` VALUES (50, 1, 4, 'muy buena cancion', '1357148668');
INSERT INTO `music_message` VALUES (51, 1, 4, 'la recomiendo :)', '1357148672');
INSERT INTO `music_message` VALUES (52, 5, 2, 'hola roy', '1357313816');
INSERT INTO `music_message` VALUES (53, 5, 2, 'holas', '1357313823');
INSERT INTO `music_message` VALUES (54, 5, 5, 'jejeje', '1358527907');
INSERT INTO `music_message` VALUES (55, 5, 4, 'ja', '1358695388');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `music_servidor`
-- 

CREATE TABLE `music_servidor` (
  `serv_id` int(11) NOT NULL auto_increment,
  `serv_nombre` varchar(50) NOT NULL,
  `serv_descripcion` varchar(255) NOT NULL,
  `serv_url` varchar(100) NOT NULL,
  `serv_acceso_user` varchar(50) NOT NULL,
  `serv_serv_acceso_pass` varchar(50) NOT NULL,
  `serv_serv_acceso_carpeta` varchar(50) NOT NULL,
  `serv_css` text NOT NULL,
  `serv_activo` int(1) NOT NULL,
  PRIMARY KEY  (`serv_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- Volcar la base de datos para la tabla `music_servidor`
-- 

INSERT INTO `music_servidor` VALUES (1, 'Youtube', '', 'http://www.youtube.com/', '', '', '', '', 1);
INSERT INTO `music_servidor` VALUES (2, 'Servidor Musica Principal', 'Luis Gago Casas', 'http://servidormusica.no-ip.org:8080/musica/', '', '', '', '', 1);
INSERT INTO `music_servidor` VALUES (3, 'Musica Lagc - Backup', 'Servidor Backup', 'musicalagc.site90.com', 'a4054288', '1989sunway', 'public_html', '', 1);
INSERT INTO `music_servidor` VALUES (4, 'DropBox', 'usuario: luisgago@lagc-peru.com pass: 1989sunway', 'dl.dropbox.com', '', '', '', '', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `m_menus`
-- 

CREATE TABLE `m_menus` (
  `m_id` int(11) NOT NULL auto_increment,
  `m_nombre` varchar(255) collate utf8_spanish_ci NOT NULL,
  `m_componente` varchar(255) collate utf8_spanish_ci NOT NULL,
  `m_orden` int(11) NOT NULL,
  `m_target` varchar(10) collate utf8_spanish_ci NOT NULL,
  `m_cssa` varchar(11) collate utf8_spanish_ci NOT NULL,
  `m_cssli` varchar(11) collate utf8_spanish_ci NOT NULL,
  `m_tcssa` int(1) NOT NULL,
  `m_tcssli` int(1) NOT NULL,
  `m_fecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `m_modificado` varchar(11) collate utf8_spanish_ci NOT NULL,
  `m_posi` int(11) NOT NULL,
  `m_activo` int(1) NOT NULL,
  PRIMARY KEY  (`m_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=10 ;

-- 
-- Volcar la base de datos para la tabla `m_menus`
-- 

INSERT INTO `m_menus` VALUES (1, 'Inicio', '-1|1', 0, '', '', '', 2, 1, '1310337280', '1341917249', 1, 2);
INSERT INTO `m_menus` VALUES (2, 'Blog', '17', 1, '', '', '', 1, 1, '1341917241', '', 1, 1);
INSERT INTO `m_menus` VALUES (3, 'Radio', '22', 2, '', '', '', 1, 1, '1341917270', '', 1, 1);
INSERT INTO `m_menus` VALUES (4, 'Videos', '15', 3, '', '', '', 1, 1, '1341917301', '', 1, 1);
INSERT INTO `m_menus` VALUES (5, 'Conoce de Socabaya', '23|1', 5, '', '', '', 1, 1, '1341917669', '1342040641', 1, 1);
INSERT INTO `m_menus` VALUES (6, 'Gente de Socabaya', '2', 6, '', '', '', 1, 1, '1341917894', '1342433687', 1, 1);
INSERT INTO `m_menus` VALUES (7, 'Mapas', '-1|3', 4, '', '', '', 1, 1, '1342040659', '', 1, 1);
INSERT INTO `m_menus` VALUES (8, 'Contactenos', '12|1', 0, '', '', '', 1, 1, '1342129121', '', 2, 1);
INSERT INTO `m_menus` VALUES (9, 'Musica', '24', 7, '', '', '', 1, 1, '1351007737', '1352053521', 1, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `m_posicion`
-- 

CREATE TABLE `m_posicion` (
  `m_pid` int(11) NOT NULL auto_increment,
  `m_pnombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `m_pactivo` int(1) NOT NULL,
  PRIMARY KEY  (`m_pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `m_posicion`
-- 

INSERT INTO `m_posicion` VALUES (1, 'Menu Principal', 1);
INSERT INTO `m_posicion` VALUES (2, 'superior', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `m_submenus`
-- 

CREATE TABLE `m_submenus` (
  `m_subid` int(11) NOT NULL auto_increment,
  `m_subnombre` varchar(255) collate utf8_spanish_ci NOT NULL,
  `m_subidm` int(11) NOT NULL,
  `m_subcomponente` varchar(255) collate utf8_spanish_ci NOT NULL,
  `m_subtarget` varchar(10) collate utf8_spanish_ci NOT NULL,
  `m_subcss` varchar(11) collate utf8_spanish_ci NOT NULL,
  `m_suborden` int(11) NOT NULL,
  `m_subfecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `m_submodificado` varchar(11) collate utf8_spanish_ci NOT NULL,
  `m_subposi` int(11) NOT NULL,
  `activado` int(1) NOT NULL,
  PRIMARY KEY  (`m_subid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `m_submenus`
-- 

INSERT INTO `m_submenus` VALUES (1, 'Lugares Turisticos', 7, '12|2', '', '', 0, '1342040733', '1342454224', 1, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `prog_archivos`
-- 

CREATE TABLE `prog_archivos` (
  `id_cont` int(11) NOT NULL auto_increment,
  `nombre_cont` varchar(100) collate utf8_spanish_ci NOT NULL,
  `archivo_cont` varchar(20) collate utf8_spanish_ci NOT NULL,
  `fecha_cre` varchar(11) collate utf8_spanish_ci NOT NULL,
  `fecha_mod` varchar(11) collate utf8_spanish_ci NOT NULL,
  `activo` int(1) NOT NULL,
  PRIMARY KEY  (`id_cont`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `prog_archivos`
-- 

INSERT INTO `prog_archivos` VALUES (1, 'Contactenos', '1_contacto', '1312252295', '1317253876', 1);
INSERT INTO `prog_archivos` VALUES (2, 'Mapa de Socabaya - Lugares Turisticos', '1_mapaturisticos', '1342454152', '', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `pro_productos`
-- 

CREATE TABLE `pro_productos` (
  `p_id` int(11) NOT NULL auto_increment,
  `p_titulo` varchar(300) collate utf8_spanish_ci NOT NULL,
  `p_contenido1` longtext collate utf8_spanish_ci NOT NULL,
  `p_contenido2` longtext collate utf8_spanish_ci NOT NULL,
  `p_contenido3` longtext collate utf8_spanish_ci NOT NULL,
  `p_imagen` varchar(14) collate utf8_spanish_ci NOT NULL,
  `p_fecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `p_fechamodi` varchar(11) collate utf8_spanish_ci NOT NULL,
  `activo` int(1) NOT NULL,
  PRIMARY KEY  (`p_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `pro_productos`
-- 

INSERT INTO `pro_productos` VALUES (1, 'Producto primero', '<p>Primer Producto</p>', '<p>caracteristicas</p>', '<p>mas info&nbsp;</p>', '1318798781.jpg', '1318777392', '1318798781', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `radio_emosoras`
-- 

CREATE TABLE `radio_emosoras` (
  `rd_id` int(11) NOT NULL auto_increment,
  `rd_nombre` varchar(255) character set utf8 collate utf8_spanish_ci NOT NULL,
  `rd_url` varchar(255) character set utf8 collate utf8_spanish_ci NOT NULL,
  `rd_estado` int(1) NOT NULL default '2',
  PRIMARY KEY  (`rd_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- Volcar la base de datos para la tabla `radio_emosoras`
-- 

INSERT INTO `radio_emosoras` VALUES (1, 'Radio XtH', 'http://giss.tv:8000/radio-xth.mp3', 1);
INSERT INTO `radio_emosoras` VALUES (2, 'amigostereo', 'http://giss.tv:8000/cumbiaenrad10.mp3', 2);
INSERT INTO `radio_emosoras` VALUES (3, 'Radio Magica', 'http://stream.giss.tv:8000/usmp.mp3', 2);
INSERT INTO `radio_emosoras` VALUES (4, 'La Metro Radio', 'http://stream.giss.tv:8000/latropi.mp3', 2);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `url_enlaces`
-- 

CREATE TABLE `url_enlaces` (
  `url_id` int(11) NOT NULL auto_increment,
  `url_nombre` varchar(255) NOT NULL,
  `url_enlace` text NOT NULL,
  `url_descripcion` varchar(255) NOT NULL,
  `url_visitas` int(100) NOT NULL default '0',
  `url_creado` varchar(11) NOT NULL,
  `url_editado` varchar(11) NOT NULL,
  `url_usuario` int(11) NOT NULL,
  `url_estado` int(1) NOT NULL,
  PRIMARY KEY  (`url_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `url_enlaces`
-- 

INSERT INTO `url_enlaces` VALUES (1, 'Historia de Socabaya', '?lagc=com_blog&id=1&categoria=socabaya', '', 53, '1341917586', '', 1, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuarios`
-- 

CREATE TABLE `usuarios` (
  `id` tinyint(5) NOT NULL auto_increment,
  `usuario` varchar(50) collate utf8_spanish_ci NOT NULL,
  `password` varchar(32) collate utf8_spanish_ci NOT NULL,
  `componentes` varchar(500) collate utf8_spanish_ci NOT NULL,
  `email` varchar(100) collate utf8_spanish_ci NOT NULL,
  `tipo` int(5) default '2',
  `activo` int(11) NOT NULL,
  `sexo` int(1) NOT NULL,
  `nombres` varchar(200) collate utf8_spanish_ci NOT NULL,
  `apellidos` varchar(200) collate utf8_spanish_ci NOT NULL,
  `idredes` varchar(255) collate utf8_spanish_ci NOT NULL,
  `idioma` varchar(6) collate utf8_spanish_ci NOT NULL,
  `cump_dia` varchar(2) collate utf8_spanish_ci NOT NULL,
  `cump_mes` varchar(2) collate utf8_spanish_ci NOT NULL,
  `cump_anio` varchar(4) collate utf8_spanish_ci NOT NULL,
  `doc_tipo` int(11) NOT NULL,
  `doc_num` int(50) NOT NULL,
  `imagen` text collate utf8_spanish_ci NOT NULL,
  `fecha` varchar(10) collate utf8_spanish_ci NOT NULL,
  `fechamodi` varchar(10) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=9 ;

-- 
-- Volcar la base de datos para la tabla `usuarios`
-- 

INSERT INTO `usuarios` VALUES (1, 'vikingo', '42d83ea5c0be456bdf42fa61f55d5288', '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23', 'luisgago@lagc-peru.com', 1, 1, 1, 'Luis', 'Gago Casas', '', '', '30', '5', '1989', 1, 70332193, 'vikingo_1340049104.jpg', '1278379495', '1340787687');
INSERT INTO `usuarios` VALUES (2, 'admin', '16f88b8d74ec25ab91a11c4c01b4a9da', '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20', 'info@lagc-peru.com', 1, 1, 1, 'Administrador', 'Lagc Peru', '', '', '-1', '-1', '-1', 1, 0, '', '1296763709', '1342517124');
INSERT INTO `usuarios` VALUES (3, 'luisenriquexth', '1bd895865446ada98bd4d2c4b1f49500', '', 'falconpower96@hotmail.com', 3, 1, 1, 'Luis', 'Xth', '1212439725', 'es_LA', '02', '25', '1991', 0, 0, 'https://graph.facebook.com/luis.e.xth/picture?type=large', '1340936048', '');
INSERT INTO `usuarios` VALUES (4, 'martin', '42c54fabf7b03281238a197876f681e0', '', 'marky3_2@hotmail.com', 2, 1, 1, 'martin', 'meza', '', '', '-1', '-1', '-1', 1, 0, '', '1340939364', '');
INSERT INTO `usuarios` VALUES (5, 'luisgago', '16f88b8d74ec25ab91a11c4c01b4a9da', '', 'luisgago@live.com', 3, 1, 1, 'Luis', 'Gago', '100000476487163', 'es_LA', '05', '30', '1989', 0, 0, 'https://graph.facebook.com/luisgagocasas/picture?type=large', '1340996696', '1343156162');
INSERT INTO `usuarios` VALUES (6, 'saulozeladaccopa', '009f2b351bbabecc089a145ecd8fee95', '', 'saulo_xth_@hotmail.com', 3, 1, 1, 'Saulo', 'Ccopa', '100001620605664', 'es_LA', '09', '03', '1996', 0, 0, 'https://graph.facebook.com/saulo.ccopa/picture?type=large', '1341041001', '');
INSERT INTO `usuarios` VALUES (7, 'rodrigoclaudiobermejovilca', 'b0a10ef5e3866d43c4272ccfd42e9fe7', '', 'claudio@portuhermana.com', 3, 1, 1, 'Rodrigo', 'Bermejo Vilca', '100001672274730', 'es_ES', '07', '15', '1995', 0, 0, 'https://graph.facebook.com/claudio.demovidas/picture?type=large', '1341438448', '');
INSERT INTO `usuarios` VALUES (8, 'hugocabrera', '069376a0602c64e4d12d00d0b8aa73b3', '', 'gowy_xth@hotmail.com', 3, 1, 1, 'Hugo', 'Cabrera', '100004006644591', 'es_LA', '02', '27', '1991', 0, 0, 'https://graph.facebook.com/hugo.cabrera.125323/picture?type=large', '1341539965', '');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuarios_amigos`
-- 

CREATE TABLE `usuarios_amigos` (
  `amg_id` int(11) NOT NULL auto_increment,
  `amg_iduserde` int(11) NOT NULL,
  `amg_iduserpara` int(11) NOT NULL,
  `amg_fechasend` varchar(11) NOT NULL,
  `amg_fechaapro` varchar(11) NOT NULL,
  `amg_mensaje` varchar(255) NOT NULL,
  `amg_aprobado` int(1) NOT NULL,
  PRIMARY KEY  (`amg_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `usuarios_amigos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuarios_comentarios`
-- 

CREATE TABLE `usuarios_comentarios` (
  `com_id` int(11) NOT NULL auto_increment,
  `com_user` int(11) NOT NULL,
  `com_idcoment` int(11) NOT NULL,
  `com_fecha` varchar(11) NOT NULL,
  `com_gusta` int(11) NOT NULL,
  `com_comentario` varchar(255) NOT NULL,
  PRIMARY KEY  (`com_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- Volcar la base de datos para la tabla `usuarios_comentarios`
-- 

INSERT INTO `usuarios_comentarios` VALUES (1, 5, 3, '1343162653', 0, 'fghghfg');
INSERT INTO `usuarios_comentarios` VALUES (2, 5, 3, '1343162934', 1, 'excelente x');
INSERT INTO `usuarios_comentarios` VALUES (3, 5, 3, '1343163368', 0, 'xD jajaja');
INSERT INTO `usuarios_comentarios` VALUES (4, 5, 3, '1343163551', 1, 'jajajajajaajaja');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuarios_publicaciones`
-- 

CREATE TABLE `usuarios_publicaciones` (
  `user_id` int(11) NOT NULL auto_increment,
  `user_comentario` varchar(255) NOT NULL,
  `user_visiblepor` int(1) NOT NULL,
  `user_de` int(11) NOT NULL,
  `user_para` int(11) NOT NULL,
  `user_fecha` varchar(11) NOT NULL,
  `user_estado` int(1) NOT NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- 
-- Volcar la base de datos para la tabla `usuarios_publicaciones`
-- 

INSERT INTO `usuarios_publicaciones` VALUES (1, 'bienvenido a por Tu HErmana :)', 1, 2, 2, '1342520143', 1);
INSERT INTO `usuarios_publicaciones` VALUES (2, 'hola bienvenido nuevamente', 1, 2, 2, '1342520547', 1);
INSERT INTO `usuarios_publicaciones` VALUES (3, 'hola', 1, 5, 5, '1343156219', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `video_categorias`
-- 

CREATE TABLE `video_categorias` (
  `vi_ca_id` int(11) NOT NULL auto_increment,
  `vi_ca_titulo` varchar(100) NOT NULL,
  `vi_ca_descripcion` varchar(255) NOT NULL,
  `vi_ca_imagen` varchar(20) NOT NULL,
  `vi_ca_estado` int(1) NOT NULL,
  PRIMARY KEY  (`vi_ca_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `video_categorias`
-- 

INSERT INTO `video_categorias` VALUES (1, 'Socabaya', '', '1335289212.jpg', 1);
INSERT INTO `video_categorias` VALUES (2, 'X T H', '', '', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `video_comentarios`
-- 

CREATE TABLE `video_comentarios` (
  `coment_id` int(11) NOT NULL auto_increment,
  `coment_video` int(11) NOT NULL,
  `coment_comentario` varchar(255) NOT NULL,
  `coment_creado` varchar(11) NOT NULL,
  `coment_usuario` int(11) NOT NULL,
  `coment_estado` int(1) NOT NULL default '2',
  PRIMARY KEY  (`coment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `video_comentarios`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `video_videos`
-- 

CREATE TABLE `video_videos` (
  `vi_id` int(11) NOT NULL auto_increment,
  `vi_titulo` varchar(200) NOT NULL,
  `vi_categoria` int(11) NOT NULL default '1',
  `vi_enlace` varchar(80) NOT NULL,
  `vi_autor` int(11) NOT NULL,
  `vi_descripcion` varchar(250) NOT NULL,
  `vi_tags` text NOT NULL,
  `vi_imagen` varchar(100) NOT NULL,
  `vi_creado` varchar(11) NOT NULL,
  `vi_modificado` varchar(11) NOT NULL,
  `vi_comentarios` int(1) NOT NULL default '2',
  `vi_estado` int(1) NOT NULL,
  PRIMARY KEY  (`vi_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

-- 
-- Volcar la base de datos para la tabla `video_videos`
-- 

INSERT INTO `video_videos` VALUES (1, 'X T H Introducción', 2, 'HzEl9sv77BU', 1, 'este video es la version 2006 - 2007 de la portada portuhermana', 'intro xth, 2006 intro, portuhermana', 'http://i.ytimg.com/vi/HzEl9sv77BU/3.jpg', '1334564369', '1340898558', 1, 1);
INSERT INTO `video_videos` VALUES (2, 'Himno de Socabaya', 1, '7njuS6J7CYo', 1, 'A nuestro Socabaya', 'socabaya himno, himno socabaya 2012', 'http://i.ytimg.com/vi/7njuS6J7CYo/1.jpg', '1340898621', '1340912971', 1, 1);
INSERT INTO `video_videos` VALUES (3, 'Primer Parque Temático Villa el Golf de Socabaya', 1, '0SjCoSVO1zE', 1, '', 'parque tematica, Villa el Golf Socabaya', 'http://i.ytimg.com/vi/0SjCoSVO1zE/default.jpg', '1340898780', '', 1, 1);
INSERT INTO `video_videos` VALUES (4, 'Socabaya en el 2012', 1, 'BSTAPNHh0G8', 1, 'Dinos tu opinión sobre que te parece el cambio que vemos en este 2012', 'socabaya el 2012, cambio de socabaya, 2012, socabaya arequipa', 'http://i.ytimg.com/vi/BSTAPNHh0G8/1.jpg', '1340899071', '', 1, 1);
INSERT INTO `video_videos` VALUES (5, 'Socabaya Reportaje La Carcocha 1', 1, 'X5PxISkoPaI', 1, '.-Reportaje del programa la  Carcocha Primera Parte que se realizo en el año 2011.', 'Socabaya La Carcocha Reportaje', 'http://i.ytimg.com/vi/X5PxISkoPaI/3.jpg', '1340899739', '1340899813', 1, 1);
INSERT INTO `video_videos` VALUES (6, 'Socabaya Reportaje La Carcocha 2', 1, 'gNFYK76Gk0Y', 1, '.-Reportaje sobre Socabaya segunda parte la Iglesia San Fernando rey de España', 'San Fernando Rey de España, Socabaya Iglesia, San Fernando Rey de Socabaya', 'http://i.ytimg.com/vi/gNFYK76Gk0Y/1.jpg', '1340900085', '', 1, 1);
INSERT INTO `video_videos` VALUES (7, 'Llegada del Rio Socabaya - Febrero 2012', 1, 'qgrCj6sgOA8', 1, 'ESTO OCURRIO EL 08 DE FEBRERO DEL 2012 EN EL PAIS DE PERU, CIUDAD AREQUIPA, DISTRITO DE SOCABAYA.\r\nEL RIO DE SOCABAYA NUNCA ANTES VISTO DE ESA MAGNITUD ESTUBO DE PAR A PAR FUE INCREIBLE.', 'llegada del rio socabaya, 2012 llegada del rio arequipa', 'http://i.ytimg.com/vi/qgrCj6sgOA8/default.jpg', '1340917939', '', 1, 1);
INSERT INTO `video_videos` VALUES (8, 'Documental de Socabaya - 2009', 1, '55iSltzVesM', 1, '', 'documental socabaya', 'http://i.ytimg.com/vi/55iSltzVesM/1.jpg', '1340918330', '', 1, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `wilss_billeteras`
-- 

CREATE TABLE `wilss_billeteras` (
  `bi_id` int(11) NOT NULL auto_increment,
  `bi_nombre` varchar(200) character set utf8 collate utf8_spanish_ci NOT NULL,
  `bi_img1` varchar(15) character set utf8 collate utf8_spanish_ci NOT NULL,
  `bi_img2` varchar(15) character set utf8 collate utf8_spanish_ci NOT NULL,
  `bi_img3` varchar(15) character set utf8 collate utf8_spanish_ci NOT NULL,
  `bi_img4` varchar(15) character set utf8 collate utf8_spanish_ci NOT NULL,
  `bi_creado` varchar(11) character set utf8 collate utf8_spanish_ci NOT NULL,
  `bi_modificado` varchar(11) character set utf8 collate utf8_spanish_ci NOT NULL,
  `bi_estado` int(1) NOT NULL,
  PRIMARY KEY  (`bi_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `wilss_billeteras`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `wilss_carteras`
-- 

CREATE TABLE `wilss_carteras` (
  `ca_id` int(11) NOT NULL auto_increment,
  `ca_nombre` varchar(200) character set utf8 collate utf8_spanish_ci NOT NULL,
  `ca_img1` varchar(15) character set utf8 collate utf8_spanish_ci NOT NULL,
  `ca_img2` varchar(15) character set utf8 collate utf8_spanish_ci NOT NULL,
  `ca_img3` varchar(15) character set utf8 collate utf8_spanish_ci NOT NULL,
  `ca_img4` varchar(15) character set utf8 collate utf8_spanish_ci NOT NULL,
  `ca_creado` varchar(11) character set utf8 collate utf8_spanish_ci NOT NULL,
  `ca_modificado` varchar(11) character set utf8 collate utf8_spanish_ci NOT NULL,
  `ca_estado` int(1) NOT NULL,
  PRIMARY KEY  (`ca_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `wilss_carteras`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `wilss_correas`
-- 

CREATE TABLE `wilss_correas` (
  `co_id` int(11) NOT NULL auto_increment,
  `co_nombre` varchar(200) character set utf8 collate utf8_spanish_ci NOT NULL,
  `co_img1` varchar(15) character set utf8 collate utf8_spanish_ci NOT NULL,
  `co_img2` varchar(15) character set utf8 collate utf8_spanish_ci NOT NULL,
  `co_img3` varchar(15) character set utf8 collate utf8_spanish_ci NOT NULL,
  `co_img4` varchar(15) character set utf8 collate utf8_spanish_ci NOT NULL,
  `co_creado` varchar(11) character set utf8 collate utf8_spanish_ci NOT NULL,
  `co_modificado` varchar(11) character set utf8 collate utf8_spanish_ci NOT NULL,
  `co_estado` int(1) NOT NULL,
  PRIMARY KEY  (`co_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `wilss_correas`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `wilss_sobres`
-- 

CREATE TABLE `wilss_sobres` (
  `so_id` int(11) NOT NULL auto_increment,
  `so_nombre` varchar(200) character set utf8 collate utf8_spanish_ci NOT NULL,
  `so_img1` varchar(15) character set utf8 collate utf8_spanish_ci NOT NULL,
  `so_img2` varchar(15) character set utf8 collate utf8_spanish_ci NOT NULL,
  `so_img3` varchar(15) character set utf8 collate utf8_spanish_ci NOT NULL,
  `so_img4` varchar(15) character set utf8 collate utf8_spanish_ci NOT NULL,
  `so_creado` varchar(11) character set utf8 collate utf8_spanish_ci NOT NULL,
  `so_modificado` varchar(11) character set utf8 collate utf8_spanish_ci NOT NULL,
  `so_estado` int(1) NOT NULL,
  PRIMARY KEY  (`so_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `wilss_sobres`
-- 

